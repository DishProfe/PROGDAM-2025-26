package ejemplos2026;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 * Programa
 */
public class ReadTxt03 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------
        // Constantes
            String FILE_NAME="numeros.txt";
            String FOLDER = "data";
            String PATH= FOLDER + "/" + FILE_NAME;
        
        // Variables de entrada
        List<Double> listaEnteros;
        FileReader fr = null; // V��nculo entre mi programa y un archivo el s.o.
        BufferedReader entrada = null; // Capa sobre el fr con el que leo textos


        // Variables de salida
        
        // Variables auxiliares
        boolean lecturaCorrecta = true;
        int contadorLineas;

        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("LECTURA DE REALES EN ARCHIVO DE TEXTO");
        System.out.println("--------------------------------------");
        System.out.println(" ");

        listaEnteros = new LinkedList<>();
        
        contadorLineas= 0;
        try {
            // Abrimos el archivo binario para lectura
            fr = new FileReader (PATH); // Establecemos v��nculo entre mi programa y un archivo del s.o.
            entrada = new BufferedReader(fr); // A�adimos capa facilitar la lectura de textos del archivo


            // Leemos cada uno de las l�neas del archivo de texto
            // y los vamos incluyendo en el Set
            String linea;
            
            while ( (linea = entrada.readLine()) != null) {
                System.out.printf ("L�nea le�da: %s\n", linea);
                double numero;
                try {
                    numero = Double.parseDouble(linea);
                    listaEnteros.add (numero);
                } catch ( NumberFormatException ex ) {
                    System.out.println ("Error: formato no num�rico real.");
                }
                contadorLineas++;
            }
            




            
//            while ( (linea = entrada.readLine()) != null ) {
//                try {
//                    int numero = Integer.parseInt(linea);
//                    listaTextos.add (numero);                    
//                    System.out.printf ("Línea correcta: %s\n", linea);
//                } catch (NumberFormatException ex) {
//                    // Línea que no contiene un número entero (no se tiene en cuenta) 
//                    System.out.printf ("Línea incorrecta: %s\n", linea);
//                }
//           }
//            
            System.out.println("Lectura del contenido del archivo finalizda.");
            
            
            
            
        } catch (FileNotFoundException ex) {
            System.out.printf("Error: %s\n", ex.getMessage());
            lecturaCorrecta = false;
        } catch (IOException ex) {
            System.out.printf("Error: %s\n", ex.getMessage());
            lecturaCorrecta = false;
        }

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        // Cerramos el archivo
        try {
            if (entrada != null) {
                entrada.close();
                if (fr != null) {
                    fr.close();
                }
            }
        } catch (IOException ex) {
            System.out.printf("Error al intentar cerrar el archivo: %s\n", ex.getMessage());
        }        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------


        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");
        System.out.printf ("Contenido leido del archivo de texto: \n%s\n", listaEnteros);
        System.out.printf ("N�mero de l�neas: %d\n", contadorLineas);
        System.out.printf ("N�mero de l�neas v�lidas: %d\n", listaEnteros.size());
        
        System.out.println();
        System.out.println("Fin del programa.");

    }

}
