package ejemplos2026;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

/**
 * Programa
 */
public class ReadTxt06 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------
        // Constantes
            String FILE_NAME="multiple.txt";
            String FOLDER = "data";
            String PATH= FOLDER + "/" + FILE_NAME;
        
        // Variables de entrada
        Map<String, List> mapElementos;
        FileReader fr = null; // V��nculo entre mi programa y un archivo el s.o.
        BufferedReader entrada = null; // Capa sobre el fr con el que leo textos


        // Variables de salida
        
        // Variables auxiliares
        boolean lecturaCorrecta = true;
        int contadorLineas;

        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("LECTURA DE ENTEROS, REALES, FECHAS SEPARADAS POR COMAS O PUNTOS Y COMAS EN ARCHIVO DE TEXTO");
        System.out.println("-------------------------------------------------------------------------------------------");
        System.out.println(" ");

        mapElementos = new LinkedHashMap<>();
        mapElementos.put ( "Enteros", new LinkedList<Integer>() );
        mapElementos.put ( "Reales", new LinkedList<Double>() );
        mapElementos.put ( "Fechas", new LinkedList<LocalDate>() );
        
        contadorLineas= 0;
        try {
            // Abrimos el archivo binario para lectura
            fr = new FileReader (PATH); // Establecemos v��nculo entre mi programa y un archivo del s.o.
            entrada = new BufferedReader(fr); // A�adimos capa facilitar la lectura de textos del archivo


            // Leemos cada uno de las l�neas del archivo de texto
            // y los vamos incluyendo en el Set
            String linea;
            
            while ( (linea = entrada.readLine()) != null) {
                System.out.printf ("L�nea le�da: %s\n", linea);

                String[] arrayLinea = linea.split("[,;]");
                for ( int indice=0; indice < arrayLinea.length  ; indice++ ) {
                    String texto = arrayLinea[indice].trim();

                    // Comprobaci�n de entero
                    if ( texto.matches("[0-9]+") ) {
                        int numero;
                        try {
                            numero = Integer.parseInt(texto);
                            mapElementos.get("Enteros").add(numero);
                        } catch ( NumberFormatException ex ) {
                            System.out.printf ("Error: \"%s\" - Formato num�rico entero incorrecto.\n",
                                    texto);
                        }
                    } // Comprobaci�n de fecha dd/mm/aaaa 
                    else if ( texto.matches("[0-9]{2}/[0-9]{2}/[0-9]{4}") ) {
                            LocalDate fecha;
                            String[] arrayElementos = texto.split("/");
                            
                            try {
                                fecha = LocalDate.of ( Integer.parseInt(arrayElementos[2]), 
                                        Integer.parseInt(arrayElementos[1]), 
                                        Integer.parseInt(arrayElementos[0]) );

    //                            fecha = LocalDate.parse ( arrayElementos[2] + "-" + 
    //                                    arrayElementos[1] + "-" +
    //                                    arrayElementos[0]);

                                mapElementos.get("Fechas").add(fecha);

                            } catch ( DateTimeException ex ) {
                                System.out.printf ("Error: \"%s\" formato de fecha incorrecto.\n", 
                                       texto);
                            }
                    } else { // Comprobaci�n de real
                        double numero;
                        try {
                            numero = Double.parseDouble(texto);
                            mapElementos.get("Reales").add(numero);
                        } catch ( NumberFormatException ex ) {
                            System.out.printf ("Error: \"%s\" - Formato del elemento incorrecto.\n",
                                    texto);
                        }
                }
            }
            contadorLineas++;
        }        




            
//            while ( (linea = entrada.readLine()) != null ) {
//                try {
//                    int numero = Integer.parseInt(linea);
//                    listaTextos.add (numero);                    
//                    System.out.printf ("Línea correcta: %s\n", linea);
//                } catch (NumberFormatException ex) {
//                    // Línea que no contiene un número entero (no se tiene en cuenta) 
//                    System.out.printf ("Línea incorrecta: %s\n", linea);
//                }
//           }
//            
            System.out.println("Lectura del contenido del archivo finalizda.");
            
            
            
            
        } catch (FileNotFoundException ex) {
            System.out.printf("Error: %s\n", ex.getMessage());
            lecturaCorrecta = false;
        } catch (IOException ex) {
            System.out.printf("Error: %s\n", ex.getMessage());
            lecturaCorrecta = false;
        }

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        // Cerramos el archivo
        try {
            if (entrada != null) {
                entrada.close();
                if (fr != null) {
                    fr.close();
                }
            }
        } catch (IOException ex) {
            System.out.printf("Error al intentar cerrar el archivo: %s\n", ex.getMessage());
        }        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------


        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");
        //System.out.printf ("Contenido leido del archivo de texto: \n%s\n", mapElementos);
        for ( String tipo : mapElementos.keySet() ) {
            System.out.printf ("%s -> %s\n", tipo, mapElementos.get(tipo));
        }
        System.out.printf ("N�mero de l�neas: %d\n", contadorLineas);
        //System.out.printf ("N�mero de elementos v�lidos: %d\n", mapElementos.size());
        
        System.out.println();
        System.out.println("Fin del programa.");

    }

}
