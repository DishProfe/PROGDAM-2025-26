
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.time.LocalDate;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;


public class EjemplosTree01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE ESTRUCTURAS ORDENADAS");
            System.out.println("---------------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            Set<Integer> s1, s2, s3;
            Set s;

            s1= new HashSet<>();
            s2= new LinkedHashSet<>();
            s3= new TreeSet<>();
            

            s= s1;
            s.add(10);
            s.add(5);
            s.add(20);
            s.add(100);
            s.add(12);
            
            s= s2;
            s.add(10);
            s.add(5);
            s.add(20);
            s.add(100);
            s.add(12);

            s= s3;
            s.add(10);
            s.add(5);
            s.add(20);
            s.add(100);
            s.add(12);

            Set<Producto2> sp1, sp2, sp3;
            Set sp;

            sp1= new HashSet<>();
            sp2= new LinkedHashSet<>();
            sp3= new TreeSet<>();
            
            Producto2 p = new Producto2("tabarra", LocalDate.of(2026, 12, 31), 6.50);
            
            sp1.add(p);

            sp2.add(p);

            sp3.add(p);
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("s1 (HashSet)       = %s\n", s1);
            System.out.printf ("s2 (LinkedHashSet) = %s\n", s2);
            System.out.printf ("s3 (TreeSet)       = %s\n", s3);
            

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}