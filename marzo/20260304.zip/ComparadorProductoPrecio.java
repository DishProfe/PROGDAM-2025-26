/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplos2026;

import java.util.Comparator;

/**
 *
 * @author diosdado
 */
public class ComparadorProductoPrecio implements Comparator<Producto2> {
    
    @Override
    public int compare (Producto2 p1, Producto2 p2) {
        return Double.compare(p1.getPrecio(), p2.getPrecio());
    }
    
    
}
