package ejemplos2026;

/**
 *
 * @author diosdado
 */
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;


/**
 * Clase Producto. Contiene la informaci�n de un producto.
 * @author profe
 */
public class Producto2  {
    private final String nombre;
    private final LocalDate caducidad;
    private final double precio;
    private static final DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern ("dd/MM/yyyy");
    
    public Producto2(String nombre, LocalDate caducidad, double precio)
    {
        this.caducidad=caducidad;
        this.nombre=nombre;
        this.precio= precio;
    }

    public String getNombre() {
        return nombre;
    }

    public LocalDate getCaducidad() {
        return this.caducidad;
    }
    
    public double getPrecio() {
        return this.precio;
    }
      
    @Override
    public String toString() {
        return String.format ("{%-10s, %s, %.2f}", 

                this.getNombre(),
                this.getCaducidad().format(formatoFecha),
                this.getPrecio());
    }

    
}