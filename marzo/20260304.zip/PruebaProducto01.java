package ejemplos2026;

/**
 * Programa XXX
 *
 * @author diosdado
 */
import java.time.LocalDate;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class PruebaProducto01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------
        List<Producto> listaProductos = new LinkedList<>();

        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
        System.out.println("ORDENACI�N DE PRODUCTOS");
        System.out.println("-----------------------");

        // Rellenamos la lista con los productos indicados en el enunciado
        listaProductos.add(new Producto("tabarra", LocalDate.of(2026, 12, 31), 6.50));
        listaProductos.add(new Producto("sardinas", LocalDate.of(2023, 12, 31), 1.50));
        listaProductos.add(new Producto("navajas", LocalDate.of(2021, 1, 1), 2.40));
        listaProductos.add(new Producto("navajas", LocalDate.of(2021, 1, 1), 7.40));
        listaProductos.add(new Producto("caballa", LocalDate.of(2023, 12, 25), 1.70));
        listaProductos.add(new Producto("mejillones", LocalDate.of(2022, 1, 11), 2.10));

        System.out.printf("Contenido inicial de la lista:\n");
        mostrarListaProductos(listaProductos);

        Collections.sort(listaProductos);
        
        System.out.println(); 
        System.out.printf("Contenido de la lista tras ordenar:\n");
        mostrarListaProductos(listaProductos);
        System.out.println();
        
        
    }

    
    // M�todo que recorre una lista de productos y los muestra cada uno en una l�nea
    static void mostrarListaProductos(List<Producto> listaProductos) {
        int contador = 1;
        for (Producto elemento : listaProductos) {
            System.out.printf("%d. %s\n", contador++, elemento);
        }
    }

}
