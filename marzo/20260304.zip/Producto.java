package ejemplos2026;

/**
 *
 * @author diosdado
 */
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;


/**
 * Clase Producto. Contiene la informaci�n de un producto.
 * @author profe
 */
public class Producto implements Comparable<Producto> {
    private final String nombre;
    private final LocalDate caducidad;
    private final double precio;
    private static final DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern ("dd/MM/yyyy");
    
    public Producto(String nombre, LocalDate caducidad, double precio)
    {
        this.caducidad=caducidad;
        this.nombre=nombre;
        this.precio= precio;
    }

    public String getNombre() {
        return nombre;
    }

    public LocalDate getCaducidad() {
        return this.caducidad;
    }
    
    public double getPrecio() {
        return this.precio;
    }
      
    @Override
    public String toString() {
        return String.format ("{%-10s, %s, %.2f}", 

                this.getNombre(),
                this.getCaducidad().format(formatoFecha),
                this.getPrecio());
    }

/*    
    @Override
    public int compareTo (Producto otroProducto) {
        int resultado = 0;
        
        if (this.precio - otroProducto.precio < 0) {
            resultado = -1 ;
        } else if (this.precio - otroProducto.precio > 0) {
            resultado =  1;
        } 
        
        return resultado;
    } 
*/    

/*    
    @Override
    public int compareTo (Producto otroProducto) {
        
        return this.caducidad.compareTo(otroProducto.caducidad);

    /*            
        int resultado = 0;
                
        if (this.caducidad.isBefore(otroProducto.caducidad)) {
            resultado = -1 ;
        } else if (this.caducidad.isAfter(otroProducto.caducidad)) {
            resultado =  1;
        } 
        
        return resultado;
    */
//*/

/*    
    @Override
    public int compareTo (Producto otroProducto) {
        
        return this.nombre.compareTo(otroProducto.nombre);

    } 
*/

/*    
    @Override
    public int compareTo (Producto otroProducto) {


        return Double.compare(this.precio, otroProducto.precio);
        
        //return Double.valueOf(this.precio).compareTo( Double.valueOf(otroProducto.precio));

//        
//        int resultado = 0;
//        
//        if (this.precio - otroProducto.precio < 0) {
//            resultado = -1 ;
//        } else if (this.precio - otroProducto.precio > 0) {
//            resultado =  1;
//        } 
//        
//        return resultado;
 

    }
*/ 
    
//    @Override
//    public int compareTo ( Producto p ) {
//
//        //return this.nombre.length() - p.nombre.length() ;
//        
//        return Integer.compare(this.nombre.length(), p.nombre.length());
//        
//        
//    }
    
//    @Override
//    public int compareTo ( Producto p ) {
//
//        int resultado = Integer.compare(this.nombre.length(), p.nombre.length());
//        
//        if ( resultado == 0 ) {
//            resultado = this.nombre.compareTo(p.nombre);
//        }
//        
//        return resultado;
//    }    
     
    @Override
    public int compareTo ( Producto p ) {

        int resultado = this.caducidad.compareTo(p.caducidad);
        
        if ( resultado == 0 ) {
            resultado = Double.compare(this.precio, p.precio);
        }
        
        if (resultado == 0) {
            resultado = Integer.compare(this.nombre.length(), p.nombre.length());
        }
        
        if ( resultado == 0 ) {
            resultado = this.nombre.compareTo(p.nombre);
        }
        
        return resultado;
    }    
    
}