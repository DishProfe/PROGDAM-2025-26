
package ejemplos2026;

/**
 * Programa de Turnos
 * @author diosdado
 */

import java.time.LocalDate;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;


public class Turnos02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida
            Map<LocalDate, Set<String> > mapTurnos;
            Map<String, Set<LocalDate> > mapTurnosPersona;
            


            // Variables auxiliares
            String[] arrayPersonas = {"Juan", "Luisa", "Clara", "Rogelio", "Francisco"};



            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("ASIGNACI�N DE TURNOS");
            System.out.println("--------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Generamos Map<LocalDate, Set<String> >
            mapTurnos = new LinkedHashMap<>();

            LocalDate fecha = LocalDate.now();
            int numDias = 0;
            
            while ( numDias < 7 ) {
                mapTurnos.put (fecha, new LinkedHashSet<>() );

                for ( int contador=0 ; contador < 3; contador++ ) {
                    mapTurnos.get (fecha).add(arrayPersonas[(numDias+contador) % arrayPersonas.length]);
                }
                
                fecha = fecha.plusDays(1);
                numDias++;
            } 
            
            // Generamos  Map<String, Set<LocalDate> > a partir de Map<LocalDate, Set<String> >
            mapTurnosPersona = new HashMap<>();
            
            // Recorremos las claves del map inicial (fechas)
            for ( LocalDate dia : mapTurnos.keySet() ) {
                Set<String> setNombres = mapTurnos.get(dia);
                // Recorremos cada Set correspondiente a cada clave (Set de nombres)
                // Recorremos cada nombre
                for ( String nombre : setNombres ) {
                    // Para cada nombre que encontremos
                    // Creamos una clave para �l y le asociamos un conjunto de LocalDate vac�o que iremos rellenando
                    if ( !mapTurnosPersona.containsKey(nombre)) {
                        mapTurnosPersona.put ( nombre, new HashSet<LocalDate>() );
                    }
                    // Metenemos para ese nombre la fecha que le corresponde
                    mapTurnosPersona.get(nombre).add (dia);
                }
            }

            
            
            
            


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Asignaci�n de turnos por fecha: ");
            System.out.println (mapTurnos);

            System.out.println ();
            System.out.println ("Asignaci�n de turnos por fecha: ");
            for ( LocalDate dia : mapTurnos.keySet()  ) {
                System.out.printf ("%s -> %s\n", 
                        dia, 
                        mapTurnos.get(dia));
            }
            
            System.out.println ("Asignaci�n de turnos por persona: ");
            System.out.println (mapTurnosPersona);

            System.out.println ();
            System.out.println ("Asignaci�n de turnos por persona: ");
            for ( String dia : mapTurnosPersona.keySet()  ) {
                System.out.printf ("%s -> %s\n", 
                        dia, 
                        mapTurnosPersona.get(dia));
            }

            System.out.println ();
            System.out.println ("Asignaci�n de turnos por fecha: ");
            for ( LocalDate dia : mapTurnos.keySet()  ) {
                System.out.printf ("%s: \n", dia);
                for ( String persona : mapTurnos.get(dia) ) {
                    System.out.printf ("  - %s\n", persona);
                }
            }
            
            System.out.println ();
            System.out.println ("Asignaci�n de turnos por persona: ");
            for ( String nombre : mapTurnosPersona.keySet()  ) {
                System.out.printf ("%s: \n", nombre);
                for ( LocalDate dia : mapTurnosPersona.get(nombre) ) {
                    System.out.printf ("  - %s\n", dia);
                }
            }

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}