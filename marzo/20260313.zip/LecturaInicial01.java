package ejemplos2026;

/**
 * Programa XXX
 *
 * @author diosdado
 */
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class LecturaInicial01 {

    public static void main(String[] args) {

        FileInputStream fis;
        DataInputStream entrada;
        
        byte byteLeido;

        String ARCHIVO_ENTRADA = "./unidad08-01.datos";

        try {

            // Abrimos el archivo para leer: establecimiento de un v�nculo con el sistema operativo 
            fis = new FileInputStream(ARCHIVO_ENTRADA);

            // Pasamos ese FileOutputStream a un DataOutputStream 
            // para poder "leer" tipos primitivos (int, byte, float, boolean, etc.).
            entrada = new DataInputStream(fis);

            // Leemos un byte
            byteLeido = entrada.readByte();
            System.out.printf("Elemento leido: %d\n", byteLeido);


            
            
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

    }

}
