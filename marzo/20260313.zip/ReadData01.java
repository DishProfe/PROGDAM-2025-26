package ejemplos2026;

import ejemplos2024.*;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

/**
 * Programa
 */
public class ReadData01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------
    // Constantes
    String ARCHIVO_ENTRADA = "./unidad08-01.datos";

        // Variables de entrada
        // Enteros
        byte[] arrayByte = new byte[16];
        short[] arrayShort = new short[8];
        int[] arrayInt = new int[4];
        long[] arrayLong = new long[2];

        // Reales
        float[] arrayFloat = new float[4];
        double[] arrayDouble = new double[2];

        // Caracteres
        char[] arrayChar = new char[8];

        // Boolean
        boolean[] arrayBoolean = new boolean[16];

        // Variables de salida
        FileInputStream fis;
        DataInputStream entrada;

        // Variables auxiliares
        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("LECTURA DE ARCHIVO BINARIO");
        System.out.println("--------------------------");
        System.out.println(" ");

            System.out.printf("Leyendo del archivo de entrada %s:\n\n", ARCHIVO_ENTRADA);

            try {

            // Abrimos el archivo para leer
            fis = new FileInputStream(ARCHIVO_ENTRADA);

            // Pasamos ese FileOutputStream a un DataOutputStream 
            // para poder "leer" tipos primitivos (int, float, boolean, etc.).
            entrada = new DataInputStream(fis);

            // Leemos los diecis�is primeros bytes interpret�ndolos como bytes (16 * 1 byte)
            readByte(entrada, arrayByte);

            // Leemos 16 bytes interpret�ndolos como short (8 * 2 bytes)
            readShort(entrada, arrayShort);

            // Leemos 16 bytes interpret�ndolos como short (4 * 4 bytes)
            readInt(entrada, arrayInt);

            // Leemos 16 bytes interpret�ndolos como long (2 * 8 bytes)
            readLong(entrada, arrayLong);

            // Leemos 16 bytes interpret�ndolos como float (4 * 4 bytes)
            readFloat(entrada, arrayFloat);

            // Leemos 16 bytes interpret�ndolos como double (2 * 8 bytes)
            readDouble(entrada, arrayDouble);

            // Leemos 16 bytes interpret�ndolos como char (8 * 2 bytes)
            readChar(entrada, arrayChar);

            // Leemos 16 bytes interpret�ndolos como float (16 * 1 byte)
            readBoolean(entrada, arrayBoolean);

        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");

        System.out.println();
        System.out.println("Fin del programa.");

    }

    static void readByte(DataInputStream entrada, byte[] array) throws IOException {
        for (int i = 0; i < array.length; i++) {
            array[i] = entrada.readByte();
        }
        System.out.printf("Datos le�dos: %s\n\n",
                Arrays.toString(array));
    }

    static void readShort(DataInputStream entrada, short[] array) throws IOException {
        for (int i = 0; i < array.length; i++) {
            array[i] = entrada.readShort();
        }
        System.out.printf("Datos le�dos: %s\n\n",
                Arrays.toString(array));
    }

    static void readInt(DataInputStream entrada, int[] array) throws IOException {
        for (int i = 0; i < array.length; i++) {
            array[i] = entrada.readInt();
        }
        System.out.printf("Datos le�dos: %s\n\n",
                Arrays.toString(array));
    }

    static void readLong(DataInputStream entrada, long[] array) throws IOException {
        for (int i = 0; i < array.length; i++) {
            array[i] = entrada.readLong();
        }
        System.out.printf("Datos le�dos: %s\n\n",
                Arrays.toString(array));
    }

    static void readFloat(DataInputStream entrada, float[] array) throws IOException {
        for (int i = 0; i < array.length; i++) {
            array[i] = entrada.readFloat();
        }
        System.out.printf("Datos le�dos: %s\n\n",
                Arrays.toString(array));
    }

    static void readDouble(DataInputStream entrada, double[] array) throws IOException {
        for (int i = 0; i < array.length; i++) {
            array[i] = entrada.readDouble();
        }
        System.out.printf("Datos le�dos: %s\n\n",
                Arrays.toString(array));
    }

    static void readChar(DataInputStream entrada, char[] array) throws IOException {
        for (int i = 0; i < array.length; i++) {
            array[i] = entrada.readChar();
        }
        System.out.printf("Datos le�dos: %s\n\n",
                Arrays.toString(array));
    }

    static void readBoolean(DataInputStream entrada, boolean[] array) throws IOException {
        for (int i = 0; i < array.length; i++) {
            array[i] = entrada.readBoolean();
        }
        System.out.printf("Datos le�dos: %s\n\n",
                Arrays.toString(array));
    }

}
