package ejemplos2026;

/**
 * Programa XXX
 *
 * @author diosdado
 */
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class LecturaInicial03 {

    public static void main(String[] args) {

        FileInputStream fis;
        DataInputStream entrada;
        
        byte byteLeido;

        String ARCHIVO_ENTRADA = "./unidad08-01.datos";

        try {

            // Abrimos el archivo para leer: establecimiento de un v�nculo con el sistema operativo 
            fis = new FileInputStream(ARCHIVO_ENTRADA);

            // Pasamos ese FileOutputStream a un DataOutputStream 
            // para poder "leer" tipos primitivos (int, byte, float, boolean, etc.).
            entrada = new DataInputStream(fis);

            // Leemos varios bytes
            for ( int contador = 0 ; contador < 128; contador++ ){ 
                byteLeido = entrada.readByte();
                System.out.printf("%4d ", byteLeido);
                if ( (contador+1) % 16 == 0) {
                    System.out.println();
                }
            }

            
            
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

    }

}
