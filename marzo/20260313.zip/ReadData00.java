package ejemplos2026;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

/**
 * Programa
 */
public class ReadData00 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------
        // Constantes
        String ARCHIVO_ENTRADA = "./unidad08-01.datos";

        // Variables de entrada
        // Enteros
        byte[] arrayByte = new byte[16];
        short[] arrayShort = new short[8];
        int[] arrayInt = new int[4];
        long[] arrayLong = new long[2];

        // Reales
        float[] arrayFloat = new float[4];
        double[] arrayDouble = new double[2];

        // Caracteres
        char[] arrayChar = new char[8];

        // Boolean
        boolean[] arrayBoolean = new boolean[16];

        // Variables de salida
        FileInputStream fis;
        DataInputStream entrada;

        // Variables auxiliares
        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("LECTURA DE ARCHIVO BINARIO");
        System.out.println("--------------------------");
        System.out.println(" ");

        System.out.printf("Leyendo del archivo de entrada %s:\n\n", ARCHIVO_ENTRADA);


        ARCHIVO_ENTRADA = "./unidad08-02.datos";

        try {

            // Abrimos el archivo para leer: establecimiento de un v�nculo con el sistema operativo 
            fis = new FileInputStream(ARCHIVO_ENTRADA);

            // Pasamos ese FileOutputStream a un DataOutputStream 
            // para poder "leer" tipos primitivos (int, byte, float, boolean, etc.).
            entrada = new DataInputStream(fis);

            int numero;
            // Leemos 16 bytes del archivo binario
            System.out.println("Leyendo 16 bytes");
            for (int i=0; i<16; i++) {
                // Leemos un byte
                numero = entrada.readByte();
                System.out.printf("Elemento le�do: %4d\n", numero);
                System.out.printf("Elemento le�do: %4x\n", numero);
                System.out.printf("Elemento le�do: %4s\n", Integer.toBinaryString(numero));
                System.out.println();
            }

            short numShort;
            // Leemos 8 shorts del archivo binario (16 bytes)
            System.out.println("Leyendo 8 shorts (16 bytes)");
            for (int i=0; i<8; i++) {
                // Leemos un short
                numShort = entrada.readShort();
                System.out.printf("Elemento le�do: %4d\n", numShort);
                System.out.printf("Elemento le�do: %4x\n", numShort);
                System.out.printf("Elemento le�do: %4s\n", Integer.toBinaryString(numShort));
                System.out.println();
            }

            int numInt;
            // Leemos 4 int del archivo binario (16 bytes)
            System.out.println("Leyendo 4 int (16 bytes)");
            for (int i=0; i<4; i++) {
                // Leemos un int
                numInt = entrada.readInt();
                System.out.printf("Elemento le�do: %4d\n", numInt);
                System.out.printf("Elemento le�do: %4x\n", numInt);
                System.out.printf("Elemento le�do: %4s\n", Integer.toBinaryString(numInt));
                System.out.println();
            }
            
            long numLong;
            // Leemos 2 long del archivo binario (16 bytes)
            System.out.println("Leyendo 2 long (16 bytes)");
            for (int i=0; i<2; i++) {
                // Leemos un long
                numLong = entrada.readLong();
                System.out.printf("Elemento le�do: %4d\n", numLong);
                System.out.printf("Elemento le�do: %4x\n", numLong);
                System.out.printf("Elemento le�do: %4s\n", Long.toBinaryString(numLong));
                System.out.println();
            }
            
            float numFloat;
            // Leemos 4 float del archivo binario (16 bytes)
            System.out.println("Leyendo 4 float (16 bytes)");
            for (int i=0; i<4; i++) {
                // Leemos un float
                numFloat = entrada.readFloat();
                System.out.printf("Elemento le�do: %.2f\n", numFloat);
            }
            System.out.println();

            double numDouble;
            // Leemos 2 double del archivo binario (16 bytes)
            System.out.println("Leyendo 2 double (16 bytes)");
            for (int i=0; i<2; i++) {
                // Leemos un double
                numDouble = entrada.readDouble();
                System.out.printf("Elemento le�do: %.2f\n", numDouble);
            }
            System.out.println();
            
            char caracter;
            // Leemos 8 char de tama�o 2 bytes del archivo binario (16 bytes)
            System.out.println("Leyendo 8 char de tama�o 2 bytes (16 bytes)");
            for (int i=0; i<8; i++) {
                // Leemos un char
                caracter = entrada.readChar();
                System.out.printf("Elemento le�do: '%c'\n", caracter);
                System.out.printf("Elemento le�do (como int): %4d\n", (int)caracter);
                System.out.printf("Elemento le�do (como int): %04x\n", (int)caracter);
                System.out.println();
            }
            System.out.println();

            boolean valorBoolean;
            // Leemos 8 char de tama�o 2 bytes del archivo binario (16 bytes)
            System.out.println("Leyendo 16 boolean de tama�o 1 byte (16 bytes)");
            for (int i=0; i<16; i++) {
                // Leemos un boolean
                valorBoolean = entrada.readBoolean();
                System.out.printf("Elemento le�do: %b\n", valorBoolean);
                System.out.println();
            }
            System.out.println();

            
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");

        System.out.println();
        System.out.println("Fin del programa.");

    }

    static void readByte(DataInputStream entrada, byte[] array) throws IOException {
        for (int i = 0; i < array.length; i++) {
            array[i] = entrada.readByte();
        }
        System.out.printf("Datos le�dos: %s\n\n",
                Arrays.toString(array));
    }

    static void readShort(DataInputStream entrada, short[] array) throws IOException {
        for (int i = 0; i < array.length; i++) {
            array[i] = entrada.readShort();
        }
        System.out.printf("Datos le�dos: %s\n\n",
                Arrays.toString(array));
    }

    static void readInt(DataInputStream entrada, int[] array) throws IOException {
        for (int i = 0; i < array.length; i++) {
            array[i] = entrada.readInt();
        }
        System.out.printf("Datos le�dos: %s\n\n",
                Arrays.toString(array));
    }

    static void readLong(DataInputStream entrada, long[] array) throws IOException {
        for (int i = 0; i < array.length; i++) {
            array[i] = entrada.readLong();
        }
        System.out.printf("Datos le�dos: %s\n\n",
                Arrays.toString(array));
    }

    static void readFloat(DataInputStream entrada, float[] array) throws IOException {
        for (int i = 0; i < array.length; i++) {
            array[i] = entrada.readFloat();
        }
        System.out.printf("Datos le�dos: %s\n\n",
                Arrays.toString(array));
    }

    static void readDouble(DataInputStream entrada, double[] array) throws IOException {
        for (int i = 0; i < array.length; i++) {
            array[i] = entrada.readDouble();
        }
        System.out.printf("Datos le�dos: %s\n\n",
                Arrays.toString(array));
    }

    static void readChar(DataInputStream entrada, char[] array) throws IOException {
        for (int i = 0; i < array.length; i++) {
            array[i] = entrada.readChar();
        }
        System.out.printf("Datos le�dos: %s\n\n",
                Arrays.toString(array));
    }

    static void readBoolean(DataInputStream entrada, boolean[] array) throws IOException {
        for (int i = 0; i < array.length; i++) {
            array[i] = entrada.readBoolean();
        }
        System.out.printf("Datos le�dos: %s\n\n",
                Arrays.toString(array));
    }

}
