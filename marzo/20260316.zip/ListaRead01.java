
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;


public class ListaRead01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            String FILE_NAME="lista.dat";
            String FOLDER = "data";
            String PATH= FOLDER + "/" + FILE_NAME;


            // Variables de entrada
            List<Integer> lista = null;
            FileInputStream fis;
            ObjectInputStream entrada;



            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("LEER LISTA DE ALEATORIOS DE ARCHIVO BINARIO SERIALIZADO");
            System.out.println("-------------------------------------------------------");
            System.out.println(" ");
            
            try {
                
                // Abrimos el archivo para leer
                fis = new FileInputStream (PATH);
                
                // Pasamos ese FileInput a un ObjectInputStream
                // para poder "leer" objetos serializados
                entrada = new ObjectInputStream ( fis );
                
                // Leer un objeto del archivo
                lista = (List)entrada.readObject();
                
                if ( lista instanceof ArrayList ) {
                    System.out.println ("Le�do un objeto ArrayList");
                } else if ( lista instanceof LinkedList ) {
                    System.out.println ("Le�do un objeto ArrayList");                    
                } else {
                    System.out.println ("Le�do otro objeto List");                                        
                }
                
                
                
                
            } catch ( FileNotFoundException ex ) {
                System.out.printf("Error: %s\n", ex.getMessage());                
            } catch ( IOException ex) {
                System.out.printf("Error: %s\n", ex.getMessage());        
            } catch ( ClassNotFoundException ex) {
                System.out.printf("Error: %s\n", ex.getMessage());
            }
            
            
            


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            if ( lista != null ){
                System.out.printf ("Lista le�da");
                System.out.printf ("Tama�o: %d\n", lista.size());
                System.out.printf ("Contenido: %s\n", lista);
            }
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}