
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;


public class PruebaEquipo01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("PRUEBA DE EQUIPOS SERIALIZADOS");
            System.out.println("------------------------------");
            System.out.println(" ");

            Equipo e1 = new Equipo("Zuazo", "Barakaldo");
            System.out.printf ("Creado equipo: %s\n", e1);
            Equipo e2 = new Equipo("Aula", "Valladolid");
            System.out.printf ("Creado equipo: %s\n", e2);
            
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            System.out.println ("Guardando equipos en disco...");
            e1.save ("data/e1.dat");
            e2.save ("data/e2.dat");
            System.out.println ("Equipos guardados.");

            
            System.out.println ("Leyendo equipos de disco...");
            Equipo e3, e4;
            
            try {
                e3 = Equipo.CargarEquipo("data/e1.dat");
                e4 = Equipo.CargarEquipo("data/e2.dat");
                System.out.printf ("Equipo leido de e1.dat: %s\n", e3);
                System.out.printf ("Equipo leido de e2.dat: %s\n", e4);
            } catch ( FileNotFoundException ex ) {
                System.out.printf("Error: %s\n", ex.getMessage());                
            } catch ( IOException ex) {
                System.out.printf("Error: %s\n", ex.getMessage());        
            } catch ( ClassNotFoundException ex) {
                System.out.printf("Error: %s\n", ex.getMessage());
            }

            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}