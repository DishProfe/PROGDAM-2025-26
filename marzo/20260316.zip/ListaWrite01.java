
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;


public class ListaWrite01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            String FILE_NAME="lista.dat";
            String FOLDER = "data";
            String PATH= FOLDER + "/" + FILE_NAME;

            // Variables de entrada
            List<Integer> lista;



            // Variables de salida
            FileOutputStream fos;
            ObjectOutputStream salida;

            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            lista = new LinkedList<>();
            
            System.out.println("ALEATORIOS EN ARCHIVO BINARIO SERIALIZADO");
            System.out.println("-----------------------------------------");
            System.out.println(" ");

            int sizeLista = 10 + (int) (Math.random() * 11);
            for (int i = 0; i < sizeLista; i++) {
                lista.add ((int) (Math.random() * 10));
            }

            System.out.printf ("Tama�o de la lista: %d\n", lista.size());
            System.out.printf ("Contenido de la lista: %s\n", lista);
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            try {
                // Establecimiento de un v�nculo con el sistema operativo
                fos = new FileOutputStream (PATH);
                
                // Objeto OOS sobre el que serializar
                salida = new ObjectOutputStream (fos);
                
                // Escribimos el objeto lista serializado en archivo binario
                System.out.println("Escribiendo lista en archivo binario serializado...");
                salida.writeObject(lista);
                
            } catch ( FileNotFoundException ex ) {
                System.out.printf("Error: %s\n", ex.getMessage());
            } catch ( IOException ex ) {
                System.out.printf("Error: %s\n", ex.getMessage());                
            }



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf("Archivo generado: %s\n", PATH);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}