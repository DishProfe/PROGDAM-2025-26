package ejemplos2026;

import java.util.Comparator;

/**
 *
 * @author diosdado
 */
public class ComparadorCitasPorTexto implements Comparator<CitaLiteraria> {
    
    @Override
    public int compare (CitaLiteraria cita1, CitaLiteraria cita2 ) {
        return cita1.getTexto().compareTo(cita2.getTexto());
    }
    
}
