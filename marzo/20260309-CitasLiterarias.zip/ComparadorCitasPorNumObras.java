
package ejemplos2026;

import java.util.Comparator;

/**
 *
 * @author diosdado
 */
public class ComparadorCitasPorNumObras implements Comparator<CitaLiteraria> {
    
    public int compare (CitaLiteraria cita1, CitaLiteraria cita2) {
        
        return cita1.getUsos().size() - cita2.getUsos().size();
        
    }
    
    
}
