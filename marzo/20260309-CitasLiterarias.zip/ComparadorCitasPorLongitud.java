
package ejemplos2026;

import java.util.Comparator;

/**
 *
 * @author diosdado
 */
public class ComparadorCitasPorLongitud implements Comparator<CitaLiteraria> {
    
    @Override
    public int compare (CitaLiteraria cita1, CitaLiteraria cita2) {
        
        return cita1.getTexto().length() - cita2.getTexto().length() ;
        
        //return Integer.compare (cita1.getTexto().length(), cita2.getTexto().length());
        
        //return Integer.valueOf(cita1.getTexto().length()).compareTo(Integer.valueOf(cita2.getTexto().length()));
        
        
    }
    
}
