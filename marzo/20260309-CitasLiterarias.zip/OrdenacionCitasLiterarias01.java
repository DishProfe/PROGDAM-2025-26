
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;


public class OrdenacionCitasLiterarias01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida
            List<CitaLiteraria> listaCitas;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("ORDENACI�N DE CITAS");
            System.out.println("-------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            listaCitas = new LinkedList<>();
            
            CitaLiteraria cita1 = new CitaLiteraria (
                    "Soy el mejor en morir en la escena",
                    "Libro 1"
                );

            CitaLiteraria cita2 = new CitaLiteraria (
                    "El mundo acaba hoy",
                    "Libro 1", "Libro 2"
                );
            
            CitaLiteraria cita3 = new CitaLiteraria (
                    "Silba una vez y vendr� siempre",
                    "Libro 3", "Libro 4", "Libro 5"
                );

            CitaLiteraria cita4 = new CitaLiteraria (
                    "Un invitado invita a cien"
                );
            
            
            
            listaCitas.add (cita1);
            listaCitas.add (cita2);
            listaCitas.add (cita3);
            listaCitas.add (cita4);

            
            System.out.println ("Lista antes de ser ordenada: ");
            printLista (listaCitas);
            System.out.println();
            
            Collections.sort (listaCitas);  
            
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Lista despu�s de ser ordenada: ");
            printLista (listaCitas);
            System.out.println();


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
        
        
        
    public static void printLista ( List lista ) {
        for ( int indice=0 ; indice < lista.size(); indice++ ) {
            System.out.printf ("%2d. %s\n", 
                    indice+1, 
                    lista.get(indice));
        }            
    }
    
}