
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;


public class CargarCiudades01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            String FILE_NAME="Slovenia.txt";
            String FOLDER = "data\\World\\Europe\\Southern Europe";
            String PATH= FOLDER + "/" + FILE_NAME;


            // Variables de entrada
            List<Ciudad> listaCiudades;
            FileReader fr = null; // V��nculo entre mi programa y un archivo el s.o.
            BufferedReader entrada = null; // Capa sobre el fr con el que leo textos



            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CARGAR LISTA DE CIUDADES DE UN ARCHIVO DE TEXTO");
            System.out.println("-----------------------------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            listaCiudades = new LinkedList<>();
            
            try {
                // Abrimos el archivo de texto para lectura
                fr = new FileReader (PATH); // Establecemos v��nculo entre mi programa y un archivo del s.o.
                entrada = new BufferedReader(fr); // A�adimos capa facilitar la lectura de textos del archivo


                // Leemos cada uno de las l�neas del archivo de texto
                // y los vamos incluyendo en el Set
                String linea;

                int contador= 0 ;
                while ( (linea = entrada.readLine()) != null) {

                    String[] arrayElementos = linea.split(",");
                    if ( arrayElementos.length == 5 ) {

                        try {
                            Ciudad ciudad = new Ciudad ( 
                                    Integer.parseInt(arrayElementos[0].trim()),
                                    arrayElementos[1],
                                    arrayElementos[2],
                                    arrayElementos[3],
                                    Integer.parseInt(arrayElementos[4].trim())                            
                            );

                            listaCiudades.add(ciudad);
                        } catch ( NumberFormatException ex ) {
                            //System.out.printf ("Error: %s\n", ex.getMessage());
                        }

                    }

                    //System.out.printf ("L�nea le�da: %s\n", linea);
                    contador++;
                }






                System.out.println("Lectura del contenido del archivo finalizada.");


            } catch (FileNotFoundException ex) {
                System.out.printf("Error: %s\n", ex.getMessage());
            } catch (IOException ex) {
                System.out.printf("Error: %s\n", ex.getMessage());
            }


            // Ordenamos la lista
            Collections.sort (listaCiudades);


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            Iterator<Ciudad> it = listaCiudades.iterator();
            int contador = 1;
            System.out.printf ("Total de ciudades leidas correctamente: %d\n", 
                    listaCiudades.size());
            while ( it.hasNext() ) {
                Ciudad ciudad = it.next();
                System.out.printf ("%2d: %s\n", contador++, ciudad);
            }


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}