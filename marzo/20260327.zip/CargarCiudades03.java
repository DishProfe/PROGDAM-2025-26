package ejemplos2026;

/**
 * Programa XXX
 *
 * @author diosdado
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class CargarCiudades03 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------
        // Constantes
        String FOLDER = "data\\World\\Asia";

        // Variables de entrada
        Map <String ,Map < String, List<Ciudad> > > mapRegionPaisesCiudades;

        // Variables de salida

        // Variables auxiliares
        String path;
        
        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("CARGAR LISTA DE CIUDADES DE UN DIRECTORIO DE REGIONES DE DIRECTORIO DE PAISES");
        System.out.println("-----------------------------------------------------------------------------");
        System.out.println(" ");

        mapRegionPaisesCiudades = new LinkedHashMap<>();
        
        File directorio = new File(FOLDER);
        String[] listaDirectorios = directorio.list();

        for (int indice = 0; indice < listaDirectorios.length; indice++) {
            System.out.printf ("%2d: %s\n", indice+1, listaDirectorios[indice]);
            path = FOLDER + "/" + listaDirectorios[indice];
            
            
            Map <String, List<Ciudad>> mapPaisCiudades= cargarPaisesFromFolder (path);
            mapRegionPaisesCiudades.put (
                    listaDirectorios[indice], 
                    mapPaisCiudades);

            System.out.println();
            
        }
        
        
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------

        //---------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");
        System.out.println ("El map queda: ");

        for ( String region : mapRegionPaisesCiudades.keySet() ) {
            
            System.out.printf ("Region: %s\n", region);
            System.out.printf ("--------------------\n");

            for ( String pais : mapRegionPaisesCiudades.get(region).keySet() ) {
                System.out.printf ("%s:\n", pais);

                for ( int indice=0 ; indice < mapRegionPaisesCiudades.get(region).get(pais).size() ; indice++ ) {

                   Ciudad ciudad = mapRegionPaisesCiudades.get(region).get(pais).get(indice);
                   System.out.printf ("  - %s\n", ciudad.getNombre());
                }
                System.out.println();

        }
            
            
        }

        
        System.out.println();
        System.out.println("Fin del programa.");

    }

    static Map <String, List<Ciudad> > cargarPaisesFromFolder (String folderName) {
        
        File directorio = new File(folderName);
        String[] listaArchivos = directorio.list();

        Map < String, List<Ciudad> > mapPaisCiudades = new LinkedHashMap<>();
        
        for (int indice = 0; indice < listaArchivos.length; indice++) {
            System.out.printf ("%2d: %s\n", indice+1, listaArchivos[indice]);
            String path = folderName + "/" + listaArchivos[indice];
            
            
            List<Ciudad> listaCiudades= cargarCiudadesFromFile (path);
            mapPaisCiudades.put (
                    listaArchivos[indice].replace(".txt", ""), 
                    listaCiudades);

            System.out.println();
            
        }
        
        return mapPaisCiudades;
        
    }
    
    
    static List<Ciudad> cargarCiudadesFromFile(String fileName) {

        FileReader fr = null; // V��nculo entre mi programa y un archivo el s.o.
        BufferedReader entrada = null; // Capa sobre el fr con el que leo textos
        List<Ciudad> listaCiudades = new LinkedList<>();

        try {
            // Abrimos el archivo de texto para lectura
            fr = new FileReader(fileName); // Establecemos v��nculo entre mi programa y un archivo del s.o.
            entrada = new BufferedReader(fr); // A�adimos capa facilitar la lectura de textos del archivo

            // Leemos cada uno de las l�neas del archivo de texto
            // y los vamos incluyendo en el Set
            String linea;

            int contador = 0;
            while ((linea = entrada.readLine()) != null) {

                String[] arrayElementos = linea.split(",");
                if (arrayElementos.length == 5) {

                    try {
                        Ciudad ciudad = new Ciudad(
                                Integer.parseInt(arrayElementos[0].trim()),
                                arrayElementos[1],
                                arrayElementos[2],
                                arrayElementos[3],
                                Integer.parseInt(arrayElementos[4].trim())
                        );

                        listaCiudades.add(ciudad);
                    } catch (NumberFormatException ex) {
                        //System.out.printf ("Error: %s\n", ex.getMessage());
                    }

                }

                //System.out.printf ("L�nea le�da: %s\n", linea);
                contador++;
            }

            //System.out.println("Lectura del contenido del archivo finalizada.");
        } catch (FileNotFoundException ex) {
            System.out.printf("Error: %s\n", ex.getMessage());
        } catch (IOException ex) {
            System.out.printf("Error: %s\n", ex.getMessage());
        }

        // Ordenamos la lista
        Collections.sort(listaCiudades);

        return listaCiudades;
    }

}
