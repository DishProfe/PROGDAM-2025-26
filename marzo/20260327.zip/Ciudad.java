/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplos2026;

/**
 *
 * @author diosdado
 */
public class Ciudad implements Comparable<Ciudad> {
    
    private int id;
    private String nombre;
    private String codPais;
    private String distrito;
    private int poblacion; 
    
    public Ciudad (int id, String nombre, String codPais, String distrito, int poblacion ) {
        this.id = id;
        this.nombre = nombre;
        this.codPais = codPais;
        this.distrito = distrito;
        this.poblacion = poblacion;
               
    }
    
    public String getNombre() {
        return this.nombre;
    }
    
    
    
    @Override
    public String toString () {
        return String.format ("%3d %32s %5s %20s %8d",
                this.id,
                this.nombre,
                this.codPais,
                this.distrito,
                this.poblacion
        );
    }
    
    @Override
    public int compareTo ( Ciudad otraCiudad ) {
        return this.nombre.compareTo(otraCiudad.nombre);
    }
    
    
}
