
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;


public class BuscarCoincidentes01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            //String arrayColores[] = {"NGR", "BLA", "ROJ", "VER", "AMR", "AZL"};
            String arrayColores[] = {"NGR", "BLA", "ROJ", "VER"};


            // Variables de entrada
            List<String> lista1, lista2, listaEliminados;
            List<Integer> posiciones;
            Set<String> setEliminados;
            List<Integer> listaPosiciones;
            Map<String, Integer> mapCoincidencias;
            Map<String, Set<Integer> > mapListaCoincidencias;



            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("B�SQUEDA DE COINCIDENTES");
            System.out.println("------------------------");
            System.out.println(" ");

            
            // Reservamos espacio para las estructuras
            lista1 = new LinkedList<>();
            lista2 = new LinkedList<>();
            listaEliminados = new LinkedList<>();
            listaPosiciones = new LinkedList<>();
            setEliminados = new HashSet<>();
            mapCoincidencias = new HashMap<>();
            mapListaCoincidencias = new HashMap();
            
            // Rellenamos aleatoriamente lista1
            while ( lista1.size() < 15) {
                String colorRandom = arrayColores[(int)(Math.random()*arrayColores.length)];
                lista1.add(colorRandom);
            }
            
            // Rellenamos aleatoriamente lista2
            while ( lista2.size() < 15) {
                String colorRandom = arrayColores[(int)(Math.random()*arrayColores.length)];
                lista2.add(colorRandom);
            }
            
            System.out.println ("Valores iniciales: ");
            System.out.printf ("lista1: %s\n", lista1);
            System.out.printf ("lista2: %s\n", lista2);
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            
            for ( int indice=0 ; indice < lista1.size() ; indice++ ) {
                String color1 = lista1.get(indice);
                String color2 = lista2.get(indice);
                if (  color1.equals(color2) ) {
                    lista1.set (indice, "---");
                    lista2.set (indice, "---");
                    listaEliminados.add(color1);
                    listaPosiciones.add(indice);
                    setEliminados.add(color1);
                    
                    if ( mapCoincidencias.containsKey(color1) ) {
                        // Obtenemos la cantidad de ese color por ahora y lo incrementamos en 1
                        int valorActual = mapCoincidencias.get(color1);
                        mapCoincidencias.put(color1, valorActual+1);

                        // A�adimos la nueva posici�n de ese color
                        mapListaCoincidencias.get(color1).add(indice);

                    } else {
                        // Si es la primera vez que aparece el color, creamos su clave
                        mapCoincidencias.put(color1, 1); 
                        mapListaCoincidencias.put (color1, new HashSet<>() );
                        mapListaCoincidencias.get (color1).add(indice);
                    }
                    
                    
                }
            }




            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("lista1: %s\n", lista1);
            System.out.printf ("lista2: %s\n", lista2);
            System.out.printf ("listaEliminados: %s\n", listaEliminados);
            System.out.printf ("listaPosiciones: %s\n", listaPosiciones);
            System.out.printf ("setEliminados: %s\n", setEliminados);
            System.out.printf ("mapCoincidencias: %s\n", mapCoincidencias);
            System.out.printf ("mapListaCoincidencias: %s\n", mapListaCoincidencias);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}