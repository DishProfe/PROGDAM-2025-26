
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;


public class FechasDias01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int year = 2026;



            // Variables de salida
            Map<Month, Map<DayOfWeek, Set<LocalDate> > > calendario;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CALENDARIO MAP ");
            System.out.println("---------------");
            System.out.println(" ");
             

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Reservamos espacio para la estructura principal
            calendario = new LinkedHashMap<>();
            
            // Creamos una clave para cada mes
            for ( int indiceMes = 1 ; indiceMes <=12 ; indiceMes++ ) {
                Month mes = Month.of(indiceMes);
                
                // Para cada mes le asignamos un nuevo map
                calendario.put ( mes, new LinkedHashMap<>() );
                
                // Creamos una clave para d�a de la semana en ese map
                for ( int indiceDiaSemana = 1 ; indiceDiaSemana<=7 ;  indiceDiaSemana++ ) {
                    DayOfWeek diaSemana = DayOfWeek.of(indiceDiaSemana);

                    // Para cada d�a de la semana le asignamos un set de fechas
                    calendario.get(mes).put ( diaSemana, new TreeSet<>()  ) ;
                    
                    // Rellenamos ese set de fechas con las fechas del mes que coincian con ese d�a de la semana
                    LocalDate fecha = LocalDate.of (year, mes , 1);
                    // Recorremos todas las fechas del mes
                    while ( fecha.getMonth().equals(mes) ) {
                        
                        // Aquellas cuyo d�a de la semana coincida con el actual, las metemos en el set
                        if ( fecha.getDayOfWeek().equals(diaSemana) ) {
                            calendario.get(mes).get(diaSemana).add(fecha);
                        }
                        fecha = fecha.plusDays(1);
                        
                    }
                    //System.out.printf ("%s\n", calendario);
                    
                }
            }



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            for ( Month mes : calendario.keySet() ) {
                System.out.printf ("%s\n", mes);
                for ( DayOfWeek diaSemana :  calendario.get(mes).keySet() ) {
                    System.out.printf ("%s: %s\n", 
                            diaSemana, 
                            calendario.get(mes).get(diaSemana));
                }
             }

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}