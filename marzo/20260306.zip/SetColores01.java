
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;


public class SetColores01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            String arrayColores[] = {"NGR", "BLA", "ROJ", "VER", "AMR", "AZL"};

            // Variables de entrada
            Set<String> c1, c2;



            // Variables de salida
            Set<String> union, interseccion, dif1, dif2;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CONJUNTOS DE COLORES");
            System.out.println("--------------------");
            System.out.println(" ");
            
            // Reservamos espacio para c1 y c2
            c1 = new HashSet<>();
            c2 = new HashSet<>();
            
            // Rellenamos aleatoriamente c1
            while ( c1.size() < 3) {
                String colorRandom = arrayColores[(int)(Math.random()*arrayColores.length)];
                c1.add(colorRandom);
            }
            
            // Rellenamos aleatoriamente c2
            while ( c2.size() < 3) {
                String colorRandom = arrayColores[(int)(Math.random()*arrayColores.length)];
                c2.add(colorRandom);
            }
            
            System.out.println ("Valores iniciales: ");
            System.out.printf ("c1: %s\n", c1);
            System.out.printf ("c2: %s\n", c2);
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Union
            union = new HashSet<>(c1);
            union.addAll(c2);

            // Intersecci�n
            interseccion = new HashSet<>(c1);
            interseccion.retainAll(c2);
            
            // Diferencia c1 - c2
            dif1 = new HashSet<>(c1);
            dif1.removeAll(c2);
            
            // Diferencia c2 - c1
            dif2 = new HashSet<>(c2);
            dif2.removeAll(c1);
            
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("c1: %s\n", c1);
            System.out.printf ("c2: %s\n", c2);
            System.out.printf ("union: %s\n", union);
            System.out.printf ("intersecci�n: %s\n", interseccion);
            System.out.printf ("diferencia c1 - c2: %s\n", dif1);
            System.out.printf ("diferencia c2 - c1: %s\n", dif2);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}