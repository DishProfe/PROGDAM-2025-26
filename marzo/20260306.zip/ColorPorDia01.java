
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.time.LocalDate;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;


public class ColorPorDia01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            String arrayColores[] = {"NGR", "BLA", "ROJ", "VER", "AMR", "AZL"};

            // Variables de entrada




            // Variables de salida
            Map<LocalDate, String> mapDiaColor;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COLOR POR D�A");
            System.out.println("-------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            mapDiaColor = new HashMap<>();
            
            int year = LocalDate.now().getYear();
            LocalDate fechaInicial = LocalDate.of (year, 3, 1);
            
            
            
            for ( int contador=0 ; contador < 5 ; contador++ ) {

                LocalDate fecha = fechaInicial.plusDays(contador);
                String colorRandom;
                do  {
                    colorRandom = arrayColores[(int)(Math.random()*arrayColores.length)];
                } while ( mapDiaColor.containsValue(colorRandom) );    
                mapDiaColor.put(fecha, colorRandom);
                
            }

//            mapDiaColor.clear();
//            Set<String> sacoAleatorios = new LinkedHashSet<>();
//           
//            // Rellenamos aleatoriamente el saco
//            while ( sacoAleatorios.size() < 5) {
//                String colorRandom = arrayColores[(int)(Math.random()*arrayColores.length)];
//                sacoAleatorios.add(colorRandom);
//            }
//
//            Iterator<String> it = sacoAleatorios.iterator();
//            int contador = 0;
//            while ( it.hasNext() )  {
//                String color = it.next();
//                mapDiaColor.put ( fechaInicial.plusDays(contador++), color);
//            }
//            
            
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Asignaci�n fecha->color: %s\n", mapDiaColor);
            for ( LocalDate fecha : mapDiaColor.keySet() ) {
                System.out.printf ("%s -> %s\n", fecha, mapDiaColor.get(fecha));
            }            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}