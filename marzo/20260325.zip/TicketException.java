/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplos2026;

/**
 *
 * @author diosdado
 */
public class TicketException extends Exception {
    
    public TicketException ( String message ) {
        super (message);
    }
    
}
