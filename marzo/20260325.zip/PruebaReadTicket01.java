
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;


public class PruebaReadTicket01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            String FILE_NAME="ticket.txt";
            String FOLDER = "data";
            String PATH= FOLDER + "/" + FILE_NAME;

            // Variables de entrada
            TicketCompra ticket = null;



            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("PRUEBA DE LECTURA DE UN TICKET DE UN ARCHIVO DE TEXTO");
            System.out.println("-----------------------------------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            
            try {
                ticket = TicketCompra.readTicket(PATH);
            } catch ( FileNotFoundException ex) {
                System.out.printf ("Error: %s\n", ex);    
            } catch ( IOException ex ) {
                System.out.printf ("Error: %s\n", ex);                        
            } catch ( TicketException ex ) {
                 System.out.printf ("Error: %s\n", ex);                   
            }
            


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            if ( ticket != null ) {
                System.out.printf ("Ticket leido: \n%s\n", ticket);
            }


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}