package ejemplos2026;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Representa el ticket de la compra realizada por un cliente.
 * Contiene información sobre fecha y hora, así como el vendedor, los productos adquiridos, 
 * cantidades, precios, etc.
 * El registro de los productos comprados, junto con la cantidad y el precio se almacenan en forma de lista 
 * de objetos <code>Compra</code>, es decir, una lista de ternas <code>(producto, precio, unidades)</code>.
 * @author profe + nombre alumno/a
 */
public class TicketCompra {
    private static final  DateTimeFormatter FORMATO_FECHA_HORA = DateTimeFormatter.ofPattern("dd/MM/YYYY HH:mm:ss");
    private final String vendedor;
    private final LocalDateTime instante;
    private final List<Compra> listaCompra;


    // --------------------------------------------------
    //               CONSTRUCTORES
    // --------------------------------------------------
    /**
     * Constructor para instanciar un ticket a partir de un vendedor, un instante (timestamp)
     * y una lista de objetos Compra.
     * Si la lista pasada es <code>null</code>, se creará una lista vacía.
     * @param vendedor vendedor que atendió en la compra
     * @param instante momento de la compra (fecha y hora)
     * @param listaCompra lista de la compra. Lista de objetos Compra, ternas del tipo (producto, precio, unidades)
     */
    public TicketCompra (String vendedor, LocalDateTime instante, List<Compra> listaCompra) {
        this.vendedor = vendedor;
        this.instante = instante;
        if (listaCompra != null) {
            this.listaCompra = listaCompra;
        } else {
            this.listaCompra = new LinkedList<>();
        }
    }
    
    /**
     * Constructor para instanciar un ticket a partir de un vendedor y un instante (timestamp).
     * Inicialmente la lista de objetos compra estará vacía.
     * @param vendedor vendedor que atendió en la compra
     * @param instante momento de la compra (fecha y hora)
     */
    public TicketCompra (String vendedor, LocalDateTime instante) {
        this (vendedor, instante, null);
    }
    
    /**
     * Constructor para instanciar un ticket a partir de un vendedor y una lista de compras.
     * El momento de la compra se considerará el actual.
     * @param vendedor vendedor que atendió en la compra
     * @param listaCompra lista de la compra. Lista de objetos Compra, ternas del tipo (producto, precio, unidades)
     */
    public TicketCompra (String vendedor, List<Compra> listaCompra) {
        this (vendedor, LocalDateTime.now(), listaCompra);
    }
    
    /**
     * Constructor para instanciar un ticket a partir de un vendedor.
     * El momento de la compra se considerará el actual.
     * Inicialmente la lista de objetos compra estará vacía.
     * @param vendedor vendedor que atendió en la compra
     */
    public TicketCompra (String vendedor) {
        this (vendedor, LocalDateTime.now());
    }
    
    
    
    public static TicketCompra readTicket (String filename) throws FileNotFoundException, IOException, TicketException {
        
        String vendedor;
        String textoInstante;
        LocalDateTime instante = null;
        List<Compra> listaCompra = new LinkedList<>();
        
        TicketCompra ticket = null;
        
        try {
            // Abrimos el archivo binario para lectura
            FileReader fr = new FileReader (filename); // Establecemos v��nculo entre mi programa y un archivo del s.o.
            BufferedReader entrada = new BufferedReader(fr); // A�adimos capa facilitar la lectura de textos del archivo


            // Leemos cada uno de las l�neas del archivo de texto
            // y los vamos incluyendo en el Set
            String linea;
            
            int contador= 0 ;

            // La primera l�nea es el vendedor
            vendedor = entrada.readLine();
            
            // La segunda l�nea es el instante de venta
            textoInstante = entrada.readLine();
            
            try {
                instante = LocalDateTime.parse (textoInstante);
            } catch ( DateTimeParseException ex) {
                throw new TicketException (
                        String.format ("Instante no v�lido: %s", textoInstante )
                );
            }        
                
            while ( (linea = entrada.readLine()) != null) {
                System.out.printf ("L�nea le�da: %s\n", linea);
                contador++;

                //Pattern pattern = Pattern.compile ("[A-Za-z0-9 ]+, [0-9]+.[0-9]+, [0-9]+");
                String[] arrayElementos = linea.split (",");
                
                boolean compraValida = true;
                String producto = arrayElementos[0];
                double precio = 0.0;
                try {
                    precio = Double.parseDouble(arrayElementos[1].trim()); 
                } catch ( NumberFormatException ex) {
                    compraValida = false;
                }
                int cantidad = 0;
                try {
                    cantidad = Integer.parseInt(arrayElementos[2].trim());
                } catch ( NumberFormatException ex) {
                    compraValida = false;
                }

                if ( compraValida ) {
                    listaCompra.add ( new Compra (producto, precio, cantidad) );
                }
            }
            
            
        } catch (FileNotFoundException ex) {
            throw ex;
        } catch (IOException ex) {
            throw ex;
        }
        
        
        // Creamos el ticket con la informaci�n leida del archivo
        ticket = new TicketCompra ( vendedor, instante, listaCompra );
        
        return ticket;
    }
    
    
    
    // --------------------------------------------------
    //                    GETTERS
    // --------------------------------------------------
    /**
     * Obtiene el vendedor que atendió en la compra
     * @return vendedor que atendió en la compra
     */    
    
    
    // --------------------------------------------------
    //                    GETTERS
    // --------------------------------------------------
    /**
     * Obtiene el vendedor que atendió en la compra
     * @return vendedor que atendió en la compra
     */
    public String getVendedor() {
        return this.vendedor;
    }

    /**
     * Obtiene el instante (<code>timestamp</code> o fecha y hora) en el que se realizó la compra.
     * @return instante de la compra
     */
    public LocalDateTime getInstante() {
        return instante;
    }

    /**
     * Obtiene la lista completa de los objetos <code>Compra</code> del ticket.
     * @return lista de objetos <code>Compra</code>
     */
    public List<Compra> getListaCompra() {
        return listaCompra;
    }
    

    // --------------------------------------------------
    //                   TOSTRING
    // --------------------------------------------------
    /**
     * Representación textual de un ticket de compra.
     * Tendrá el formato {vendedor, instante, numArticulos, importe, [lista de tickets]}.
     * @return representación textual del ticket.
     */
    @Override
    public String toString() {
        return String.format ("{%s, %s, %d, %6.2f, %s}", 
                this.vendedor, 
                this.instante.format(FORMATO_FECHA_HORA), 
                this.getNumArticulos(),
                this.getImporte(),
                this.listaCompra);
    }
    
    // --------------------------------------------------
    // MÉTODOS QUE DEBEN SER IMPLEMETADOS POR EL ALUMNADO
    // --------------------------------------------------
    
    // Ejercicio 1.1
    // -------------
    /**
     * Devuelve el importe total de la compra. Tiene en cuenta todos los productos
     * comprados, su cantidad y su precio.
     * @return importe total de la compra
     */
    public double getImporte() {
        
        double importe = 0.0;
        
        for ( Compra compra : this.listaCompra ) {
            
            importe += compra.getImporte();
            
        }
        return importe;
    }

    // Ejercicio 1.2
    // -------------
    /**
     * Devuelve el total de artículos adquiridos en la compra. Tiene en cuenta la cantidad de 
     * cada uno de los productos comprados.
     * @return importe total de la compra
     */
    public int getNumArticulos() {

        int numArticulos = 0;
        for ( int indice=0 ; indice < this.listaCompra.size(); indice++ ) {
            numArticulos += this.listaCompra.get(indice).getUnidades();
        }
        return numArticulos;

    }
    
    /*
    public void writeTicket ( String filename ) throws FileNotFoundException, IOException {
        
        FileWriter fw = null; // V��nculo entre mi programa y un archivo el s.o.
        PrintWriter salida = null; // Capa sobre el fw con el que escribo textos

        try {
            // Abrimos el archivo de texto para escritura
            fw = new FileWriter (filename); // Establecemos v��nculo entre mi programa y un archivo del s.o.
            salida = new PrintWriter (fw); // A�adimos capa facilitar la escritura de textos en el archivo

            salida.print (this.toString());

            
        } catch (FileNotFoundException ex) {
            throw ex;
        } catch (IOException ex) {
            throw ex;
        }
        
        salida.close();
        
    }
    */
    
    public void writeTicket ( String filename ) throws FileNotFoundException, IOException {
        
        FileWriter fw = null; // V��nculo entre mi programa y un archivo el s.o.
        PrintWriter salida = null; // Capa sobre el fw con el que escribo textos

        try {
            // Abrimos el archivo de texto para escritura
            fw = new FileWriter (filename); // Establecemos v��nculo entre mi programa y un archivo del s.o.
            salida = new PrintWriter (fw); // A�adimos capa facilitar la escritura de textos en el archivo

            salida.println (this.vendedor);
            salida.println (this.instante);
            for ( Compra compra : this.getListaCompra() ) {
                salida.printf ("%s, %s, %s\n", 
                        compra.getProducto(), 
                        compra.getPrecio(),
                        compra.getUnidades()
                );
            }

            
        } catch (FileNotFoundException ex) {
            throw ex;
        } catch (IOException ex) {
            throw ex;
        }
        
        salida.close();
        
    }    
    
    
    
    
}
