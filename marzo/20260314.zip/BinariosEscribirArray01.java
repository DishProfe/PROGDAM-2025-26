/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplos2026;

import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;
/**
 *
 * @author profe
 */


public class BinariosEscribirArray01 {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        FileOutputStream fos = null;
        DataOutputStream salida = null;

        // Leemos un array 2D de double
        double[][] tabla;
        int numFilas, numColumnas, fila, columna;
        do{
            System.out.print("N�mero de filas: ");
            numFilas = teclado.nextInt();
        }while(numFilas<=0);
        do{
            System.out.print("N�mero de columnas: ");
            numColumnas = teclado.nextInt();
        }while(numColumnas<=0);

        tabla = new double[numFilas][numColumnas]; //se crea la matriz
       
        for (fila = 0; fila < numFilas; fila++) {     //lectura de datos por teclado
            for (columna = 0; columna < numColumnas; columna++) {
                System.out.print("matriz[" + fila + "][" + columna + "]: ");
                tabla[fila][columna] = teclado.nextDouble();
            }
        }
        
        
        try {
            //Creamos el fichero de salida
            fos = new FileOutputStream("./array.dat");
            salida = new DataOutputStream(fos);

           
           //Escribimos el array en el fichero en un orden determinado
            for (fila = 0; fila < numFilas; fila++) {
                for (columna = 0; columna < numColumnas; columna++) {
                    salida.writeDouble(tabla[fila][columna]);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        } 
        
        
        // Cerramos los streams
        try {
            if (fos != null) {
                fos.close();
            }
            if (salida != null) {
                salida.close();
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}

