package ejemplos2026;

import ejemplosunidad07.*;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author profe
 */

public class BinariosLeerArray021 {
    public static void main(String[] args) {
        
        FileInputStream fis = null;
        DataInputStream entrada = null;
        
        int filas=0, columnas=0, i, j;
        double[][] tabla= null;
        
        try {
            // Creamos los streams
            fis = new FileInputStream("./array.dat");
            entrada = new DataInputStream(fis);
            
            // Obtenemos filas y columnas
            filas = entrada.readInt();  //se lee el primer entero del fichero
            columnas = entrada.readInt();//se lee el segundo entero del fichero
            
            // Reservamos espacio para el array
            tabla= new double[filas][columnas];

            
            // Vamos "recorriendo" el array y lo "rellenamos" con lo que encontremos en el archivo
            for (i = 0; i < filas; i++) {
                for (j = 0; j < columnas; j++) {  // se leen los double y se muestran por pantalla
                    tabla[i][j]= entrada.readDouble();
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (EOFException e) {
            System.out.println("Fin de fichero");
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        
        // Cerramos los streams
        try {
            if (fis != null) {
                fis.close();
            }
            if (entrada != null) {
                entrada.close();
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }        

        // Salida
        for (i = 0; i < filas; i++) {
            for (j = 0; j < columnas; j++) {  // se leen los double y se muestran por pantalla
                System.out.printf("%8.2f",tabla[i][j]);
            }
            System.out.println();
        }        

        
        

    }
}
