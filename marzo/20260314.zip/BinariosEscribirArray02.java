/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplos2026;

import ejemplosunidad07.*;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;
/**
 *
 * @author profe
 */


public class BinariosEscribirArray02 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        FileOutputStream fos = null;
        DataOutputStream salida = null;

        // Leemos un array 2D de double
        double[][] tabla;
        int numFilas, numColumnas, i, j;
        do{
            System.out.print("N�mero de filas: ");
            numFilas = sc.nextInt();
        }while(numFilas<=0);
        do{
            System.out.print("N�mero de columnas: ");
            numColumnas = sc.nextInt();
        }while(numColumnas<=0);

        tabla = new double[numFilas][numColumnas]; //se crea la matriz
       
        for (i = 0; i < numFilas; i++) {     //lectura de datos por teclado
            for (j = 0; j < numColumnas; j++) {
                System.out.print("matriz[" + i + "][" + j + "]: ");
                tabla[i][j] = sc.nextDouble();
            }
        }
        
        
        try {
            //Creamos el fichero de salida
            fos = new FileOutputStream("./array.dat");
            salida = new DataOutputStream(fos);

            //Escribimos el n�mero de filas y columnas en el fichero
            salida.writeInt(numFilas);
            salida.writeInt(numColumnas);
           
           //Escribimos el array en el fichero en un orden determinado
            for (i = 0; i < numFilas; i++) {
                for (j = 0; j < numColumnas; j++) {
                    salida.writeDouble(tabla[i][j]);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        } 
        
        
        // Cerramos los streams
        try {
            if (fos != null) {
                fos.close();
            }
            if (salida != null) {
                salida.close();
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}

