package ejemplos2026;


/**
 * Clase que encapsula la informaci�n de un equipo.
 * @author profe
 */
public class Equipo implements Comparable<Equipo> {    
    private final String nombreEquipo;
    private final String ciudad;
    
    /**
    * Constructor de equipo.
    * @param nombreEquipo Nombre del equipo.
    * @param ciudad Ciudad del equipo.
    */
    public Equipo (String nombreEquipo, String ciudad)
    {
        this.nombreEquipo=nombreEquipo;
        this.ciudad=ciudad;
    }
   
    /**
     * Obtiene el nombre del equipo.
     * @return Nombre del equipo.
     */
    public String getNombreEquipo() {
        return this.nombreEquipo;
    }

        /**
     * Obtiene la ciudad del equipo.
     * @return Ciudad del equipo.
     */
    public String getCiudadEquipo() {
        return this.ciudad;
    }

    /**
     * Representaci�n del equipo en formato texto.
     * @return Nombre del equipo y ciudad del equipo en formato texto.
     */
    @Override
    public String toString()
    {
        StringBuilder cad=new StringBuilder();
        cad.append(nombreEquipo);
        cad.append(" (").append(ciudad).append(")");
        return cad.toString();
    }
    
    /**
     * Comparaci�n con otro equipo: a trav�s de sus nombres
     * @param otroEquipo equipo con el que se realiza la comparación
     * @return valor negativo, cero o positivo, dependiendo de su ordenación, en orden ascendente, por nombre de equipo
     */
    @Override
    public int compareTo (Equipo otroEquipo) {
        return this.nombreEquipo.compareTo(otroEquipo.nombreEquipo);
    }
    
    
}
