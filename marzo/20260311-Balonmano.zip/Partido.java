package ejemplos2026;

import java.time.LocalDate;

/**
 * Clase que encapsula los datos de un partido.
 * @author profe
 */
public class Partido implements Comparable<Partido> {
    
    private Equipo local;
    private Equipo visitante;
    private int puntosLocal;
    private int puntosVisitante;
    private LocalDate fecha;        
    
    /**
     * Constructor de la clase partido.
     * @param local Equipo que juega como local.
     * @param visitante Equipo que juega como visitante.
     * @param puntosLocal Puntos del equipo local en el partido.
     * @param puntosVisitante Puntos del equipo visitante en el partido.
     * @param fecha Fecha en la que se disput� el partido.
     * @throws IllegalArgumentException Excepci�n que se lanza cuando pasa
     * algo de lo siguiente: equipo local o visitante son null, los puntos
     * son negativos (alguno de ellos), la fecha es null o anterior a 1/1/1990.
     */
    public Partido (Equipo local, Equipo visitante, int puntosLocal, int puntosVisitante, LocalDate fecha) throws IllegalArgumentException
    {
        if (local==null || visitante==null ||
            puntosLocal<0 || puntosVisitante<0 ||
            fecha==null || fecha.isBefore(LocalDate.of(1990,1,1)) ||
                    fecha.isAfter(LocalDate.now()) )
        {
            throw new IllegalArgumentException("Los datos de creaci�n del partido son err�neos.");
        }
        this.local=local;
        this.visitante=visitante;
        this.puntosLocal=puntosLocal;
        this.puntosVisitante=puntosVisitante;
        this.fecha= fecha;
    }
    
    /**
     * Obtiene el nombre del equipo local.
     * @return nombre del equipo local.
     */
    public String nombreEquipoLocal()
    {
        return local.getNombreEquipo();
    }
    
    /**
     * Obtiene el nombre del equipo visitante.
     * @return nombre del equipo visitante.
     */
    public String nombreEquipoVisitante()
    {
        return this.visitante.getNombreEquipo();
    }
    
    /**
     * Obtiene el nombre de la ciudad donde se celebr� el partido.
     * Es la ciudad del equipo local.
     * @return ciudad donde se celebr� el partido
     */
    public String nombreCiudad()
    {
        return this.local.getCiudadEquipo();
    }    
    
    
    public LocalDate getFecha() {
        return this.fecha;
    }
    
    public int getPuntosLocal() {
        return this.puntosLocal;
    }
    
    public int getPuntosVisitante() {
        return this.puntosVisitante;
    }
    
    /**
     * Calcula cual es el equipo ganador.
     * @return El equipo que ha ganado el encuentro o null si el encuentro
     * result� en empate.
     */
    public Equipo equipoGanador()
    {
        Equipo ganador=null;
        if (puntosLocal<puntosVisitante) {
            ganador=visitante;
        } else if (puntosLocal>puntosVisitante) {
            ganador=local;
        }
        return ganador;        
    }
    
    /**
     * M�todo que retorna una versi�n en cadena del partido, que incluye:
     * - fecha del partido.
     * - nombre del equipo visitante y sus puntos.
     * - nombre del equipo local y sus puntos.
     * @return Cadena con la informaci�n del partido.
     */
    @Override
    public String toString()
    {
        return String.format("%s - %s %d - %s %d", 
                    this.fecha,
                    this.local.getNombreEquipo(),
                    this.puntosLocal,
                    this.visitante.getNombreEquipo(),
                    this.puntosVisitante);
    }


    /**
     * M�todo de comparaci�n de partidos (por fecha, por equipo local y por equipo visitante)
     * @param otroPartido partido con el que se compara
     * @return valor negativo, cero o positivo, dependiendo de su ordenaci�n, en orden ascendente, por fecha, nombre de equipo local o bien nombre de equipo visitante (en ese orden)
     */
    @Override
    public int compareTo (Partido otroPartido) {
        int comparacion= this.fecha.compareTo(otroPartido.getFecha());
        if (comparacion == 0) {
            comparacion= this.nombreEquipoLocal().compareTo(otroPartido.nombreEquipoLocal());
            if (comparacion == 0) {
                comparacion= this.nombreEquipoVisitante().compareTo(otroPartido.nombreEquipoVisitante());                
            }   
        }
        return comparacion;
    }
 
        
/*    @Override
    public int compareTo (Partido otroPartido) {
        int numGolesThis= this.puntosLocal + this.puntosVisitante;
        int numGolesOtroPartido= otroPartido.puntosLocal + otroPartido.puntosVisitante;
        
        return numGolesThis - numGolesOtroPartido;
    }
 */   
    
}
