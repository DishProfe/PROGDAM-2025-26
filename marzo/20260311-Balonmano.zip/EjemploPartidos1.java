package ejemplos2026;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 *
 * @author profe
 */
public class EjemploPartidos1 {

    public static void main(String[] args) {
        
        // Creamos algunos equipos
        System.out.println("1.- Creaci�n de equipos:");
        System.out.println("------------------------");
        
        Equipo zuazo = new Equipo("Zuazo", "Barakaldo");
        System.out.println("Creado equipo: "+zuazo);
        Equipo aula = new Equipo("Aula", "Valladolid");
        System.out.println("Creado equipo: "+aula);
        Equipo malaga = new Equipo("M�laga", "M�laga");
        System.out.println("Creado equipo: "+malaga);
        Equipo castellon = new Equipo("Castell�n", "Castell�n");
        System.out.println("Creado equipo: "+castellon);
                                               
        // Creamos algunos partidos
        System.out.println("\n2.- Creaci�n de los partidos:");
        System.out.println("-----------------------------");
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("d-M-y", Locale.getDefault());
        Partido p1 = new Partido(zuazo, aula, 17, 14, LocalDate.parse("18-12-2017", dtf));
        System.out.println(p1);
        Partido p2 = new Partido(aula, zuazo, 10, 16, LocalDate.parse("6-12-2017", dtf));
        System.out.println(p2);
        Partido p3 = new Partido(aula, malaga, 13, 19, LocalDate.parse("22-12-2017", dtf));
        System.out.println(p3);
        Partido p4 = new Partido(malaga, aula, 23, 11, LocalDate.parse("7-12-2017", dtf));
        System.out.println(p4);
        Partido p5 = new Partido(malaga, castellon, 13, 13, LocalDate.parse("8-12-2017", dtf));
        System.out.println(p5);
        Partido p6 = new Partido(castellon, malaga, 17, 18, LocalDate.parse("9-12-2017", dtf));
        System.out.println(p6);
        Partido p7 = new Partido(castellon, zuazo, 13, 18, LocalDate.parse("10-12-2017", dtf));
        System.out.println(p7);
        Partido p8 = new Partido(zuazo, castellon, 18, 9, LocalDate.parse("16-12-2017", dtf));
        System.out.println(p8);
        Partido p9 = new Partido(zuazo, malaga, 11, 11, LocalDate.parse("17-12-2017", dtf));
        System.out.println(p9);
        System.out.println();
        

    }
}
