package ejemplos2026;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 *
 * @author profe
 */
public class EjemploPartidos2 {

    public static void main(String[] args) {
        
        // Creamos algunos equipos
        System.out.println("1.- Creaci�n de equipos:");
        System.out.println("------------------------");
        
        Equipo zuazo = new Equipo("Zuazo", "Barakaldo");
        System.out.println("Creado equipo: "+zuazo);
        Equipo aula = new Equipo("Aula", "Valladolid");
        System.out.println("Creado equipo: "+aula);
        Equipo malaga = new Equipo("M�laga", "M�laga");
        System.out.println("Creado equipo: "+malaga);
        Equipo castellon = new Equipo("Castell�n", "Castell�n");
        System.out.println("Creado equipo: "+castellon);
                                               
        // Creamos algunos partidos
        System.out.println("\n2.- Creaci�n de los partidos:");
        System.out.println("-----------------------------");
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("d-M-y", Locale.getDefault());
        Partido p1 = new Partido(zuazo, aula, 17, 14, LocalDate.parse("18-12-2017", dtf));
        System.out.println(p1);
        Partido p2 = new Partido(aula, zuazo, 10, 16, LocalDate.parse("6-12-2017", dtf));
        System.out.println(p2);
        Partido p3 = new Partido(aula, malaga, 13, 19, LocalDate.parse("22-12-2017", dtf));
        System.out.println(p3);
        Partido p4 = new Partido(malaga, aula, 23, 11, LocalDate.parse("7-12-2017", dtf));
        System.out.println(p4);
        Partido p5 = new Partido(malaga, castellon, 13, 13, LocalDate.parse("8-12-2017", dtf));
        System.out.println(p5);
        Partido p6 = new Partido(castellon, malaga, 17, 18, LocalDate.parse("9-12-2017", dtf));
        System.out.println(p6);
        Partido p7 = new Partido(castellon, zuazo, 13, 18, LocalDate.parse("10-12-2017", dtf));
        System.out.println(p7);
        Partido p8 = new Partido(zuazo, castellon, 18, 9, LocalDate.parse("16-12-2017", dtf));
        System.out.println(p8);
        Partido p9 = new Partido(zuazo, malaga, 11, 11, LocalDate.parse("17-12-2017", dtf));
        System.out.println(p9);
        System.out.println();
        
        // Creamos una temporada        
        Temporada t1 = new Temporada("Divisi�n de Honor Femenina 2017/2018");
        
        // Añadimos equipos a la temporada        
        t1.aniadirEquipo(zuazo);
        t1.aniadirEquipo(aula);
        t1.aniadirEquipo(malaga);
        t1.aniadirEquipo(castellon);
                
        System.out.println("\n3.- Los equipos insertados en la temporada son:");
        System.out.println("------------------------------------------------");
        for (Equipo eq: t1.listaDeEquipos()) {
            System.out.println (eq);
        }
        System.out.println();

        // Insertamos partidos en la temporada
        t1.insertarPartido(p1);
        t1.insertarPartido(p2);
        t1.insertarPartido(p3);
        t1.insertarPartido(p4);
        t1.insertarPartido(p5);
        t1.insertarPartido(p6);
        t1.insertarPartido(p7);
        t1.insertarPartido(p8);
        t1.insertarPartido(p9);

        // Calculamos los puntos de cada equipo
        System.out.println("\n4.- Los puntos de cada equipo son:");
        System.out.println("------------------------------------");
        for (Equipo eq: t1.listaDeEquipos()) {
            System.out.println (eq.getNombreEquipo() + ": " + t1.calcularPuntosEquipo(eq));
        }
        System.out.println();
                
        // Mostramos la lista de partidos de la temporada
        System.out.println("\n5.- Lista de partidos"); 
        System.out.println("-----------------------");
        System.out.println(t1.partidosToString());
        
        // Mostramos la clasificaci�n de la temporada
        System.out.println("\n6.- Clasificaci�n");
        System.out.println("-------------------");
        System.out.println(t1.toString());       

    }
}