package ejemplos2026;

/**
 * Programa XXX
 *
 * @author diosdado
 */
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PruebaEquipo04 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------
        // Constantes
        String FILE_NAME = "equipos2.txt";
        String FOLDER = "data";
        String PATH = FOLDER + "/" + FILE_NAME;

        // Variables de entrada
        Set<Equipo> setEquipos;

        // Variables de salida
        // Variables auxiliares
        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("PRUEBA LECTURA DE EQUIPOS A PARTIR DE ARCHIVOS DE TEXTO");
        System.out.println("-------------------------------------------------------");
        System.out.println(" ");

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        setEquipos = new LinkedHashSet<>();

        System.out.println("Leyendo equipos de disco...");

        try {
            // Abrimos el archivo binario para lectura
            FileReader fr = new FileReader(PATH); // Establecemos v��nculo entre mi programa y un archivo del s.o.
            BufferedReader entrada = new BufferedReader(fr); // A�adimos capa facilitar la lectura de textos del archivo

            // Leemos cada uno de las l�neas del archivo de texto
            // y los vamos incluyendo en el Set
            String linea;
            while ((linea = entrada.readLine()) != null) {

                Pattern pattern = Pattern.compile(" *([A-Z][A-Za-z ]+) *, *([A-Z][A-Za-z ]+)");
                Matcher matcher = pattern.matcher(linea);

                if (matcher.matches()) {

                    String nombre = matcher.group(1).trim();
                    String ciudad = matcher.group(2).trim();

                    Equipo eq = new Equipo(nombre, ciudad);
                    setEquipos.add(eq);

                } else {
                    System.out.printf("Formato incorrecto: %s\n", linea);
                }

            }

        } catch (FileNotFoundException ex) {
            System.out.printf("Error :%s\n");
        } catch (IOException ex) {
            System.out.printf("Error :%s\n");
        }

        //---------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");
        System.out.println("Equipos le�dos de disco: ");
        for ( Equipo equipo : setEquipos ) {
            System.out.printf ("%s\n", equipo);
        }
        
        System.out.println();
        System.out.println("Fin del programa.");

    }

}
