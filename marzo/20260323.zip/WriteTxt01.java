package ejemplos2026;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 * Programa
 */
public class WriteTxt01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------
        // Constantes
            String FILE_NAME="textos.txt";
            String FOLDER = "data";
            String PATH= FOLDER + "/" + FILE_NAME;
        
        // Variables de entrada
        List<String> listaTextos;
        FileWriter fw = null; // V��nculo entre mi programa y un archivo el s.o.
        PrintWriter salida = null; // Capa sobre el fw con el que escribo textos


        // Variables de salida
        
        // Variables auxiliares
        boolean lecturaCorrecta = true;

        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("LECTURA DE L�NEAS EN ARCHIVO DE TEXTO");
        System.out.println("-------------------------------------");
        System.out.println(" ");

        listaTextos = new LinkedList<>();
        
        listaTextos.add ("Uno");
        listaTextos.add ("Dos");
        listaTextos.add ("L�nea tres");
        listaTextos.add ("L�nea 4");
        listaTextos.add ("�ltima l�nea");
        
        
        
        try {
            // Abrimos el archivo de texto para escritura
            fw = new FileWriter (PATH); // Establecemos v��nculo entre mi programa y un archivo del s.o.
            salida = new PrintWriter (fw); // A�adimos capa facilitar la escritura de textos en el archivo


            // Vamos recorriendo la lista de textos y los vamos escribiendo
            // cada uno en una l�nea del archivo
            
            String linea;
            
            for ( int indice = 0 ; indice < listaTextos.size() ; indice++ ) {
                linea = listaTextos.get(indice);
                System.out.printf ("Escribiendo l�nea: %s\n", linea);

                salida.println(linea);
            }
            


            System.out.println("Escritura del contenido de la lista en el archivo finalizda.");
            
            
            
            
        } catch (FileNotFoundException ex) {
            System.out.printf("Error: %s\n", ex.getMessage());
            lecturaCorrecta = false;
        } catch (IOException ex) {
            System.out.printf("Error: %s\n", ex.getMessage());
            lecturaCorrecta = false;
        }

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        // Cerramos el archivo
        try {
            if (salida != null) {
                salida.close();
                if (fw != null) {
                    fw.close();
                }
            }
        } catch (IOException ex) {
            System.out.printf("Error al intentar cerrar el archivo: %s\n", ex.getMessage());
        }        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------


        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");
        System.out.printf ("Contenido leido del archivo de texto: \n%s\n", listaTextos);

        System.out.println();
        System.out.println("Fin del programa.");

    }

}
