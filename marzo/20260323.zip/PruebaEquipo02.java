
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;


public class PruebaEquipo02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            String FILE_NAME="e1.txt";
            String FOLDER = "data";
            String PATH= FOLDER + "/" + FILE_NAME;


            // Variables de entrada
            Equipo e1 = null, e2 = null;



            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("PRUEBA LECTURA DE EQUIPOS A PARTIR DE ARCHIVOS DE TEXTO");
            System.out.println("-------------------------------------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            System.out.println ("Leyendo equipos de disco...");
            
            try {

                e1 = Equipo.ofEquipo(FOLDER + "/" + "equipo1.txt");
                e2 = Equipo.ofEquipo(FOLDER + "/" + "equipo2.txt");


            } catch ( FileNotFoundException ex ) {
                System.out.printf("Error: %s\n", ex.getMessage());                
            } catch ( IOException ex) {
                System.out.printf("Error: %s\n", ex.getMessage());        
            } catch ( IllegalArgumentException ex){
                System.out.printf("Error: %s\n", ex.getMessage());                        
            } 

            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Equipos le�dos de disco: ");
            System.out.printf ("e1=  %s\n", e1);
            System.out.printf ("e2=  %s\n", e2);
            

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}