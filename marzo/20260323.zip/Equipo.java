package ejemplos2026;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Clase que encapsula la información de un equipo.
 * @author profe
 */
public class Equipo implements Serializable {    
    private final String nombreEquipo;
    private final String ciudad;
    
//The serialization runtime associates with each serializable class a 
//version number, called a serialVersionUID, which is used during 
//deserialization to verify that the sender and receiver of
//a serialized object have loaded classes for that object 
//that are compatible with respect to serialization.
//If the receiver has loaded a class for the object that has a different 
//serialVersionUID than that of the corresponding sender's class, 
//then deserialization will result in an InvalidClassException.    
private static final long serialVersionUID = 42L;
    
    /**
    * Constructor de equipo.
    * @param nombreEquipo Nombre del equipo.
    * @param ciudad Ciudad del equipo.
    */
    public Equipo (String nombreEquipo, String ciudad)
    {
        this.nombreEquipo=nombreEquipo;
        this.ciudad=ciudad;
    }
   
    public Equipo (Equipo equipo) {
        this (equipo.nombreEquipo, equipo.ciudad);
    }
    
    
    public static Equipo ofEquipo (Equipo equipo) {
        return new Equipo (equipo);
    }
    
    

    public static Equipo ofEquipo (String filename) throws FileNotFoundException, IOException, IllegalArgumentException {

        Equipo eq;
        
        try {
            // Abrimos el archivo binario para lectura
            FileReader fr = new FileReader (filename); // Establecemos v��nculo entre mi programa y un archivo del s.o.
            BufferedReader entrada = new BufferedReader(fr); // A�adimos capa facilitar la lectura de textos del archivo


            // Leemos cada uno de las l�neas del archivo de texto
            // y los vamos incluyendo en el Set
            String linea = entrada.readLine();
            
            Pattern pattern = Pattern.compile ("([A-Z][A-Za-z ]+) \\(([A-Z][A-Za-z ]+)\\)");
            Matcher matcher = pattern.matcher(linea);
            
            if ( matcher.matches() ) {
                
                String nombre = matcher.group(1);
                String ciudad = matcher.group(2);

                eq = new Equipo (nombre, ciudad);
                
            } else {
                throw new IllegalArgumentException ("Formato incorrecto");
            }
            
        
        } catch (FileNotFoundException ex) {
            throw ex;
        } catch (IOException ex) {        
            throw ex;
        }
        
        return eq;
        
    }





    
    public static Equipo CargarEquipo (String filename) 
            throws FileNotFoundException, IOException, ClassNotFoundException {


        Equipo equipo = null;
        
        try {
            // Abrimos el archivo para leer
            FileInputStream fis = new FileInputStream (filename);
            
            // Pasamos ese FileOutputStream a un ObjectOutputStream 
            // para poder "leer" objetos
            ObjectInputStream entrada = new ObjectInputStream(fis);
            
            // Leemos el objeto de disco
            equipo = (Equipo) entrada.readObject();

            
            
        } catch (FileNotFoundException ex) {
            throw ex;
        } catch (IOException | ClassNotFoundException ex) {        
            throw ex;
        }

        // Y lo devolvemos
        return equipo;
        
    }
    
    
    
    /**
     * Obtiene el nombre del equipo.
     * @return Nombre del equipo.
     */
    public String getNombreEquipo() {
        return this.nombreEquipo;
    }

        /**
     * Obtiene la ciudad del equipo.
     * @return Ciudad del equipo.
     */
    public String getCiudadEquipo() {
        return this.ciudad;
    }

    /**
     * Representación del equipo en formato texto.
     * @return Nombre del equipo y ciudad del equipo en formato texto.
     */
    @Override
    public String toString()
    {
        return String.format ("%s (%s)", this.nombreEquipo, this.ciudad);
    }
    






    
    public void save (String filename) {
        
        try {
            FileOutputStream fos = new FileOutputStream(filename);
            ObjectOutputStream salida = new ObjectOutputStream(fos);

            // Volcamos el objeto Equipo (this) en el archivo
            salida.writeObject(this);
            
        } catch (FileNotFoundException ex) {
            System.out.printf ("Error: %s\n", ex.getMessage());
        } catch (IOException ex) {
            System.out.printf ("Error: %s\n", ex.getMessage());
        }
        
    }
    
    
    
    
}
