
package tarea07.tienda.comparators;

import java.util.Comparator;
import tarea07.tienda.TicketCompra;

/**
 *
 * @author diosdado
 */
public class ComparadorTicketsPorInstante implements Comparator<TicketCompra> {

    @Override
    public int compare ( TicketCompra t1, TicketCompra t2 ) {
        
        return t1.getInstante().compareTo(t2.getInstante());
        
    }
    
}
