
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;


public class ListaAleatorios01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int CANTIDAD = 20;


            // Variables de entrada




            // Variables de salida
            List<Integer> listaEnteros;



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS CON LISTAS");
            System.out.println("-------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            listaEnteros = new ArrayList<>();

            System.out.printf ("Lista inicial: %s\n", listaEnteros);
            for ( int numElementos=0; numElementos < CANTIDAD ; numElementos++ ) {
                int numAleatorio = 1 + (int)(Math.random()*10);
                listaEnteros.add ( numAleatorio );
                System.out.printf ("A�adiendo %2d: %s\n", numAleatorio, listaEnteros);
            }

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            
            System.out.print ("Contenido de la lista (con toString): ");
            System.out.println (listaEnteros);
            System.out.println ();
            System.out.println ("Contenido de la lista (con un bucle foreach): ");
            int contador = 0;
            for ( int elemento : listaEnteros) {
                System.out.printf ("Elemento %2d: %2d\n", contador++, elemento);
            }
            
            System.out.println ();
            System.out.println ("Contenido de la lista (con un bucle for convencional): ");
            for ( int indice = 0 ; indice < listaEnteros.size() ; indice++ ) {
                int elemento = listaEnteros.get(indice);
                System.out.printf ("Elemento %2d: %2d\n", indice, elemento);                
            }

            System.out.println ();
            System.out.println ("Contenido de la lista (generando un array con toArray): ");
            // Obtenemos un array con los elementos de la lista
            Integer[] arrayEnteros =  listaEnteros.toArray( new Integer[0]);
            System.out.println (Arrays.toString(arrayEnteros));
            // Recorremos el array
            for ( int indice = 0 ; indice < arrayEnteros.length ; indice++ ) {
                int elemento = arrayEnteros[indice];
                System.out.printf ("Elemento %2d: %2d\n", indice, elemento);                
            }


            System.out.println ();
            System.out.println ("Contenido de la lista (con un bucle for con iterador): ");
            Iterator<Integer> it = listaEnteros.iterator();
            contador = 0;
            while ( it.hasNext() ) {
                Integer elemento = it.next();
                System.out.printf ("Elemento %2d: %2d\n", contador++, elemento);
            }
            
            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

