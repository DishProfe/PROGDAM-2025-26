
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;


public class Lista2D01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida
            List< List<Integer> > lista2D;



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
        System.out.println("LISTA DE LISTAS DE ENTEROS ALEATORIOS");
        System.out.println("-------------------------------------");
        System.out.println(" ");

        //----------------------------------------------
        //                 Procesamiento 
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println("Creamos la lista inicial (primera dimensi�n):");
        lista2D = new LinkedList<>();
        System.out.println(lista2D.toString());

        
        for ( int contador1 = 0; contador1< 4; contador1++ ) {
            // Creamos sublista
            List<Integer> sublista = new LinkedList<>();
            lista2D.add( sublista );
            System.out.printf ("Sublista creada: %s\n", lista2D);
            //lista2D.add( new LinkedList<>() );
            
            // Rellenamos sublista
            for ( int contador2 = 0 ;  contador2 < 4 ; contador2++ ) {
                int numAleatorio = (int)(Math.random()*10);
                sublista.add(numAleatorio);
                //lista2D.get(contador1).add(contador2);
                System.out.printf ("A�adiendo elemento %d a sublista: %s\n", 
                        numAleatorio, lista2D);
                
            }
            
        }
        


            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println (lista2D);

            System.out.println ();
            System.out.println ("Recorrido de la lista usando iterador: ");
            Iterator< List<Integer> > it = lista2D.iterator();
            while ( it.hasNext() ) {
                List<Integer> sublista = it.next();
                System.out.println (sublista);
            }
            
            System.out.println ();
            System.out.println ("Recorrido de la lista usando dos iteradores: ");
            Iterator< List<Integer> > it1 = lista2D.iterator();
            while ( it1.hasNext() ) {
                List<Integer> sublista = it1.next();
                
                Iterator<Integer> it2 = sublista.iterator();
                System.out.printf ("Sublista %s: \n", sublista);
                while ( it2.hasNext() ) {
                    int elemento = it2.next();
                    System.out.printf ("  - %2d\n", elemento);
                }
                
            }


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}