
package ejemplos2026;

/**
 * Programa de Turnos
 * @author diosdado
 */

import java.time.LocalDate;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;


public class Turnos01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida
            Map<LocalDate, Set<String> > mapTurnos;
            


            // Variables auxiliares
            String[] arrayPersonas = {"Juan", "Luisa", "Clara", "Rogelio", "Francisco"};



            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("ASIGNACI�N DE TURNOS");
            System.out.println("--------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            mapTurnos = new LinkedHashMap<>();

            LocalDate fecha = LocalDate.now();
            int numDias = 0;
            
            while ( numDias < 7 ) {
                mapTurnos.put (fecha, new LinkedHashSet<>() );

                for ( int contador=0 ; contador < 3; contador++ ) {
                    mapTurnos.get (fecha).add(arrayPersonas[(numDias+contador) % arrayPersonas.length]);
                }
                
                fecha = fecha.plusDays(1);
                numDias++;
            } 
            
            


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Asignaci�n de turnos: ");
            System.out.println (mapTurnos);

            System.out.println ();
            System.out.println ("Asignaci�n de turnos: ");
            for ( LocalDate dia : mapTurnos.keySet()  ) {
                System.out.printf ("%s -> %s\n", 
                        dia, 
                        mapTurnos.get(dia));
            }
            
            System.out.println ();
            System.out.println ("Asignaci�n de turnos: ");
            for ( LocalDate dia : mapTurnos.keySet()  ) {
                System.out.printf ("%s: \n", dia);
                for ( String persona : mapTurnos.get(dia) ) {
                    System.out.printf ("  - %s\n", persona);
                }
            }
            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}