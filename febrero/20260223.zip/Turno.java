
package ejemplos2026;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Turno
 * @author diosdado
 */
public class Turno {
    
    //Atributos de clase constantes y p�blicos

    public final static int NUM_PERSONAS_POR_TURNO_DEFAULT = 3;
    public final static int NUM_DIAS_POR_TURNO_DEFAULT = 5;
    
    // Atributos de objeto
    private List<String> listaPersonas;
    
    // Constructores
    public Turno ( String[] arrayPersonas ) throws NullPointerException {

        this.listaPersonas = new LinkedList<>();

        for ( String persona : arrayPersonas ) {
            this.listaPersonas.add(persona);
        }


    }
    
    
    
       
    
    public int getNumPersonas() {
        return this.listaPersonas.size();
    }
    
    public void addPersona (String persona) {
        this.listaPersonas.add (persona);
    }
    
    public Map<LocalDate, Set<String>> generaTurno ( LocalDate fechaInicio, 
            int numDias,
            int cantidadPersonas) {

            Map<LocalDate, Set<String> > mapTurnos;

        
            mapTurnos = new LinkedHashMap<>();

            LocalDate fecha = LocalDate.now();
            int contadorDias = 0;
            
            while ( contadorDias < numDias ) {
                mapTurnos.put (fecha, new LinkedHashSet<>() );

                for ( int contador=0 ; contador < cantidadPersonas; contador++ ) {
                    int posicionPersona = (contadorDias+contador) % this.listaPersonas.size();
                    mapTurnos.get(fecha).add(this.listaPersonas.get(posicionPersona));
                }
                
                fecha = fecha.plusDays(1);
                contadorDias++;
            } 
            
        return mapTurnos; 
    }
    
    public String generaTurnoToString ( LocalDate fechaInicio, 
            int numDias,
            int cantidadPersonas) {
    
        Map<LocalDate, Set<String> > mapTurnos = this.generaTurno(fechaInicio, numDias, cantidadPersonas);
        
        StringBuilder resultado = new StringBuilder ();
        for ( LocalDate dia : mapTurnos.keySet()  ) {

            String linea = String.format ("%s -> %s\n", 
                                dia, 
                                mapTurnos.get(dia));
            resultado.append( linea );
        }
        
        return resultado.toString();
    
    }

    
    public Map<LocalDate, Set<String>> generaTurno () {
        return this.generaTurno(LocalDate.now(), 
                    Turno.NUM_DIAS_POR_TURNO_DEFAULT, 
                    Turno.NUM_DIAS_POR_TURNO_DEFAULT);
    }
    
    /*
    
    public Map<LocalDate, Set<String>> generaTurno ( LocalDate fechaInicio ) {
        
    }
    
    public Map<LocalDate, Set<String>> generaTurno ( int cantidadPersonas ) {
        
    }
        
    public Map<LocalDate, Set<String>> generaTurno ( int numDias ) {
        
    }
            
    public Map<LocalDate, Set<String>> generaTurno ( int cantidadPersonas, int numDias ) {
        
    }

    public Map<LocalDate, Set<String>> generaTurno ( LocalDate fechaInicio, int numDias ) {
        
    }

    */
    
    

    public static void main (String[] args) {
        
        String[] arrayPersonas = {"Juan", "Luisa", "Clara", "Rogelio", "Francisco"};
        
        Turno t1 = new Turno (arrayPersonas);
            
        
        
        Map<LocalDate, Set<String> > mapTurnos= t1.generaTurno(LocalDate.now(), 10, 3);
        
        System.out.println ();
        System.out.println ("Asignaci�n de turnos: ");
        System.out.println ( t1.generaTurnoToString(LocalDate.now(), 10, 3) );
        
            
        
    }
    
    
    
    
}
