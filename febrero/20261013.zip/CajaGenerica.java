package ejemplos2026;

import java.time.LocalDate;


/**
 *
 * @author portatil_profesorado
 */
public class CajaGenerica<T> {

    private T elemento;
    
    public CajaGenerica (T valorAtributo) {
        this.elemento = valorAtributo;
    }
    
    public CajaGenerica () {
        this(null);
    }
    
    public void setElemento (T valorAtributo) {
        this.elemento = valorAtributo;
    }
    
    public T getElemento() {
        return this.elemento;
        
    }
    
    @Override
    public String toString() {
        return this.elemento.toString();
    }
    
    
    
    public static void main (String[] args)  {
        
        CajaGenerica<Integer> caja1 = new CajaGenerica ( 10 );
        CajaGenerica<LocalDate> caja2 = new CajaGenerica<LocalDate> ( LocalDate.of (2025, 9, 15) );
        CajaGenerica<String> caja3 = new CajaGenerica<String> ( "Hola Mundo" );
        
        System.out.printf ("caja1 = %s\n", caja1);
        System.out.printf ("caja2 = %s\n", caja2);
        System.out.printf ("caja3 = %s\n", caja3);
        
        System.out.printf ("caja2.year = %d\n", caja2.getElemento().getYear() );
        //System.out.printf ("caja3.year = %d\n", caja3.getElemento() );
        
        
        
    }
    
    
}
