
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.time.LocalDate;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;


public class EjemplosSet01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE CONJUNTOS CON SET");
            System.out.println("-----------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            Set<String> c1;
            Set<String> c2;
            Set<String> c3;
            Set<LocalDate>c4;
            Set<LocalDate>c5;
            
            c1 = new HashSet<>();
            c2 = new LinkedHashSet<>();
            c3 = new TreeSet<>();
            c4 = new HashSet<>();
            c5 = new HashSet<>();
            
            
            System.out.printf ( "Tama�o de c1 = %d\n", c1.size() );
            
            System.out.println ("A�adiendo elementos a c1...");
            c1.add ("Juan");
            c1.add ("Pedro");
            c1.add ("Lucas");
            c1.add ("Marcos");

            System.out.printf ( "Tama�o de c1 = %d\n", c1.size() );
            
            System.out.println ("Probamos si c1 contiene 'Pedro': ");
            System.out.println (c1.contains("Pedro"));
            System.out.println ("Probamos si c1 contiene 'Luis': ");
            System.out.println (c1.contains("Luis"));

            System.out.println ("Probamos el m�todo toString para c1: ");
            System.out.println (c1.toString());

            System.out.println ("Elementos de c1: ");
            for ( String elemento : c1 )  {
                System.out.println (elemento);
            }

            System.out.println();
            System.out.println ("A�adiendo elementos a c2...");
            c2.add ("Juan");
            c2.add ("Pedro");
            c2.add ("Lucas");
            c2.add ("Marcos");
            System.out.println ("Elementos de c2: ");
            for ( String elemento : c2 )  {
                System.out.println (elemento);
            }

            System.out.println();
            System.out.println();
            System.out.println ("A�adiendo elementos a c3...");
            c3.add ("Juan");
            c3.add ("Pedro");
            c3.add ("Lucas");
            c3.add ("Marcos");
            System.out.println ("Elementos de c3: ");
            for ( String elemento : c3 )  {
                System.out.println (elemento);
            }
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

