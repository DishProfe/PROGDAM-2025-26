package ejemplos2026;

import java.time.LocalDate;

/**
 *
 * @author portatil_profesorado
 */
public class CajaGenerico<T> {

    private T atributo;
    
    public CajaGenerico (T valorAtributo) {
        this.atributo = valorAtributo;
    }
    
    public CajaGenerico () {
        this(null);
    }
    
    public void setAtributo (T valorAtributo) {
        this.atributo = valorAtributo;
    }
    
    public T getAtributo() {
        return this.atributo;
        
    }
    
    
    public void prueba () {
        
        CajaGenerico<Integer> caja1 = new CajaGenerico(25);
        CajaGenerico<String> caja2 = new CajaGenerico ("Caja2");
        CajaGenerico<LocalDate> caja3 = new CajaGenerico (LocalDate.now());
        
        
    }
    
    
}
