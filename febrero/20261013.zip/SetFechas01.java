
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.time.LocalDate;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;


public class SetFechas01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida
            Set<LocalDate> setFechas;


            // Variables auxiliares
            


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CONJUNTOS DE FECHAS");
            System.out.println("-------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            setFechas = new LinkedHashSet<>();

            while ( setFechas.size() < 10 ) {
                
                // Fecha aleatoria entre 1 y 15 de marzo de 2022
                LocalDate fechaBase = LocalDate.of (2022, 3, 1);
                int numAleatorio = (int)(Math.random()*15);
                LocalDate fechaAleatoria = fechaBase.plusDays(numAleatorio);
                
                // Incluimos en esa fecha aleatoria en el conjunto
                setFechas.add (fechaAleatoria);
                
                
            }


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Contenido del Set de letras aleatorias: ");
            System.out.printf ("Tama�o: %d\n", setFechas.size());
            System.out.println (setFechas);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

