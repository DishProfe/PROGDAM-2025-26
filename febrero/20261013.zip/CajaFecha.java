package ejemplos2026;

import java.time.LocalDate;


/**
 *
 * @author portatil_profesorado
 */
public class CajaFecha {

    private LocalDate elemento;
    
    public CajaFecha (LocalDate valorElemento) {
        this.elemento = valorElemento;
    }
    
    public CajaFecha () {
        this(LocalDate.now());
    }
    
    public void setElemento (LocalDate valorElemento) {
        this.elemento = valorElemento;
    }
    
    public LocalDate getElemento() {
        return this.elemento;
        
    }
    
    
    public static void main (String[] args)  {
        
        CajaFecha caja1 = new CajaFecha ( LocalDate.now() );
        CajaFecha caja2 = new CajaFecha ( LocalDate.of (2026, 1, 1) );
        CajaFecha caja3 = new CajaFecha ( LocalDate.of (2025, 9, 15) );
        
        
        
        
    }
    
    
}
