
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;


public class SetLetrasAleatorias04b {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int NUM_ALEATORIOS = 10;

            // Variables de entrada




            // Variables de salida
            Character[] arrayChar;


            // Variables auxiliares
            Set<Character> setLetras;
            Set<Character> setAlfabeto;
            Set<Character> setRestoLetras;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CONJUNTO DE LETRAS ALEATORIAS");
            System.out.println("-----------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            setLetras = new HashSet<>();
            setAlfabeto = new HashSet<>();

            // Rellenamos el conjunto setAlfabeto con todas las letras
            for ( char letra='A' ; letra <= 'Z' ; letra++ ) {
                setAlfabeto.add (letra);
            }
            
            // Rellenamos el conjunto setLetras con 20 letras aleatorias
            while ( setLetras.size() < NUM_ALEATORIOS ) {
                char letraAleatoria = (char) ('A' + (Math.random()*('Z'-'A')));
                setLetras.add (letraAleatoria);                
            }

            // Restamos al conjunto global (todas las letras) las 20 aleatorias
            setRestoLetras = new HashSet<> (setAlfabeto);
            setRestoLetras.removeAll(setLetras);
            
            
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Contenido del Set de letras aleatorias: ");
            System.out.printf ("Tama�o: %d\n", setLetras.size());
            System.out.println (setLetras);
            System.out.println ();
            System.out.println ("Contenido del Set de las otras letras: ");
            System.out.printf ("Tama�o: %d\n", setRestoLetras.size() );
            System.out.println (setRestoLetras);  
            
            
            

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

