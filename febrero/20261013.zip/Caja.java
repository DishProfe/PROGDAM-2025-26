package ejemplos2026;


/**
 *
 * @author portatil_profesorado
 */
public class Caja {

    private int elemento;
    
    public Caja (int valorAtributo) {
        this.elemento = valorAtributo;
    }
    
    public Caja () {
        this(0);
    }
    
    public void setElemento (int valorAtributo) {
        this.elemento = valorAtributo;
    }
    
    public int getElemento() {
        return this.elemento;
        
    }
    
    
    public static void main (String[] args)  {
        
        Caja caja1 = new Caja (10);
        Caja caja2 = new Caja (20);
        Caja caja3 = new Caja (30);
        
        
        
        
    }
    
    
}
