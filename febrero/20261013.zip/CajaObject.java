package ejemplos2026;

import java.time.LocalDate;


/**
 *
 * @author portatil_profesorado
 */
public class CajaObject {

    private Object elemento;
    
    public CajaObject (Object valorAtributo) {
        this.elemento = valorAtributo;
    }
    
    public CajaObject () {
        this(null);
    }
    
    public void setElemento (Object valorAtributo) {
        this.elemento = valorAtributo;
    }
    
    public Object getElemento() {
        return this.elemento;
        
    }
    
    @Override
    public String toString() {
        return this.elemento.toString();
    }
    
    
    
    public static void main (String[] args)  {
        
        CajaObject caja1 = new CajaObject ( 10 );
        CajaObject caja2 = new CajaObject ( LocalDate.of (2025, 9, 15) );
        CajaObject caja3 = new CajaObject ( "Hola Mundo" );
        
        System.out.printf ("caja1 = %s\n", caja1);
        System.out.printf ("caja2 = %s\n", caja2);
        System.out.printf ("caja3 = %s\n", caja3);
        
        System.out.printf ("caja2.year = %d\n", ((LocalDate)caja2.getElemento()).getYear() );
        //System.out.printf ("caja3.year = %d\n", ((LocalDate)caja3.getElemento()).getYear() );
        
        
        
    }
    
    
}
