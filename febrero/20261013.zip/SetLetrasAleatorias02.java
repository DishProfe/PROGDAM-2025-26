
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;


public class SetLetrasAleatorias02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares
            Set<Character> setLetras;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CONJUNTO DE LETRAS ALEATORIAS");
            System.out.println("-----------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            setLetras = new HashSet<>();


            while ( setLetras.size() < 20 ) {
                char letraAleatoria = (char) ('A' + (Math.random()*('Z'-'A')));
                setLetras.add (letraAleatoria);                
            }

            
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Contenido del Set de letras aleatorias: ");
            System.out.printf ("Tama�o: %d\n", setLetras.size());
            for  ( Character letra : setLetras  ) {
                System.out.printf ("%c ", letra);
            }
            
            

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

