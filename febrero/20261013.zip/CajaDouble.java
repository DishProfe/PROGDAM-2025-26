package ejemplos2026;


/**
 *
 * @author portatil_profesorado
 */
public class CajaDouble {

    private double elemento;
    
    public CajaDouble (double valorElemento) {
        this.elemento = valorElemento;
    }
    
    public CajaDouble () {
        this(0);
    }
    
    public void setElemento (double valorElemento) {
        this.elemento = valorElemento;
    }
    
    public double getElemento() {
        return this.elemento;
        
    }
    
    
    public static void main (String[] args)  {
        
        CajaDouble caja1 = new CajaDouble (10.0);
        CajaDouble caja2 = new CajaDouble (20.0);
        CajaDouble caja3 = new CajaDouble (30.0);
        
        
        
        
    }
    
    
}
