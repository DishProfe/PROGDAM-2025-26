package ejemplos2026;

import java.time.LocalDate;


/**
 *
 * @author portatil_profesorado
 * @param <T1>
 * @param <T2>
 */
public class CajaDoble<T1,T2> {

    private T1 elemento1;
    private T2 elemento2;
    private LocalDate fechaCreacion;
    
    public CajaDoble (T1 v1, T2 v2) {
        this.elemento1 = v1;
        this.elemento2 = v2;
        this.fechaCreacion = LocalDate.now();
    }
    
   
    public void setElemento1 (T1 valor) {
        this.elemento1 = valor;
    }
    
    public void setElemento2 (T2 valor) {
        this.elemento2 = valor;
    }

    public T1 getElemento1() {
        return this.elemento1;
        
    }

    public T2 getElemento2() {
        return this.elemento2;
        
    }
    
    public LocalDate getFechaCreacion() {
        return this.fechaCreacion;
    }
    
    
    
    
    
    public static void main (String[] args)  {
        
        CajaDoble<Integer, Integer> caja1 = new CajaDoble (10, 20);
        CajaDoble<String,Double> caja2 = new CajaDoble ("Hola", 20.0);
        CajaDoble<LocalDate,Character> caja3 = new CajaDoble (LocalDate.of(2025,9,15), 'A');
        
        
        
    }
    
    
}
