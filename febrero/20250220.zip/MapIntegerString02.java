
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;


public class MapIntegerString02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            Map<Integer,String> map;



            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE MAP");
            System.out.println("---------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            map = new TreeMap<>();
            
            map.put (2,  "dos");
            map.put (3,  "tres");
            map.put (13, "trece");
            map.put (17, "diecisiete");
            map.put (19, "diecinueve");
            map.put (5,  "cinco");
            map.put (7,  "siete");
            map.put (11, "once");




            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Contenido del map: %s\n", map);
            

            System.out.println ();
            System.out.println ("Contenido del map recorriendo el conjunto de claves:");
            Set<Integer> setClaves =  map.keySet();
            for ( Integer clave : setClaves ) {
               System.out.printf ("Elemento %2d -> %s\n", 
                       clave,
                       map.get(clave));
            }
            
            
            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}