
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.time.DayOfWeek;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


public class MapDiasSemana01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            Map<Integer,DayOfWeek> mapDiasSemana;



            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE ESTRUCURAS MAP");
            System.out.println("--------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            mapDiasSemana = new HashMap<>();
            
            for (int indice = 0; indice < 5 ; indice++ ) {
                DayOfWeek dia = DayOfWeek.of (1+(int)(Math.random()*7));
                mapDiasSemana.put (indice, dia);
            }
        
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf  ("Contenido del map: %s\n", mapDiasSemana);

            System.out.println("Contenido del map recorriendo las claves:");
            for ( int indice=0; indice<mapDiasSemana.size() ; indice++ ) {
                System.out.printf ("Elemento %d: %s\n", 
                        indice,
                        mapDiasSemana.get(indice));
            }
            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}