
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;


public class MapIntegerString01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            Map<Integer,String> map;



            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE MAP");
            System.out.println("---------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            map = new HashMap<>();
            
            map.put (3, "Azul");
            map.put (7, "Verde");
            map.put (11,"Rojo");
            map.put (15002, "Naranja");




            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Contenido del map: %s\n", map);
            
            System.out.println ();
            System.out.println ("Contenido del map sabiendo las claves: ");
            System.out.printf ("Elemento %5d: %s\n", 3, map.get(3));
            System.out.printf ("Elemento %5d: %s\n", 7, map.get(7));
            System.out.printf ("Elemento %5d: %s\n", 11, map.get(11));
            System.out.printf ("Elemento %5d: %s\n", 15002, map.get(15002));

            System.out.println ();
            System.out.println ("Contenido del map recorriendo el conjunto de claves:");
            Set<Integer> setClaves =  map.keySet();
            for ( Integer clave : setClaves ) {
               System.out.printf ("Elemento %5d: %s\n", 
                       clave,
                       map.get(clave));
            }
            
            
            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}