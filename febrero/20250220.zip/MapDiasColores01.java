
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.time.DayOfWeek;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;


public class MapDiasColores01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada



            // Variables de salida
            Map< DayOfWeek, Set<String> > mapDiasColores;
            List<String> listaColores;



            // Variables auxiliares
            String[] arrayColores = {"Negro", "Blanco", "Rojo", "Verde", "Azul", "Amarillo"};

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("MAPS DE COLORES");
            System.out.println("---------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            mapDiasColores = new LinkedHashMap<>();   
            listaColores = new LinkedList<>();
            
            // Rellenamos el map con los colores a valor cero
            for ( int indice=1 ; indice<=7 ; indice++ ) {
                
                Set<String> setVacio = new HashSet<>();
                mapDiasColores.put ( DayOfWeek.of(indice), setVacio  );

                //mapDiasColores.put ( DayOfWeek.of(indice), new HashSet<>()  );
                
            }
            
            // Rellenamos cada d�a de la semana con tres colores aleatorios
            for ( DayOfWeek dia :  mapDiasColores.keySet() ){
             
                // Mientras no haya tres colores en el conjunto, vamos generando colores aleatorios
                while ( mapDiasColores.get(dia).size() < 3 ) {
                    // Genero un color aleatorio
                    String colorAleatorio = arrayColores[(int)(Math.random()*arrayColores.length)];

                    // A�ado ese color aleatorio al conjunto de colores de ese d�a
                    mapDiasColores.get(dia).add(colorAleatorio);
                    
                }
                
            }






            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Contenido de la lista de colores: %s\n", listaColores);
            System.out.printf ("Contenido del map: %s\n", mapDiasColores);

            System.out.println ();
            System.out.printf ("Contenido del map recorriendo las claves:\n");
            for ( DayOfWeek dia : mapDiasColores.keySet()  ) {
                System.out.printf ("%10s -> %s\n",
                        dia,
                        mapDiasColores.get(dia));
            }
            
            System.out.println ();
            System.out.printf ("Contenido del map recorriendo los d�as y recorriendo los colores:\n");
            for ( DayOfWeek dia : mapDiasColores.keySet()  ) {
                System.out.printf ("%-10s\n", dia);
                for ( String color : mapDiasColores.get(dia) ) {
                    System.out.printf ("  - %s\n", color);
                }
            }
            

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}