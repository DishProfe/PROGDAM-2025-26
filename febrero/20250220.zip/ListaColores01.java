
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;


public class ListaColores01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            List<String> lista1, lista2;




            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS CON LISTAS DE COLORES");
            System.out.println("------------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------


            lista1 = new LinkedList<>();       
            lista2 = new LinkedList<>();       

            // A�adimos colores a lista1
            lista1.add ("rojo");
            lista1.add ("amarillo");
            lista1.add ("verde");
            lista1.add ("azul");
            lista1.add ("morado");
            lista1.add ("gris");

            
            // Copio los colores de lista1 en lista2
            for ( String color : lista1 ) {
                if (terminaVocal (color) ) {                
                    lista2.add (color);
                }
            }

            // Invierto los contenidos de lista2
            for ( int indice=0; indice<lista2.size() ; indice++ ) {

                String color = lista2.get(indice);
                StringBuilder sb= new StringBuilder(color);
                sb.reverse();
                lista2.set (indice, sb.toString());

                //String colorInvertido = (new StringBuilder(lista2.get(indice)).reverse()).toString();
                //lista2.set(indice, colorInvertido);
            }
            


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Lista1: %s\n", lista1);
            System.out.printf ("Lista2: %s\n", lista2);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
        
        /*
        boolean terminaVocal (String texto) {
            char ultimaLetra = texto.charAt(texto.length()-1);
            if (ultimaLetra == 'a' || )
            
        }*/
        
        
        public static boolean terminaVocal (String texto) {
            return texto.matches (".*[aeiou]$");
        }
        
        
        
    
}