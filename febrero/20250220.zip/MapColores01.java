
package ejemplos2026;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;


public class MapColores01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada



            // Variables de salida
            Map<String,Integer> mapColores;
            List<String> listaColores;



            // Variables auxiliares
            String[] arrayColores = {"Negro", "Blanco", "Rojo", "Verde", "Azul", "Amarillo"};

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("MAPS DE COLORES");
            System.out.println("---------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            mapColores = new HashMap<>();   
            listaColores = new LinkedList<>();
            
            // Rellenamos el map con los colores a valor cero
            for ( String color : arrayColores ) {
                mapColores.put (color, 0);
            }
            
            // Rellenamos la lista con diez colores aleatorios
            for ( int indice = 0; indice < 10 ;  indice++ ) {
                String colorAleatorio = arrayColores[(int)(Math.random()*arrayColores.length)];
                listaColores.add(colorAleatorio);
            }
            
            // Recorremos la lista de colores aleatorios y vamos actualizando el map de colores
            for ( int indice= 0 ; indice < listaColores.size() ; indice++ ) {
                String color = listaColores.get(indice);
                int valorActual = mapColores.get(color);
                mapColores.put (color, valorActual+1) ;
            }



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Contenido de la lista: %s\n", listaColores);
            System.out.printf ("Contenido del map: %s\n", mapColores);
            System.out.println ();
            System.out.printf ("Contenido del map recorriendo las claves:\n");
            for ( String color : mapColores.keySet()  ) {
                System.out.printf ("%8s -> %d\n", color, mapColores.get(color));
            }
            
            

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}