
package ejemplos2025;

/**
 * Programa Ejemplos de captura de excepciones con objetos bombilla
 * @author diosdado
 */

import java.util.Scanner;
import aguadulce.Bombilla;
import java.util.InputMismatchException;


public class BombillaExcepciones02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            double vatios;



            // Variables de salida
            Bombilla b1 = null;


            // Variables auxiliares
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("PRUEBA DE EXCEPCIONES CON LA CLASE BOMBILLA");
            System.out.println("-------------------------------------------");

            /*
            do {
                System.out.println("Introduzca potencia de la bombilla:");
                vatios = teclado.nextDouble();            
            } while (vatios<Bombilla.MINIMA_POTENCIA || vatios>Bombilla.MAXIMA_POTENCIA);
            
            b1 = new Bombilla (vatios);
            */
            
            boolean entradaValida = false;
            do {
                System.out.println("Introduzca potencia de la bombilla:");
                try {
                    vatios = teclado.nextDouble();
                    System.out.println ("Intentando crear bombilla de " + vatios + "  vatios.");
                    b1 = new Bombilla (vatios);
                    entradaValida = true;
                    System.out.println ("Bombilla b1 creada correctamente.");                    
                }
                catch ( InputMismatchException ex ) {
                    System.out.println("Error. Debe introducir un n�mero entero.");
                    teclado.nextLine();
                }
                catch (IllegalArgumentException ex) {
                    System.out.println("Error en la creaci�n de la bombilla. " + ex.getMessage());
                }
            } while ( !entradaValida );
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("Intentamos encender b1...");
            try {
                b1.encender();
            } catch ( IllegalStateException ex ) {
                System.out.println ("Error: " + ex.getMessage());
            }
            System.out.println("b1 encendida: " + b1.toString());
            System.out.println ();
            System.out.println ("Intentamos volver a encender b1...");
            try {
                b1.encender();
            } catch ( IllegalStateException ex ) {
                System.out.println ("Error: " + ex.getMessage());
            }
            
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Objeto bombilla b1 = " + b1.toString() );
            System.out.println ("potencia de b1 = " + b1.getPotencia());

            System.out.println ();
            System.out.println ("Fin del programa.");
        

            
        
	}
    
}