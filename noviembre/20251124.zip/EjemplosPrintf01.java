
package ejemplos2025;


import java.util.Scanner;

/**
 *   Programa de pruebas del uso del printf (imprimir con "formato")
 */

    public class EjemplosPrintf01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        int edad1= 25, edad2= 32, edad3= 5, edad4= 101;
        double peso1 = 39.213, peso2 = 101.122, peso3=25, peso4=72.0;
        double altura1 = 1.31, altura2 = 1.998, 
                altura3= 0.8912111, altura4= 1.68;
        String nombre1 = "Mercedes";
        String nombre2 = "Patxi";
        String nombre3 = "Toni";
        String nombre4 = "Daniel";
        
        
        // Variables de salida



        // Variables auxiliares


        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE USO DE PRINTF");
        System.out.println("-------------------------");
        System.out.println(" ");

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        
        
        
        
        
        
        
        
        
        

        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");

        System.out.println ("Con println y concatenando elementos con +:");        
        System.out.println (nombre1 + " " + "Edad: " + edad1 + " a�os Peso: " + peso1 + "Kg Altura: " + altura1 + "m");
        System.out.println (nombre2 + " " + "Edad: " + edad2 + " a�os Peso: " + peso2 + "Kg Altura: " + altura2 + "m");
        System.out.println (nombre3 + " " + "Edad: " + edad3 + " a�os Peso: " + peso3 + "Kg Altura: " + altura3 + "m");
        System.out.println (nombre4 + " " + "Edad: " + edad4 + " a�os Peso: " + peso4 + "Kg Altura: " + altura4 + "m");
        System.out.println ();

        
        System.out.println ("Con printf y %s, %d, %f, %f:");        
        System.out.printf ("%s Edad: %d a�os Peso: %f Kg Altura: %f m\n", nombre1, edad1, peso1, altura1);
        System.out.printf ("%s Edad: %d a�os Peso: %f Kg Altura: %f m\n", nombre2, edad2, peso2, altura2);
        System.out.printf ("%s Edad: %d a�os Peso: %f Kg Altura: %f m\n", nombre3, edad3, peso3, altura3);
        System.out.printf ("%s Edad: %d a�os Peso: %f Kg Altura: %f m\n", nombre4, edad3, peso4, altura4);
        System.out.println ();
        
        System.out.println ("Con printf y %s, %d, %6f, %4f:");        
        System.out.printf ("%s Edad: %d a�os Peso: %6f Kg Altura: %4f m\n", nombre1, edad1, peso1, altura1);
        System.out.printf ("%s Edad: %d a�os Peso: %6f Kg Altura: %4f m\n", nombre2, edad2, peso2, altura2);
        System.out.printf ("%s Edad: %d a�os Peso: %6f Kg Altura: %4f m\n", nombre3, edad3, peso3, altura3);
        System.out.printf ("%s Edad: %d a�os Peso: %6f Kg Altura: %4f m\n", nombre4, edad4, peso4, altura4);
        System.out.println ();
        
        System.out.println ("Con printf y %10s, %d, %6f, %4f:");        
        System.out.printf ("%10s Edad: %d a�os Peso: %6f Kg Altura: %4f m\n", nombre1, edad1, peso1, altura1);
        System.out.printf ("%10s Edad: %d a�os Peso: %6f Kg Altura: %4f m\n", nombre2, edad2, peso2, altura2);
        System.out.printf ("%10s Edad: %d a�os Peso: %6f Kg Altura: %4f m\n", nombre3, edad3, peso3, altura3);
        System.out.printf ("%10s Edad: %d a�os Peso: %6f Kg Altura: %4f m\n", nombre4, edad4, peso4, altura4);
        System.out.println ();
        
        System.out.println ("Con printf y %-10s, %d, %6f, %4f:");        
        System.out.printf ("%-10s Edad: %d a�os Peso: %6f Kg Altura: %4f m\n", nombre1, edad1, peso1, altura1);
        System.out.printf ("%-10s Edad: %d a�os Peso: %6f Kg Altura: %4f m\n", nombre2, edad2, peso2, altura2);
        System.out.printf ("%-10s Edad: %d a�os Peso: %6f Kg Altura: %4f m\n", nombre3, edad3, peso3, altura3);
        System.out.printf ("%-10s Edad: %d a�os Peso: %6f Kg Altura: %4f m\n", nombre4, edad4, peso4, altura4);
        System.out.println ();
        
        System.out.println ("Con printf y %-10s, %d, %6.2f, %4f:");        
        System.out.printf ("%-10s Edad: %d a�os Peso: %6.2f Kg Altura: %4f m\n", nombre1, edad1, peso1, altura1);
        System.out.printf ("%-10s Edad: %d a�os Peso: %6.2f Kg Altura: %4f m\n", nombre2, edad2, peso2, altura2);
        System.out.printf ("%-10s Edad: %d a�os Peso: %6.2f Kg Altura: %4f m\n", nombre3, edad3, peso3, altura3);
        System.out.printf ("%-10s Edad: %d a�os Peso: %6.2f Kg Altura: %4f m\n", nombre4, edad4, peso4, altura4);
        System.out.println ();

        System.out.println ("Con printf y %12s, %3d, %6.1f, %4.2f:");        
        System.out.printf ("%12s Edad: %3d a�os Peso: %6.1fKg Altura: %4.2fm\n", nombre1, edad1, peso1, altura1);
        System.out.printf ("%12s Edad: %3d a�os Peso: %6.1fKg Altura: %4.2fm\n", nombre2, edad2, peso2, altura2);
        System.out.printf ("%12s Edad: %3d a�os Peso: %6.1fKg Altura: %4.2fm\n", nombre3, edad3, peso3, altura3);
        System.out.printf ("%12s Edad: %3d a�os Peso: %6.1fKg Altura: %4.2fm\n", nombre4, edad4, peso4, altura4);
        System.out.println ();

        System.out.println ("Con printf y %12s, %03d, %6.1f, %4.2f:");        
        System.out.printf ("%12s Edad: %03d a�os Peso: %6.1fKg Altura: %4.2f m\n", nombre1, edad1, peso1, altura1);
        System.out.printf ("%12s Edad: %03d a�os Peso: %6.1fKg Altura: %4.2f m\n", nombre2, edad2, peso2, altura2);
        System.out.printf ("%12s Edad: %03d a�os Peso: %6.1fKg Altura: %4.2f m\n", nombre3, edad3, peso3, altura3);
        System.out.printf ("%12s Edad: %03d a�os Peso: %6.1fKg Altura: %4.2f m\n", nombre4, edad4, peso4, altura4);
        System.out.println ();

        
        int hora= 10, minuto= 7, segundo= 5;
        System.out.println ("Ejemplo de utilidad para anteponer 0 delante de un entero:");
        System.out.println ("Con println:        Hora: " + hora + ":" + minuto + ":" + segundo);
        System.out.printf  ("Con printf y %%2d    Hora: %2d:%2d:%2d\n", hora, minuto, segundo);
        System.out.printf  ("Con printf y %%02d:  Hora: %02d:%02d:%02d\n", hora, minuto, segundo);
        System.out.println ();
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}