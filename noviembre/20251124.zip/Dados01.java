
package ejemplos2025;


import java.util.Scanner;
import aguadulce.Dado;

/**
 *   Programa Ejemplos de uso de objetos Dado
 */

    public class Dados01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida



        // Variables auxiliares
        Dado d1, d2, d3, d4, d5, d6;
        


        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE USO DE OBJETOS DADO");
        System.out.println("-------------------------------");
        System.out.println(" ");

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        d1 = new Dado();
        d2 = new Dado(4);
        System.out.println ("Num. dados creados = " + 
                Dado.getNumeroDadosCreados());

        System.out.println ("N�mero de caras de d1 = " + 
                d1.getNumeroCaras());

        System.out.println ("N�mero de caras de d2 = " + 
                d2.getNumeroCaras());
     
        for (int lanzamiento=1; lanzamiento<=10 ; lanzamiento++) {
            System.out.println ("Lanzamos d1: " + d1.lanzar());
        }         
        
        
        

        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}