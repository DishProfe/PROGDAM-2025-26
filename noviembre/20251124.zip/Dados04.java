package ejemplos2025;




import java.util.Scanner;
import aguadulce.Dado;

/**
 *   Programa Ejemplos de uso de objetos Dado
 */

    public class Dados04 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida



        // Variables auxiliares
        Dado d1, d2, d3, d4, d5, d6;
        int numLanzamientos; // Contador que indica el número de lanzmamientos que llevamos


        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE USO DE OBJETOS DADO");
        System.out.println("-------------------------------");
        System.out.println(" ");

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        d1 = new Dado();
        
        numLanzamientos = 0;
        String lanzamiento;
        do {
            lanzamiento = d1.lanzar();
            numLanzamientos++;
            System.out.println ("Lanzamiento " + 
                    numLanzamientos + ": " + lanzamiento);
        } while ( d1.getNumeroVecesCara(6) < 3 );

/*        
        for ( numLanzamientos=0 ; d1.getNumeroVecesCara(6) < 3 ;  numLanzamientos++ ) {
            lanzamiento = d1.lanzar();
            System.out.println ("Lanzamiento " + 
                    numLanzamientos + ": " + lanzamiento);            
        }
*/        
        
        
        

        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        System.out.println ("El dado se ha lanzado " + 
                numLanzamientos + " veces");
        System.out.println (d1.getSerieHistoricaLanzamientos());
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}