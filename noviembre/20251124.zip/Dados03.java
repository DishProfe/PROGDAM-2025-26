
package ejemplos2025;


import java.util.Scanner;
import aguadulce.Dado;

/**
 *   Programa Ejemplos de uso de objetos Dado
 */

    public class Dados03 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida



        // Variables auxiliares
        Dado d1, d2, d3, d4, d5, d6;
        


        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE USO DE OBJETOS DADO");
        System.out.println("-------------------------------");
        System.out.println(" ");

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        d1 = new Dado();
        
        int numLanzamientos = 0;
        String lanzamiento;
        int vecesSeis = 0;
        do {
            lanzamiento = d1.lanzar();
            numLanzamientos++;
            System.out.println ("Lanzamiento " + 
                    numLanzamientos + ": " + lanzamiento);
            if (lanzamiento.equals ("SEIS")) {
                vecesSeis++;
            }
        } while ( vecesSeis < 3 );

        
        
        
        
        
        

        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        System.out.println ("El dado se ha lanzado " + 
                numLanzamientos + " veces");
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}