
package ejemplos2025;

/**
 * Programa Ejemplos con objetos CuentaBancaria
 * @author diosdado
 */

import aguadulce.CuentaBancaria;
import java.time.LocalDate;
import java.util.Scanner;


public class EjemploCuentaBancaria01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida
            CuentaBancaria cuenta1, cuenta2, cuenta3, cuenta4;


            // Variables auxiliares
            


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE USO DE CUENTA BANCARIA");
            System.out.println("----------------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            cuenta1 = new CuentaBancaria();
            cuenta2 = new CuentaBancaria (200.0);
            cuenta3 = new CuentaBancaria (300.0, LocalDate.of (2025, 9, 15));
            cuenta4 = new CuentaBancaria (400.0, LocalDate.of (2024, 9, 15), -500.0); 

            System.out.println("Cuentas reci�n credas...");
            System.out.println ("Cuenta 1: " + cuenta1);
            System.out.println ("Cuenta 2: " + cuenta2);
            System.out.println ("Cuenta 3: " + cuenta3);
            System.out.println ("Cuenta 4: " + cuenta4);
            System.out.println ();
            
            System.out.println ("Ingresamos 150 euros en cuenta 1");
            cuenta1.ingresar(150.0);
            System.out.println ("Cuenta 1: " + cuenta1);
            System.out.println ();

            System.out.println ("Sacamos 50 euros de cuenta 2");
            cuenta2.extraer(50);
            System.out.println ("Cuenta 2: " + cuenta2);
            System.out.println ();
            
            System.out.println ("Sacamos 600 euros de cuenta 4");
            cuenta4.extraer(600);
            System.out.println ("Cuenta 4: " + cuenta4);
            System.out.println ();

            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Cuenta 1: " + cuenta1);
            System.out.println ("Cuenta 2: " + cuenta2);
            System.out.println ("Cuenta 3: " + cuenta3);
            System.out.println ("Cuenta 4: " + cuenta4);
            
            

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}