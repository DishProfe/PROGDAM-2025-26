
package ejemplos2025;

/**
 * Programa Primer del mes
 * @author diosdado
 */

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Scanner;


public class PrimerDomingoMes01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int mes;
            int year;


            // Variables de salida
            LocalDate fechaPrimerDomingo = null;


            // Variables auxiliares
            LocalDate fechaInicial;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO DEL PRIMER DOMINGO DE UN MES");
            System.out.println("------------------------------------");
            System.out.println("Introduzca mes y a�o");
            mes = teclado.nextInt();
            year = teclado.nextInt();


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            fechaInicial = LocalDate.of (year, mes, 1);
            LocalDate fechaContador = fechaInicial;
            boolean domingoEncontrado;
            do {
                DayOfWeek diaSemana = fechaContador.getDayOfWeek();
                domingoEncontrado = diaSemana == DayOfWeek.SUNDAY ;
                if (domingoEncontrado) {
                    fechaPrimerDomingo = fechaContador;
                }
                fechaContador = fechaContador.plusDays(1);
            } while ( !domingoEncontrado );




            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El primer domingo del mes " + mes + " del a�o " + 
                    year + " es " + fechaPrimerDomingo);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}