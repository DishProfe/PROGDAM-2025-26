package ejemplos2025;

/**
 * Programa Fecha Aleatoria del a�o actual anterior a la fecha actual
 * @author diosdado
 */

import java.time.LocalDate;
import java.util.Scanner;

public class FechaAleatoria03 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida
            LocalDate fechaAleatoria = null;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("FECHA ALEATORIA DEL A�O ACTUAL POSTERIOR AL D�A ACTUAL");
            System.out.println("--------------------------------*---------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            LocalDate fechaActual = LocalDate.now();
            int yearActual = fechaActual.getYear();
            LocalDate fechaInicial = LocalDate.of (yearActual, 1, 1);
            int diaActual = fechaActual.getDayOfYear();
            int longYear = fechaActual.lengthOfYear();
            int sumaDiasAleatorio = 1 + diaActual + (int)(Math.random()*(longYear - diaActual));
            fechaAleatoria = fechaInicial.plusDays(sumaDiasAleatorio);
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println (fechaAleatoria);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}