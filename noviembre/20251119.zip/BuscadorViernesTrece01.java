
package ejemplos2025;

/**
 * Programa Buscador de viernes 13 en un a�o.
 * @author diosdado
 */

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Scanner;


public class BuscadorViernesTrece01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int year;



            // Variables de salida
            String listaViernesTrece;
            int numViernesTrece;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("BUSCADOR DE VIERNES 13 EN UN A�O");
            System.out.println("--------------------------------");
            System.out.println("Introduzca a�o");
            year = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            numViernesTrece = 0;
            listaViernesTrece = "";
            for ( int mes = 1; mes <=12 ; mes++ ) {
                LocalDate fecha = LocalDate.of (year, mes, 13);
                // Si el 13 de ese mes es viernes, lo contabilizamos
                if ( fecha.getDayOfWeek() == DayOfWeek.FRIDAY ) {
                    numViernesTrece++;
                    listaViernesTrece += fecha + "\n";
                }
            }

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("N�mero de viernes 13 en " + year+ ":");
            System.out.println (listaViernesTrece);
            System.out.println ("Total de viernes 13: " + numViernesTrece);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}