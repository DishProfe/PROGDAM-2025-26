
package ejemplos2025;

/**
 * Programa Buscador de viernes 13 entre dos a�os.
 * @author diosdado
 */

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Scanner;


public class BuscadorViernesTrece02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int year1, year2;



            // Variables de salida
            String listaViernesTrece;
            int numViernesTrece;


            // Variables auxiliares
            int yearInicio, yearFin;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("BUSCADOR DE VIERNES 13 ENTRE DOS A�OS");
            System.out.println("-------------------------------------");
            System.out.println("Introduzca a�os de inicio y de fin: ");
            year1 = teclado.nextInt();
            year2 = teclado.nextInt();
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            yearInicio = Math.min(year1, year2);
            yearFin = Math.max(year1, year2);
            
            numViernesTrece = 0;
            listaViernesTrece = "";
            for ( int year=yearInicio ; year<=yearFin ; year++ ) {
                listaViernesTrece += "Viernes 13 del a�o " + year + ":\n";
                for ( int mes = 1; mes <=12 ; mes++ ) {
                    LocalDate fecha = LocalDate.of (year, mes, 13);
                    // Si el 13 de ese mes es viernes, lo contabilizamos
                    if ( fecha.getDayOfWeek() == DayOfWeek.FRIDAY ) {
                        numViernesTrece++;
                        listaViernesTrece += fecha + "\n";
                    }
                }
                listaViernesTrece +="\n";
            }

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("N�mero de viernes 13 entre " + yearInicio + 
                    " y " + yearFin + ":");
            System.out.println (listaViernesTrece);
            System.out.println ("Total de viernes 13: " + numViernesTrece);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}