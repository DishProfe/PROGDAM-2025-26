
package ejemplos2025;

/**
 * Programa C�lculo de cu�ntos d�as faltan para el fin de semana
 * @author diosdado
 */

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Scanner;


public class DiasParaFinDeSemana02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida
            int numDiasParaFinSemana;


            // Variables auxiliares
            LocalDate fechaActual;
            DayOfWeek diaSemanaActual;
            int diaActual;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CU�NTOS D�AS FALTAN PARA EL FIN DE SEMANA");
            System.out.println("-----------------------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            fechaActual = LocalDate.now();
            diaSemanaActual = fechaActual.getDayOfWeek();

            numDiasParaFinSemana = 6 - diaSemanaActual.getValue();
            if (numDiasParaFinSemana < 0) {
                numDiasParaFinSemana = 0;
            }
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Faltan " + numDiasParaFinSemana + " para el fin de semana");

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}