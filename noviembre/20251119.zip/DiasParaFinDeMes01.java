
package ejemplos2025;

/**
 * Programa C�lculo de cu�ntos d�as faltan para fin de mes
 * @author diosdado
 */

import java.time.LocalDate;
import java.util.Scanner;


public class DiasParaFinDeMes01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida
            int numDiasParaFinMes;


            // Variables auxiliares
            LocalDate fechaActual;
            int numDiasMes;
            int diaActual;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CU�NTOS D�AS FALTAN PARA FIN DE MES");
            System.out.println("-----------------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            fechaActual = LocalDate.now();
            numDiasMes = fechaActual.lengthOfMonth();
            diaActual = fechaActual.getDayOfMonth();
            numDiasParaFinMes = numDiasMes - diaActual;
            


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println (numDiasParaFinMes);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}