
package ejemplos2025;

/**
 * Programa Cuenta cu�ntos domingos hay en un mes
 * @author diosdado
 */

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Scanner;


public class ContadorDomingos02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int mes;
            int year;




            // Variables de salida
            String listaDomingos;
            int contadorDomingos;


            // Variables auxiliares
            LocalDate fechaInicial;
            LocalDate fechaPrimerDomingo = null;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CONTADOR DE DOMINGOS EN UN MES");
            System.out.println("------------------------------");
            System.out.println("Introduzca mes y a�o");
            mes = teclado.nextInt();
            year = teclado.nextInt();
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            listaDomingos = "";
            contadorDomingos = 0;
            fechaInicial = LocalDate.of (year, mes, 1);

            // Calculamos el primer domingo del mes
            LocalDate fechaContador = fechaInicial;
            boolean domingoEncontrado;
            do {
                DayOfWeek diaSemana = fechaContador.getDayOfWeek();
                domingoEncontrado = diaSemana == DayOfWeek.SUNDAY ;
                if (domingoEncontrado) {
                    fechaPrimerDomingo = fechaContador;
                }
                fechaContador = fechaContador.plusDays(1);
            } while ( !domingoEncontrado );


            // Voy sumando de 7 en 7 desde el primer domingo
            // Hasta que me salga del mes
            fechaContador = fechaPrimerDomingo;
            do {
                listaDomingos += fechaContador + "\n";
                contadorDomingos++;
                fechaContador = fechaContador.plusDays(7);
            } while ( fechaContador.getMonthValue() == fechaInicial.getMonthValue());



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Hemos encontrado " + contadorDomingos + 
                    " domingos: ");
            System.out.println (listaDomingos);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}