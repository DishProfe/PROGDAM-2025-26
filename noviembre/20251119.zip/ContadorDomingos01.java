
package ejemplos2025;

/**
 * Programa Cuenta cu�ntos domingos hay en un mes
 * @author diosdado
 */

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Scanner;


public class ContadorDomingos01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int mes;
            int year;




            // Variables de salida
            String listaDomingos;
            int contadorDomingos;


            // Variables auxiliares
            LocalDate fechaInicial;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CONTADOR DE DOMINGOS EN UN MES");
            System.out.println("------------------------------");
            System.out.println("Introduzca mes y a�o");
            mes = teclado.nextInt();
            year = teclado.nextInt();
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            listaDomingos = "";
            contadorDomingos = 0;
            fechaInicial = LocalDate.of (year, mes, 1);
            LocalDate fechaContador = fechaInicial;
            do {
                DayOfWeek diaSemana = fechaContador.getDayOfWeek();
                if ( diaSemana == DayOfWeek.SUNDAY ) {
                    listaDomingos += fechaContador + "\n";
                    contadorDomingos++;
                }
                fechaContador = fechaContador.plusDays(1);
            } while ( fechaContador.getMonthValue() == fechaInicial.getMonthValue());



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Hemos encontrado " + contadorDomingos + 
                    " domingos: ");
            System.out.println (listaDomingos);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}