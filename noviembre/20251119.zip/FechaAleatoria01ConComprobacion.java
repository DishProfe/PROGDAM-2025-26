package ejemplos2025;

/**
 * Programa Fecha Aleatoria del a�o actual
 * @author diosdado
 */

import java.time.LocalDate;
import java.util.Scanner;

public class FechaAleatoria01ConComprobacion {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida
            LocalDate fechaAleatoria = null;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("FECHA ALEATORIA DEL A�O ACTUAL");
            System.out.println("------------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            LocalDate fechaActual = LocalDate.now();
            int yearActual = fechaActual.getYear();
            LocalDate fechaInicial = LocalDate.of (yearActual, 1, 1);
            int longYear = fechaActual.lengthOfYear();
            
            boolean dic31= false;
            boolean ene01 = false;
            int contador;
            for (contador=1 ;  !dic31 || !ene01  ; contador++ ) {
                int sumaDiasAleatorio = (int)(Math.random()*longYear);
                fechaAleatoria = fechaInicial.plusDays(sumaDiasAleatorio);
                if ( fechaAleatoria.getMonthValue()==12 && fechaAleatoria.getDayOfMonth()==31) {
                    dic31  = true;
                    System.out.println (fechaAleatoria);
                }
                if ( fechaAleatoria.getMonthValue()==1 && fechaAleatoria.getDayOfMonth()==1) {
                    ene01  = true;
                    System.out.println (fechaAleatoria);
                }
            }        
            System.out.println ("Se han generado " + contador + " fechas.");
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println (fechaAleatoria);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}