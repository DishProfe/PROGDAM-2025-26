
package ejemplos2025;

/**
 * Programa Tabla de aleatorios
 * @author diosdado
 */

import java.util.InputMismatchException;
import java.util.Scanner;


public class TablaAleatorios05 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numFilas=0, numColumnas=0;



            // Variables de salida



            // Variables auxiliares
            double aleatorio;
            double aleatorioAnterior;
            boolean entradaValida;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("TABLA DE N�MEROS ALEATORIOS");
            System.out.println("---------------------------");
            
            entradaValida = false;
            do {
                System.out.println("N�mero de filas (1-10): ");
                try {
                    numFilas = teclado.nextInt();
                    entradaValida = numFilas>=1 && numFilas<=10;
                    if (!entradaValida) {
                        System.out.println("El n�mero debe estar en el rango 1-10.");
                    }
                } catch ( InputMismatchException ex) {
                    System.out.println("Debe introducir un n�mero entero.");
                    String basura = teclado.nextLine();
                }
            } while ( !entradaValida );

            entradaValida = false;
            do {
                System.out.println("N�mero de columnas (1-10): ");
                try {
                    numColumnas = teclado.nextInt();
                    entradaValida = numColumnas>=1 && numColumnas<=10;
                    if (!entradaValida) {
                        System.out.println("El n�mero debe estar en el rango 1-10.");
                    }
                } catch ( InputMismatchException ex) {
                    System.out.println("Debe introducir un n�mero entero.");
                    String basura = teclado.nextLine();
                }
            } while ( !entradaValida );

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Primera fila delimitadora
            System.out.print ("+");
            for ( int contador=1 ; contador<=numColumnas ; contador++ ) {
                System.out.print ("-------+");
            }
            System.out.println();

            // Recorrido para cada fila
            for ( int fila= 0  ; fila<numFilas  ; fila++ ) {
                // Recorrido para cada columna dentro de cada fila
                aleatorioAnterior = 10*fila;
                for ( int columna=0 ; columna<numColumnas ; columna++ ) {    
                    aleatorio = aleatorioAnterior + (Math.random()*(10*(fila+1)-aleatorioAnterior-0.01));         
                    System.out.printf ("| %5.2f ", aleatorio);
                    aleatorioAnterior = aleatorio;
                }
                // Cierre de la fila (l�mite derecho)
                System.out.println("|");

                // Fila delimitadora (bajo la fila que acabamos de escribir)
                System.out.print ("+");
                for ( int contador=1 ; contador<=numColumnas ; contador++ ) {
                    System.out.print ("-------+");
                }
                System.out.println();
            }

            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}