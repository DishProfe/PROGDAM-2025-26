
package ejemplos2025;


import java.util.Scanner;
import java.util.InputMismatchException;
import aguadulce.Dado;

/**
 *   Programa
 */

    public class Dados06Cara6VariasVecesSeguidas {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        int limiteVecesSeguidas6 = 0;
        
        
        // Variables de salida



        // Variables auxiliares
        Dado dado;


        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        // Creamos un objeto instancia de la clase Dado
        dado = new Dado();

        System.out.println("EJEMPLOS CON DADOS");
        System.out.println("------------------");
        System.out.println("Introduzca cu�ntas veces quiere que salga seguido SEIS para parar.");

        do {
            try {
                limiteVecesSeguidas6 = teclado.nextInt();
            } catch ( InputMismatchException ex ) {
                teclado.nextLine();
            }
        } while ( limiteVecesSeguidas6<0 );
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        
        String lanzamiento;
        int vecesSeguidas6 = 0;
        do {
            lanzamiento = dado.lanzar();
            System.out.println (lanzamiento);
            if ( lanzamiento.equals("SEIS") ) {
                vecesSeguidas6++;
            } else {
                vecesSeguidas6 = 0;
            }            
        } while (  vecesSeguidas6 < limiteVecesSeguidas6 );
        
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        System.out.printf ("Se han hecho %d lanzamientos.\n", dado.getNumeroLanzamientos());
        for (int cara=1 ; cara<=6 ; cara++) {
            System.out.printf ("Cara %d: %d.\n", cara,dado.getNumeroVecesCara(cara));
        }
        

        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}