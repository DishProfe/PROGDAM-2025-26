
package ejemplos2025;

/**
 * Programa Tabla de aleatorios
 * @author diosdado
 */

import java.util.Scanner;


public class TablaAleatorios02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares
            double aleatorio;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("TABLA DE N�MEROS ALEATORIOS");
            System.out.println("---------------------------");
            System.out.println();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------


            System.out.println("+----------------------------+");  // 5*numColumnas + 2*(numColumnas-1)
            
            for ( int fila= 0  ; fila<4  ; fila++ ) {
                System.out.print("|");
                for ( int columna=0 ; columna<4 ; columna++ ) {    
                    aleatorio = 10*fila + (Math.random()*10);            
                    System.out.printf (" %5.2f ", aleatorio);
                }
                System.out.print("|");
                System.out.printf("\n");
            
            }

            System.out.println("+----------------------------+");  // 5*numColumnas + 2*(numColumnas-1)
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}