
package ejemplosunidad03;

/**
 * Programa N�meros aleatorios
 * @author diosdado
 */

import java.util.Scanner;


public class Aleatorios03 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int valInicial;
            int valFinal;
            int cantidadNumeros;



            // Variables de salida
            double numeroAleatorio;



            // Variables auxiliares

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("N�MEROS ALEATORIOS");
            System.out.println("------------------");
            System.out.println ("Introduzca valor inicial, valor final y cantidad de n�meros aleatorios a generar:");
            valInicial = teclado.nextInt();
            valFinal = teclado.nextInt();
            cantidadNumeros = teclado.nextInt();
            

            //----------------------------------------------
            //                 Procesamiento 
            //                      +
            //              Salida de resultados 
            //----------------------------------------------

            
            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            int anchura = valFinal - valInicial + 1;
            System.out.println ("Aleatorios int entre " + 
                    valInicial + " y " + valFinal + ": ");
            for ( int contador = 1 ; contador <= cantidadNumeros ; contador++  ) {
                numeroAleatorio = valInicial + (anchura * Math.random());
                System.out.println (numeroAleatorio);
            }            
            
            



            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}