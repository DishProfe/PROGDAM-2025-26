
package ejemplosunidad03;

/**
 * Programa N�meros aleatorios
 * @author diosdado
 */

import java.util.Scanner;


public class Aleatorios06 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int NUM_CARAS = 6;
            

            // Variables de entrada
            int cantidadLanzamientos;



            // Variables de salida
            int resultadoDado;



            // Variables auxiliares

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("TIRADA DE DADO");
            System.out.println("--------------");
            System.out.println ("Introduzca n�mero de lanzamientos:");
            cantidadLanzamientos = teclado.nextInt();
            

            //----------------------------------------------
            //                 Procesamiento 
            //                      +
            //              Salida de resultados 
            //----------------------------------------------

            
            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Lanzamos un dado " + cantidadLanzamientos + " veces: ");
            for ( int contador = 1 ; contador <= cantidadLanzamientos ; contador++  ) {
                resultadoDado = 1 + (int)(Math.random() * NUM_CARAS);
                System.out.print (resultadoDado + " ");
            }            
            
            



            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}