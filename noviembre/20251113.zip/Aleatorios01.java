
package ejemplosunidad03;

/**
 * Programa N�meros aleatorios
 * @author diosdado
 */

import java.util.Scanner;


public class Aleatorios01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares
            double numero;
            int numeroEntero;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("N�MEROS ALEATORIOS");
            System.out.println("------------------");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            System.out.println ("Aleatorios double entre 0-1: ");
            for ( int contador = 1 ; contador <= 5 ; contador++  ) {
                numero = Math.random();
                System.out.println (numero);
            }
            System.out.println ();
            
            System.out.println ("Aleatorios double entre 0-9: ");
            for ( int contador = 1 ; contador <= 5 ; contador++  ) {
                numero = 10 * Math.random();
                System.out.println (numero);
            }
            System.out.println ();
            
            System.out.println ("Aleatorios int entre 0-9: ");
            for ( int contador = 1 ; contador <= 5 ; contador++  ) {
                numeroEntero = (int) (10 * Math.random());
                System.out.println (numeroEntero);
            }
            System.out.println ();

            System.out.println ("Aleatorios int entre 1-10: ");
            for ( int contador = 1 ; contador <= 5 ; contador++  ) {
                numeroEntero = 1 + (int) (10 * Math.random());
                System.out.println (numeroEntero);
            }
            
            System.out.println ("Aleatorios int entre 0-10: ");
            for ( int contador = 1 ; contador <= 5 ; contador++  ) {
                numeroEntero = (int) (11 * Math.random());
                System.out.println (numeroEntero);
            }

            System.out.println ("Aleatorios int entre 10-19: ");
            for ( int contador = 1 ; contador <= 5 ; contador++  ) {
                numeroEntero = 10 + (int) (10 * Math.random());
                System.out.println (numeroEntero);
            }

            System.out.println ("Aleatorios int entre 10-20: ");
            for ( int contador = 1 ; contador <= 5 ; contador++  ) {
                numeroEntero = 10 + (int) (11 * Math.random());
                System.out.println (numeroEntero);
            }

            System.out.println ("Aleatorios int entre -5 y +4: ");
            for ( int contador = 1 ; contador <= 5 ; contador++  ) {
                numeroEntero = -5 + (int) (10 * Math.random());
                System.out.println (numeroEntero);
            }

            System.out.println ("Aleatorios int entre -5 y +5: ");
            for ( int contador = 1 ; contador <= 5 ; contador++  ) {
                numeroEntero = -5 + (int) (11 * Math.random());
                System.out.println (numeroEntero);
            }
            
            int valInicial = -3;
            int valFinal = +7;
            int cantidadNumeros = valFinal - valInicial + 1;
            System.out.println ("Aleatorios int entre " + 
                    valInicial + " y " + valFinal + ": ");
            for ( int contador = 1 ; contador <= 5 ; contador++  ) {
                numeroEntero = valInicial + (int) (cantidadNumeros * Math.random());
                System.out.println (numeroEntero);
            }            
            
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}