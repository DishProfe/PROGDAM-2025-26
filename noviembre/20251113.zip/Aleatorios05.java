
package ejemplosunidad03;

/**
 * Programa N�meros aleatorios
 * @author diosdado
 */

import java.util.Scanner;


public class Aleatorios05 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int cantidadLanzamientos;



            // Variables de salida
            String resultadoFinal;



            // Variables auxiliares

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CARA O CRUZ");
            System.out.println("------------------");
            System.out.println ("Introduzca n�mero de lanzamientos:");
            cantidadLanzamientos = teclado.nextInt();
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            
            System.out.println ("Lanzamos una moneda " + cantidadLanzamientos + " veces: ");
            resultadoFinal = "";
            for ( int contador = 1 ; contador <= cantidadLanzamientos ; contador++  ) {
                resultadoFinal += (Math.random() < 0.5 ? "CARA" : "CRUZ") + " ";
            }            
            
            
            //----------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------
            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println (resultadoFinal);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}