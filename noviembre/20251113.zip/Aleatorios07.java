
package ejemplosunidad03;

/**
 * Programa N�meros aleatorios
 * @author diosdado
 */

import java.util.Scanner;


public class Aleatorios07 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            

            // Variables de entrada
            final int numCaras;
            int cantidadLanzamientos;



            // Variables de salida
            int resultadoDado;



            // Variables auxiliares

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("TIRADA DE DADO");
            System.out.println("--------------");
            System.out.println ("Introduzca n�mero de caras:");
            numCaras = teclado.nextInt();
            System.out.println ("Introduzca n�mero de lanzamientos:");
            cantidadLanzamientos = teclado.nextInt();
            

            //----------------------------------------------
            //                 Procesamiento 
            //                      +
            //              Salida de resultados 
            //----------------------------------------------

            
            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Lanzamos un dado " + cantidadLanzamientos + " veces: ");
            for ( int contador = 1 ; contador <= cantidadLanzamientos ; contador++  ) {
                resultadoDado = 1 + (int)(Math.random() * numCaras);
                System.out.print (resultadoDado + " ");
            }            
            
            



            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}