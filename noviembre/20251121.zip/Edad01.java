
package ejemplos2025;

/**
 * Programa C�lculo de la edad a partir de la fecha de nacimiento
 * @author diosdado
 */

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;


public class Edad01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int dia, mes, year;



            // Variables de salida
            int edadYears;
            int edadMeses;
            int edadSemanas;
            int edadDias;
            int edadDecadas;


            // Variables auxiliares
            LocalDate fechaNacim;
            LocalDate fechaActual;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO DE LA EDAD");
            System.out.println("------------------");
            System.out.println("Introduzca fecha de nacimiento (dia, mes, a�o)");
            dia =teclado.nextInt();
            mes =teclado.nextInt();
            year =teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            fechaNacim = LocalDate.of (year, mes, dia);
            fechaActual = LocalDate.now();

            edadYears = (int) fechaNacim.until (fechaActual, ChronoUnit.YEARS);
            edadMeses = (int) fechaNacim.until (fechaActual, ChronoUnit.MONTHS);
            edadSemanas = (int) fechaNacim.until (fechaActual, ChronoUnit.WEEKS);
            edadDias = (int) fechaNacim.until (fechaActual, ChronoUnit.DAYS);
            edadDecadas = (int) fechaNacim.until (fechaActual, ChronoUnit.DECADES);

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("La edad es: " + edadYears + " a�os.");
            System.out.println ("La edad es: " + edadMeses + " meses.");
            System.out.println ("La edad es: " + edadSemanas + " semanas.");
            System.out.println ("La edad es: " + edadDias + " d�as.");
            System.out.println ("La edad es: " + edadDecadas + " d�cadas.");

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}