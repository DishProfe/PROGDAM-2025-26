package ejemplos2025;

import java.time.LocalDateTime;
import java.time.Month;
import java.time.temporal.ChronoUnit;

/**
 *
 * @author profe
 */
public class EjemploChronoUnitBetween01 {

    public static void main(String[] args) {

        
        // Entrada de datos: autom�tica
        System.out.println("EJEMPO DE USO DE BETWEEN DE CHRONOUNIT");
        System.out.println("--------------------------------------");
        System.out.println();
        
        
        // Instante 1: 31/08/1982 10:20:55
        LocalDateTime fecha1 = LocalDateTime.of(1982, Month.AUGUST, 31, 10, 20, 55);
        // Instante 1: 09/11/2016 10:21:56
        LocalDateTime fecha2 = LocalDateTime.of(2016, Month.NOVEMBER, 9, 10, 21, 56);

        System.out.printf("Instante 1: %s\n", fecha1);
        System.out.printf("Instante 2: %s\n", fecha2);

        // Procesamiento
        // Tiempo entre las dos fechas. M�todo est�tico between del enum ChronoUnit
        long years = ChronoUnit.YEARS.between(fecha1, fecha2);
        long months = ChronoUnit.MONTHS.between(fecha1, fecha2);
        long weeks = ChronoUnit.WEEKS.between(fecha1, fecha2);
        long days = ChronoUnit.DAYS.between(fecha1, fecha2);
        long hours = ChronoUnit.HOURS.between(fecha1, fecha2);
        long minutes = ChronoUnit.MINUTES.between(fecha1, fecha2);
        long seconds = ChronoUnit.SECONDS.between(fecha1, fecha2);
        long milis = ChronoUnit.MILLIS.between(fecha1, fecha2);
        long nano = ChronoUnit.NANOS.between(fecha1, fecha2);

        // Salida de resultados
        System.out.println("\n--- Total --- ");
        System.out.println(years + " years");
        System.out.println(months + " months");
        System.out.println(weeks + " weeks");
        System.out.println(days + " days");
        System.out.println(hours + " hours");
        System.out.println(minutes + " minutes");
        System.out.println(seconds + " seconds");
        System.out.println(milis + " milis");
        System.out.println(nano + " nano");

    }    
}
