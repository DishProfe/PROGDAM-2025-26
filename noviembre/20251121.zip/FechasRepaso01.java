package ejemplos2025;


import java.util.Scanner;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 *   Programa
 */

    public class FechasRepaso01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        
        
        // Variables de salida
        LocalDate fecha1, fecha2, fecha3, fecha4, fecha5;
        LocalDate fecha6, fecha7;
        LocalDate fechaActual;


        // Variables auxiliares
        


        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("TRABAJO CON FECHAS");
        System.out.println("------------------");
        System.out.println(" ");

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
            
        fecha1= LocalDate.of (1941, 12, 7);
        System.out.println ("fecha1 = " + fecha1.toString());
        System.out.println ("fecha1.lengthOfYear = " + fecha1.lengthOfYear());
        System.out.println();
        
        fecha2 = LocalDate.of (2024, 1, 1);
        System.out.println ("fecha2 = " + fecha2.toString());
        System.out.println ("fecha2.lengthOfYear() = " + fecha2.lengthOfYear());
        System.out.println ("fecha2.getDayOfWeek() = " + fecha2.getDayOfWeek());
        System.out.println();
        
        fecha3 = fecha2.minusDays(1);
        System.out.println ("fecha2.minusDays(1) = " + fecha3);
        System.out.println();
        
        fecha3 = fecha3.minusDays(300);
        System.out.println ("fecha3.minusDays(300) = " + fecha3);
        System.out.println();
        
        fecha4 = fecha2.plusWeeks(2);
        System.out.println ("fecha4= fecha2.plusWeeks(2) = " + fecha4);
        System.out.println ("fecha4.getDayOfWeek() = " + fecha4.getDayOfWeek());
        System.out.println ("fecha4.getDayOfWeek() = " + fecha4.getDayOfMonth());
        System.out.println();

        fecha5 = fecha4.plusMonths(1);
        System.out.println ("fecha5= fecha4.plusMonths(1) = " + fecha5);
        System.out.println ("fecha4.getDayOfWeek() = " + fecha5.getDayOfMonth());
        System.out.println();
        
        fecha6 = LocalDate.of (1941, 12, 7);
        System.out.println ("fecha1= " + fecha1);
        System.out.println ("fecha6= " + fecha6);
        System.out.println ("fecha1 == fecha6 : " + (fecha1 == fecha6) );
        System.out.println ("fecha1.equals(fecha6): " + (fecha1.equals(fecha6)) );
        System.out.println ("fecha6.equals(fecha1): " + (fecha6.equals(fecha1)) );
        System.out.println();
        
        fecha7 = fecha1;
        System.out.println ("fecha1= " + fecha1);
        System.out.println ("fecha6= " + fecha6);
        System.out.println ("fecha7= " + fecha7);
        System.out.println ("fecha1 == fecha7 : " + (fecha1 == fecha7) );
        System.out.println ("fecha6 == fecha7 : " + (fecha6 == fecha7) );
        System.out.println ("fecha1.equals(fecha7): " + (fecha1.equals(fecha7)) );
        System.out.println ("fecha6.equals(fecha7): " + (fecha6.equals(fecha7)) );
        System.out.println();
        
        
        //fecha1 < fecha2
        System.out.println ("fecha1 < fecha2 -> fecha1.isBefore (fecha2): " + fecha1.isBefore (fecha2));
        System.out.println ("fecha1 > fecha2 -> fecha1.isAfter (fecha2): " + fecha1.isAfter(fecha2));
        System.out.println ("fecha2 >= fecha1 -> !fecha1.isBefore(fecha2): " + !fecha1.isBefore(fecha2) );
        System.out.println ("fecha2 >= fecha1 -> fecha1.isAfter(fecha2) || fecha1.equals(fecha2): " + (fecha1.isAfter(fecha2) || fecha1.equals(fecha2)) );
        System.out.println ("fecha1.compareTo(fecha2): " + fecha1.compareTo(fecha2));
        System.out.println ("fecha2.compareTo(fecha1): " + fecha2.compareTo(fecha1));
        System.out.println ("fecha1.compareTo(fecha6): " + fecha1.compareTo(fecha6));
        System.out.println ("fecha6.compareTo(fecha1): " + fecha6.compareTo(fecha1));
        System.out.println();

        fechaActual = LocalDate.now();
        System.out.println ("fecha1.until(fechaActual, ChronoUnit.YEARS) = " + 
                fecha1.until(fechaActual, ChronoUnit.YEARS) );
        System.out.println ("fecha1.until(fechaActual, ChronoUnit.MONTHS) = " + 
                fecha1.until(fechaActual, ChronoUnit.MONTHS) );
        System.out.println ("fecha1.until(fechaActual, ChronoUnit.WEEKS) = " + 
                fecha1.until(fechaActual, ChronoUnit.WEEKS) );
        System.out.println ("fecha1.until(fechaActual, ChronoUnit.CENTURIES) = " + 
                fecha1.until(fechaActual, ChronoUnit.CENTURIES) );
        System.out.println ("fechaActual.until(fecha1, ChronoUnit.YEARS) = " + 
                fechaActual.until(fecha1, ChronoUnit.YEARS) );

        System.out.println ("ChronoUnit.MONTHS.between(fecha1, fechaActual) = " + 
                ChronoUnit.MONTHS.between(fecha1, fechaActual));
                
        
                
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}