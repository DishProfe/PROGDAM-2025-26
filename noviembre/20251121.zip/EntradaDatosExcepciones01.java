
package ejemplos2025;

/**
 * Programa Gesti�n de entrada de datos con excepciones
 * @author diosdado
 */

import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Scanner;


public class EntradaDatosExcepciones01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero = 0;



            // Variables de salida
            int suma;


            // Variables auxiliares
            int contador;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("SUMA DE N�MEROS ENTEROS");
            System.out.println("-----------------------");

            boolean entradaValida;
            do {
                System.out.println("Introduzca n�mero > 1");

                try {
                    numero = teclado.nextInt();
                    entradaValida = numero>1;
                } catch ( InputMismatchException ex ) {
                    entradaValida = false;
                    teclado.nextLine();
                }

            } while ( !entradaValida );
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            suma = 0;
            for ( contador = 1; contador <= numero ; contador++ ) {
                suma += contador;
            }

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("La suma desde 1 hasta " + numero + " es : " + suma);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}