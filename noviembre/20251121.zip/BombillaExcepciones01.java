
package ejemplos2025;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;
import aguadulce.Bombilla;
import java.util.InputMismatchException;


public class BombillaExcepciones01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            double vatios;



            // Variables de salida
            Bombilla b1 = null;


            // Variables auxiliares
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("PRUEBA DE EXCEPCIONES CON LA CLASE BOMBILLA");
            System.out.println("-------------------------------------------");

            boolean entradaValida = false;
            do {
                System.out.println("Introduzca potencia de la bombilla:");
                try {
                    vatios = teclado.nextDouble();
                    System.out.println ("Intentando crear bombilla de " + vatios + "  vatios.");
                    b1 = new Bombilla (vatios);
                    entradaValida = true;
                    System.out.println ("Bombilla b1 creada correctamente.");                    
                }
                catch ( InputMismatchException ex ) {
                    System.out.println("Error. Debe introducir un n�mero entero.");
                    teclado.nextLine();
                }
                catch (IllegalArgumentException ex) {
                    System.out.println("Error en la creaci�n de la bombilla. " + ex.getMessage());
                }
            } while ( !entradaValida );
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Objeto bombilla b1 = " + b1.toString() );

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}