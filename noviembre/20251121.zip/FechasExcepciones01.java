
package ejemplos2025;

/**
 * Programa Fechas con errores
 * @author diosdado
 */

import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.Scanner;


public class FechasExcepciones01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int dia, mes, year;



            // Variables de salida
            LocalDate fecha = null;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("GESTI�N DE FECHAS CON ERRORES");
            System.out.println("-----------------------------");

            boolean fechaCorrecta = false;
            do {            
                System.out.println("Introduzca fecha (d�a, mes, a�o)");
                dia = teclado.nextInt();
                mes = teclado.nextInt();
                year = teclado.nextInt();

                // Intentamos crear el objeto fecha
                try {
                    fecha = LocalDate.of (year, mes, dia);
                    fechaCorrecta = true;
                } catch ( DateTimeException ex ) {
                    System.out.println ("Fecha inv�lida.");
                    System.out.println ("Excepci�n: " + ex.getMessage());
                }

            } while ( !fechaCorrecta );
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("La fecha introducida es: " + fecha);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}