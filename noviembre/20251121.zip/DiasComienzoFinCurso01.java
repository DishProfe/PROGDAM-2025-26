
package ejemplos2025;

/**
 * Programa D�as desde y hasta comienzo y fin de curso
 * @author diosdado
 */

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;


public class DiasComienzoFinCurso01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            



            // Variables de salida
            int diasDesdeInicio;
            int diasHastaFin;


            // Variables auxiliares
            LocalDate inicioCurso, finCurso;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMIENZO Y FIN DE CURSO");
            System.out.println("-----------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            LocalDate fechaActual = LocalDate.now();
            int YearActual = fechaActual.getYear();
            inicioCurso = LocalDate.of (YearActual, 9, 15);
            finCurso = LocalDate.of (YearActual+1, 6, 22);

            diasDesdeInicio = (int) inicioCurso.until (fechaActual, ChronoUnit.DAYS);
            diasHastaFin = (int) fechaActual.until (finCurso, ChronoUnit.DAYS);



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println("D�as pasados desde inicio de curso: " + diasDesdeInicio );
            System.out.println("D�as que faltan hasta fin de curso: " + diasHastaFin );

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}