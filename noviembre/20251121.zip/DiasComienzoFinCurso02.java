
package ejemplos2025;

/**
 * Programa D�as desde y hasta comienzo y fin de curso
 * @author diosdado
 */

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;


public class DiasComienzoFinCurso02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            



            // Variables de salida
            int diasDesdeInicio;
            int mesesDesdeInicio;
            int diasHastaFin;
            int mesesHastaFin;


            // Variables auxiliares
            LocalDate inicioCurso, finCurso;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMIENZO Y FIN DE CURSO");
            System.out.println("-----------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            LocalDate fechaActual = LocalDate.now();
            int YearActual = fechaActual.getYear();
            inicioCurso = LocalDate.of (YearActual, 9, 15);
            finCurso = LocalDate.of (YearActual+1, 6, 22);

            diasDesdeInicio = (int) inicioCurso.until (fechaActual, ChronoUnit.DAYS);
            mesesDesdeInicio = (int) inicioCurso.until (fechaActual, ChronoUnit.MONTHS);
            diasDesdeInicio = diasDesdeInicio - mesesDesdeInicio*30;            
            
            diasHastaFin = (int) fechaActual.until (finCurso, ChronoUnit.DAYS);
            mesesHastaFin = (int) fechaActual.until (finCurso, ChronoUnit.MONTHS);
            diasHastaFin = diasHastaFin - mesesHastaFin*30;            



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println("D�as pasados desde inicio de curso: " + 
                    mesesDesdeInicio + " meses y " + diasDesdeInicio  + " d�as");
            System.out.println("D�as que faltan hasta fin de curso: " + 
                    mesesHastaFin + " meses y " + diasHastaFin + " d�as");

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}