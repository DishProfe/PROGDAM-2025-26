
package ejemplosunidad03;

/**
 * Programa Ejemplos de uso de objetos
 * @author diosdado
 */

import java.util.Scanner;
import aguadulce.Bombilla;
import aguadulce.Dado;
import aguadulce.Ticket;
import aguadulce.CuentaBancaria;



public class Objetos01 {
 
	public static void main(String[] args) throws InterruptedException  {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares
            Bombilla b1, b2, b3;
            Dado d1, d2;
            Ticket t1, t2;
            CuentaBancaria cuenta1, cuenta2;
            
            
            
            


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE USO DE OBJETOS");
            System.out.println("--------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------


            b1 = new Bombilla ();

            // Mostramos el estado de la bombilla
            System.out.println ("Estado de b1: " + b1.getEstado() );

            // Mostramos la potencia de la bombilla
            System.out.println ("Potencia de b1: " + b1.getPotencia() + " vatios");

            // Mostramos el tiempo que ha estado la bombilla encendida
            System.out.println ("Tiempo encendida de b1: " + b1.getTiempoEncendida() + " segundos");

            
            // Encendemos la bombilla
            System.out.println("Encendemos la bombilla...");
            b1.encender();

            // Mostramos el estado de la bombilla
            System.out.println ("Estado de b1: " + b1.getEstado() );

            // Paramos 5 segundos
            System.out.println ("Paramos 5 segundos");
            Thread.sleep(5000);
            
            // Mostramos el tiempo que ha estado la bombilla encendida
            System.out.println ("Tiempo encendida de b1: " + b1.getTiempoEncendida() + " segundos");

            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}