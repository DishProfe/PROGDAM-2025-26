
package ejemplos2025;

/**
 * Programa Detector de n�mero primo
 * @author diosdado
 */

import java.util.Scanner;


public class Primos05break {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            long numero;



            // Variables de salida
            boolean esPrimo;


            // Variables auxiliares
            int candidatoDivisor;
            int numDivisores;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBADOR DE N�MERO PRIMO");
            System.out.println("---------------------------");
            System.out.println("Introduzca n�mero entero > 1");
            numero = teclado.nextLong();

            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Iniciamos a cero la cantidad de divisores encontrados
            numDivisores = 0;
            
            esPrimo = true;
            
            // Si es divisible entre 2, ya no es primo
            if ( numero % 2 == 0) {
                esPrimo = false;
            }
            
            // Compruebo con el resto de n�meros a partir de 3 y voy de 2 en 2
            // Y cuando lleguemos a la ra�z cuadrada ya no tiene sentido seguir 
            // buscando divisores si a�n no hab�amos encontrados
            candidatoDivisor = 3;
            while ( candidatoDivisor <= Math.sqrt(numero) && esPrimo ) {                
                if ( numero % candidatoDivisor == 0) {
                    // Si es divisible entre el candidato entonces ese candidato es un divisor
                    esPrimo = false;
                    break;
                }
                // Incrementamos el posible divisior para seguir probando
                candidatoDivisor += 2;    
            }



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El n�mero " + numero + 
                    (esPrimo ? "" : " no") + " es primo.");


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}