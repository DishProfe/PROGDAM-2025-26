
package ejemplos2025;

/**
 * Programa C�lculo de divisores
 * @author diosdado
 */

import java.util.Scanner;


public class Divisores02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;




            // Variables de salida



            // Variables auxiliares
            int candidatoDivisor;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO DE DIVISORES");
            System.out.println("--------------------");
            System.out.println("Introduzca n�mero > 1: ");
            numero = teclado.nextInt();
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            candidatoDivisor = 2;
            
            while ( candidatoDivisor <= numero/2 ) {
                
                if ( numero % candidatoDivisor == 0) {
                    // Si es divisible entre el candidato entonces ese candidato es un divisor
                    System.out.println (candidatoDivisor);
                }
                
                candidatoDivisor++;
                
            }
            



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}