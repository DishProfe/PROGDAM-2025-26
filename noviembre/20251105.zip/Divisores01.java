
package ejemplos2025;

/**
 * Programa C�lculo de divisores
 * @author diosdado
 */

import java.util.Scanner;


public class Divisores01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;




            // Variables de salida



            // Variables auxiliares
            int contador;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO DE DIVISORES");
            System.out.println("--------------------");
            System.out.println("Introduzca n�mero > 1: ");
            numero = teclado.nextInt();
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            contador = 2;
            
            while ( contador < numero ) {
                
                if ( numero % contador == 0) {
                    // Si es divisible entre contador entonces contador es un divisor
                    System.out.println (contador);
                }
                
                contador++;
                
            }
            



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}