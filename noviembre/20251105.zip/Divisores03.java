
package ejemplos2025;

/**
 * Programa C�lculo de divisores
 * @author diosdado
 */

import java.util.Scanner;


public class Divisores03 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;




            // Variables de salida
            String listaDivisores;


            // Variables auxiliares
            int candidatoDivisor;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO DE DIVISORES");
            System.out.println("--------------------");
            System.out.println("Introduzca n�mero > 1: ");
            numero = teclado.nextInt();
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Inciamos contador de posibles divisores
            candidatoDivisor = 2;
            
            // Iniciamos acumulador de texto con los divisores encontrador
            listaDivisores = "";
            
            while ( candidatoDivisor <= numero/2 ) {                
                if ( numero % candidatoDivisor == 0) {
                    // Si es divisible entre el candidato entonces ese candidato es un divisor
                    listaDivisores += candidatoDivisor + " ";
                }
                // Incrementamos el posible divisior para seguir probando
                candidatoDivisor++;                
            }
            



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Los divisores de " + numero + " son: ");
            System.out.println (listaDivisores);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}