package ejemplos2025;

/**
 * Programa An�lisis de n�meros
 *
 * @author diosdado
 */
import java.util.Scanner;

public class AnalisisNumerico01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------
        // Constantes
        // Variables de entrada
        int numero;

        // Variables de salida
        int numElementos;
        boolean esPar;
        boolean esPrimo;
        int cantidadPrimos;
        int cantidadPares;
        int cantidadDivisores;
        int cantidadDivisoresTotales;

        // Variables auxiliares
        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("AN�LISIS NUM�RICO");
        System.out.println("-----------------");

        // Inicializamos contadores
        numElementos = 0;
        cantidadPares = 0;
        cantidadPrimos = 0;
        cantidadDivisoresTotales = 0;

        do {
            // Vamos pidiendo n�meros hasta que se introduzca un n�mero < 2
            System.out.println("Introduzca n�mero entero (>1): ");
            numero = teclado.nextInt();

            // Vamos analizando los n�meros introducidos
            if (numero > 1) {

                // Y contamos
                numElementos++;

                // Comprobaci�n de si es par o no
                esPar = numero % 2 == 0;

                // Comprobaci�n de si es primo o no
                // Si es 2 es directamente primo
                esPrimo = numero==2 ? true : numero % 2 != 0;
                // Si no es 2 pero es divisible entre 2, no es primo

                // Si no es 2 ni divisible entre 2, vamos a intentar encontrar un divisor
                int divisor = 3;
                while (divisor < Math.sqrt(numero) && esPrimo) {
                    if (numero % divisor == 0) {
                        esPrimo = false;
                    }
                    divisor +=2;
                }

                // C�lculo n�mero de divisores
                cantidadDivisores = 0;
                divisor = 2;
                while (divisor <= numero / 2) {
                    if (numero % divisor == 0) {
                        cantidadDivisores++;
                    }
                    divisor++;
                }

                // Mostramos an�lis del n�mero
                System.out.println("El n�mero es " + (esPar ? "par" : "impar"));
                System.out.println("El n�mero" + (esPrimo ? "" : " no") + " es primo");
                System.out.println("El n�mero tiene " + cantidadDivisores + " divisores");
                System.out.println();

                // Acumulamos totales usando los parciales de este n�mero
                if (esPrimo) {
                    cantidadPrimos++;
                }
                if (esPar) {
                    cantidadPares++;
                }
                cantidadDivisoresTotales += cantidadDivisores;

            }

        } while (numero > 1);

        //---------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");
        System.out.println("Total de n�meros: " + numElementos);
        System.out.println("Total de pares: " + cantidadPares);
        System.out.println("Total de impares: " + (numElementos - cantidadPares) );
        System.out.println("Total de primos: " + cantidadPrimos);
        System.out.println("Total de divisores: " + cantidadDivisoresTotales);
        System.out.println();

        System.out.println();
        System.out.println("Fin del programa.");

    }

}
