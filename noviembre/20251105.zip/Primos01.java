
package ejemplos2025;

/**
 * Programa Detector de n�mero primo
 * @author diosdado
 */

import java.util.Scanner;


public class Primos01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;



            // Variables de salida
            boolean esPrimo;


            // Variables auxiliares
            int candidatoDivisor;
            int numDivisores;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBADOR DE N�MERO PRIMO");
            System.out.println("---------------------------");
            System.out.println("Introduzca n�mero entero > 1");
            numero = teclado.nextInt();

            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Inciamos contador de posibles divisores
            candidatoDivisor = 2;
            
            // Iniciamos a cero la cantidad de divisores encontrados
            numDivisores = 0;
            
            
            while ( candidatoDivisor <= numero/2 ) {                
                if ( numero % candidatoDivisor == 0) {
                    // Si es divisible entre el candidato entonces ese candidato es un divisor
                    numDivisores++;
                }
                // Incrementamos el posible divisior para seguir probando
                candidatoDivisor++;                
            }

            esPrimo = numDivisores == 0;

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El n�mero " + numero + 
                    (esPrimo ? "" : " no") + " es primo.");


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}