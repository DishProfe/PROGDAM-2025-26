
package ejemplos2025;

/**
 * Programa Pir�mide de asteriscos con break
 * @author diosdado
 */

import java.util.Scanner;


public class PiramideAsteriscos02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numLineas;



            // Variables de salida



            // Variables auxiliares
            int fila;
            int columna;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("PIR�MIDE DE ASTERISCOS");
            System.out.println("----------------------");
            System.out.println("Introduzca n�mero de l�neas: ");
            numLineas = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            for ( fila=1 ;  ; fila++ ) {
                if ( fila > numLineas) {
                    break;
                }
                for ( columna = 1; ; columna++ ) {
                    if ( columna > fila ) {
                        break;
                    }
                    System.out.print ("*");
                }
                System.out.println ();
            }
            



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}