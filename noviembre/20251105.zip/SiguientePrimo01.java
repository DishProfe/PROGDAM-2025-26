
package ejemplos2025;

/**
 * Programa C�lculo del siguiente primo
 * @author diosdado
 */

import java.util.Scanner;


public class SiguientePrimo01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;




            // Variables de salida
            int siguientePrimo;


            // Variables auxiliares
            boolean primoEncontrado;
            int candidatoPrimo;

            boolean esPrimo;
            int divisor;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("SIGUIENTE PRIMO");
            System.out.println("---------------");
            System.out.println("Introduzca n�mero > 1");
            numero = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------


            // Empezamos a probar posibles primos a partir de numero+1
            candidatoPrimo = numero + 1;
            do {
                
                // Comprobaci�n de si es primo o no
                // Si es 2 es directamente primo
                esPrimo = candidatoPrimo==2 ? true : candidatoPrimo % 2 != 0;
                // Si no es 2 pero es divisible entre 2, no es primo

                // Si no es 2 ni divisible entre 2, vamos a intentar encontrar un divisor
                divisor = 3;
                while (divisor <= Math.sqrt(candidatoPrimo) && esPrimo) {
                    if (candidatoPrimo % divisor == 0) {
                        esPrimo = false;
                    }
                    divisor +=2;
                }
                
                if (!esPrimo) {
                    candidatoPrimo++;
                } 
                
                // El bucle termina cuando haya encontrado un primo
            } while ( !esPrimo );
            
            // El primo encontrado es el �ltimo candidato con el que se prob�            
            siguientePrimo = candidatoPrimo;
           




            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El siguiente primo es: " + siguientePrimo);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}