package ejemplos2025;

/**
 * Programa XXX
 *
 * @author diosdado
 */
import java.util.Scanner;

public class EjemploBreak01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------
        // Constantes
        // Variables de entrada
        // Variables de salida
        // Variables auxiliares
        // Declaraci�n de variables
        int contador;
                /* Este bucle s�lo se ejecutar� en 6 ocasiones, ya que cuando
        * la variable contador sea igual a 7 encontraremos un break que
        * romper� el flujo del bucle, transfiri�ndonos el control a la 
        * sentencia que imprime el  mensaje  de Fin del programa.
                 */
                
                
                
                
                
                
                
                
                
                
                
        for (contador = 1; contador <= 10; contador++) {
            if (contador == 7) {
                break;
            }
            System.out.println("Valor: " + contador); // Es una forma muy inapropiada de salir del bucle!!      
        }
        System.out.println("Fin del programa");
    }
}
