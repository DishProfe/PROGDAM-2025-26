
package ejemplos2025;

/**
 * Programa Pir�mide de asteriscos
 * @author diosdado
 */

import java.util.Scanner;


public class PiramideAsteriscos03 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numLineas;



            // Variables de salida
            String piramide;



            // Variables auxiliares
            int fila;
            int columna;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("PIR�MIDE DE ASTERISCOS");
            System.out.println("----------------------");
            System.out.println("Introduzca n�mero de l�neas: ");
            numLineas = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Valor inicial del acumulador String para la pir�mide
            piramide = "";
            
            for ( fila=1 ; fila<=numLineas; fila++ ) {

                for ( columna = 1; columna <= fila ; columna++ ) {
                    piramide += "*";
                }
                piramide += "\n";
            }
            



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println (piramide);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}