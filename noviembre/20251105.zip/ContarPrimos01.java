
package ejemplos2025;

/**
 * Programa C�lculo del siguiente primo
 * @author diosdado
 */

import java.util.Scanner;


public class ContarPrimos01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int inicio, fin;




            // Variables de salida
            int cantidadPrimos;


            // Variables auxiliares
            boolean primoEncontrado;
            int candidatoPrimo;

            boolean esPrimo;
            int divisor;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("SIGUIENTE PRIMO");
            System.out.println("---------------");
            System.out.println("Introduzca n�meros de inicio y fin");
            inicio = teclado.nextInt();
            fin = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------


            // Empezamos a probar posibles primos a partir de numero+1
            candidatoPrimo = inicio;
            cantidadPrimos = 0;
            do {
                
                // Comprobaci�n de si es primo o no
                // Si es 2 es directamente primo
                esPrimo = candidatoPrimo==2 ? true : candidatoPrimo % 2 != 0;
                // Si no es 2 pero es divisible entre 2, no es primo

                // Si no es 2 ni divisible entre 2, vamos a intentar encontrar un divisor
                divisor = 3;
                while (divisor <= Math.sqrt(candidatoPrimo) && esPrimo) {
                    if (candidatoPrimo % divisor == 0) {
                        esPrimo = false;
                    }
                    divisor +=2;
                }
                
                if (esPrimo) {
                    cantidadPrimos++;
                }
                candidatoPrimo++;
                
                // El bucle termina cuando haya encontrado un primo
            } while ( candidatoPrimo <= fin );
            
           




            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("La cantidad de primos entre " +
                    inicio + " y " + fin + " es: " + cantidadPrimos);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}