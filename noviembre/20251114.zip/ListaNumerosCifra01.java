
package ejemplos2025;

/**
 * Programa Localizador de cifras en n�meros
 * @author diosdado
 */

import java.util.Scanner;


public class ListaNumerosCifra01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes

            // Variables de entrada
            int inicioEntrada, finEntrada;
            int cifra;


            // Variables de salida
            String listaNumeros;
            int numsConCifra;


            // Variables auxiliares
            int inicio, fin;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("LOCALIZADOR DE CIFRA");
            System.out.println("--------------------");
            System.out.println("Introduzca valores inicial y final:");
            inicioEntrada = teclado.nextInt();
            finEntrada = teclado.nextInt();
            do {
                System.out.println("Introduzca la cifra a buscar (0-9):");
                cifra = teclado.nextInt();                
            } while ( cifra<0 || cifra>9 );
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Tomamos como inicio el valor m�s peque�o y como fin el m�s grande
            inicio = Math.min (inicioEntrada, finEntrada);
            fin = Math.max (inicioEntrada, finEntrada);
            
            // Iniciamos la lista de n�meros a la cadena vac�a
            listaNumeros = "";
            
            // Iniciamos la cantidad de n�meros encontrados a cero
            numsConCifra = 0;
            
            // Recorremos todos los n�meros enteros entre los valores inicial y final
            // Usamos una variable contador
            for ( int numero = inicio ; numero<= fin ; numero++ ) {

                // Comprobamos si cada n�mero (contador) contiene o no la cifra
                // Iniciamos el residuo al n�mero (contador)
                // Y lo iremos dividiendo entre 10 para ir obteniendo sus cifras (resto)
                int residuo = numero;
                boolean cifraEncontrada = false;
                // Vamos comprobando mientras nos queden cifras (residuo>0)
                while (residuo>0 && !cifraEncontrada ) {
                    // En cuanto alg�n resto coincida con la cifra, ya sabemos que contiene la cifra
                    cifraEncontrada = residuo % 10 == cifra;
                    residuo /= 10;
                }
                // Si se ha encontrado la cifra, a�adimos el n�mero (contador) a la lista
                // E incrementamos la cantidad de n�meros encontrados con la cifra
                if (cifraEncontrada) {
                    listaNumeros += numero + " ";  // A�adimos n�mero a la lista
                    numsConCifra++;  // Incrementamos cantidad de n�meros con la cifra
                }
                
            }

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Hay " + numsConCifra + " n�mero" +
                    (numsConCifra==1 ? "" : "s") + " entre " + inicio + 
                    " y " + fin + " que contienen la cifra " + cifra + ": ");
            System.out.println (listaNumeros);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}