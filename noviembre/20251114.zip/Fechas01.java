
package ejemplos2025;

/**
 * Programa Ejemplos de objetos Fecha LocalDate
 * @author diosdado
 */

import java.util.Scanner;
import java.time.LocalDate;

public class Fechas01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares
            LocalDate fecha1, fecha2, fecha3;
            
            


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE FECHAS");
            System.out.println("------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            System.out.println ("Creando fecha1: 15/09/2025");
            fecha1 = LocalDate.of (2025, 9, 15);

            System.out.println ("Creando fecha2: 22/06/2026");
            fecha2 = LocalDate.parse ("2026-06-22");

            System.out.println ("Creando fecha3: fecha actual");
            fecha3 = LocalDate.now();
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("fecha1.dia = " + fecha1.getDayOfMonth());
            System.out.println ("fecha1.mes = " + fecha1.getMonthValue());
            System.out.println ("fecha1.a�o = " + fecha1.getYear());
            System.out.println ("fecha1.toString() = " + fecha1.toString() );
            System.out.println ();
            System.out.println ("fecha2.dia = " + fecha2.getDayOfMonth());
            System.out.println ("fecha2.mes = " + fecha2.getMonthValue());
            System.out.println ("fecha2.a�o = " + fecha2.getYear());
            System.out.println ("fecha2.toString() = " + fecha2.toString() );
            System.out.println ();
            System.out.println ("fecha3.dia = " + fecha3.getDayOfMonth());
            System.out.println ("fecha3.mes = " + fecha3.getMonthValue());
            System.out.println ("fecha3.a�o = " + fecha3.getYear());
            System.out.println ("fecha3.toString() = " + fecha3.toString() );
            System.out.println ("fecha3->d�a del mes: " + fecha3.getDayOfMonth() );
            System.out.println ("fecha3->d�a de la semana: " + fecha3.getDayOfWeek() );
            System.out.println ("fecha3->d�a del a�o: " + fecha3.getDayOfYear() );
            System.out.println ("fecha3->mes en n�mero = " + fecha3.getMonthValue());
            System.out.println ("fecha3->mes en nombre = " + fecha3.getMonth());
            System.out.println ("fecha3->el a�o es bisiesto = " + fecha3.isLeapYear());
            System.out.println ("fecha3->n�mero de d�as en el mes= " + fecha3.lengthOfMonth());
            System.out.println ("fecha3->n�mero de d�as en el a�o= " + fecha3.lengthOfYear());

            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}