
package ejemplos2025;

/**
 * Programa Simulador de ruleta
 * @author diosdado
 */

import java.util.Scanner;


public class Ruleta02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int NUM_CASILLAS = 37;

            // Variables de entrada
            int numTiradas;



            // Variables de salida
            int casilla;
            String descripcionCasilla;



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("RULETA DE CASINO");
            System.out.println("----------------");
            System.out.println("Introduzca el n�mero de tiradas (>=1): ");
            do {
                numTiradas = teclado.nextInt();
            } while ( numTiradas < 1 );

            //----------------------------------------------
            //                 Procesamiento 
            //                       +
            //              Salida de resultados 
            //----------------------------------------------
            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");

            for (int contador =1 ;  contador <= numTiradas; contador++ ) {
            
                casilla = (int) (Math.random()*NUM_CASILLAS);

                descripcionCasilla = "N�mero: " + casilla;
                if ( casilla != 0 ) {

                    // Comprobamos si es par/impar
                    boolean esPar = casilla % 2 == 0;
                    descripcionCasilla += (esPar ? " PAR" :  " IMPAR");

                    // Comprobamos si rojo/negro
                    switch (casilla) {
                        case 1, 3, 5, 7, 12, 9, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36 -> descripcionCasilla += " ROJO";
                        default -> descripcionCasilla += " NEGRO";

                    }

                    // Comprobamos pasa/falta
                    if (casilla<=18) {
                            descripcionCasilla += " FALTA";
                    } else {
                            descripcionCasilla += " PASA";                    
                    }

                } 

                System.out.print ("Tirada " + contador + ": ");
                System.out.println (descripcionCasilla);
            }

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}