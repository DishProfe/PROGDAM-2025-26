package ejemplos2025;

/**
 * Programa Buscador de lunes
 *
 * @author diosdado
 */
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Scanner;

public class BuscadorLunes01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------
        // Constantes

        // Variables de entrada
        int mes;
        
        // Variables de salida

        // Variables auxiliares
        int year;
        int numDiasMes;

        
        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("BUSCADOR DE LUNES");
        System.out.println("-----------------");
        do {
            System.out.println("Introduzca mes (1-12)");
            mes = teclado.nextInt();
        } while (mes < 1 || mes > 12);

        //----------------------------------------------
        //                 Procesamiento 
        //                       +
        //              Salida de resultados 
        //----------------------------------------------
        year = LocalDate.now().getYear();
        numDiasMes = LocalDate.of (year, mes, 1).lengthOfMonth();

        for ( int dia=1 ; dia <= numDiasMes ; dia++ ) {
            LocalDate fecha = LocalDate.of (year, mes, dia);
            DayOfWeek diaSemana = fecha.getDayOfWeek();
            if ( diaSemana == DayOfWeek.MONDAY) {
                System.out.println (fecha.toString());
            }
            
        }
        
        
        
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");

        System.out.println();
        System.out.println("Fin del programa.");

    }

}
