
package ejemplos2025;

/**
 * Programa Ejemplos de objetos Fecha LocalDate
 * @author diosdado
 */

import java.util.Scanner;
import java.time.LocalDate;

public class Fechas02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares
            LocalDate fecha1, fecha2, fecha3;
            
            


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE FECHAS");
            System.out.println("------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            System.out.println ("Creando fecha1: 15/09/2025");
            fecha1 = LocalDate.of (2025, 9, 15);
            System.out.println ("fecha1.toString() = " + fecha1.toString() );
            System.out.println ("Sumamos 1 a�o a fecha1");  
            fecha1 = fecha1.plusYears(1) ;
            
            System.out.println ("Creando fecha2: 22/06/2026");
            fecha2 = LocalDate.parse ("2026-06-22");
            System.out.println ("fecha2.toString() = " + fecha2.toString() );
            System.out.println ("Restamos 1 mes a fecha2");  
            fecha2= fecha2.minusMonths(1);

            System.out.println ("Creando fecha3: fecha actual");
            fecha3 = LocalDate.now();
            System.out.println ("fecha3.toString() = " + fecha3.toString() );
            System.out.println ("Sumamos 2 d�as a fecha3");  
            fecha3= fecha3.plusDays(2);


            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Resultado tras las operaciones: ");
            System.out.println ("fecha1.toString() = " + fecha1.toString() );
            System.out.println ("fecha2.toString() = " + fecha2.toString() );
            System.out.println ("fecha3.toString() = " + fecha3.toString() );

            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}