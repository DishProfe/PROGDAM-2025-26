
package ejemplos2025;

/**
 * Programa Simulador de ruleta
 * @author diosdado
 */

import java.util.Scanner;


public class Ruleta01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int NUM_CASILLAS = 37;

            // Variables de entrada




            // Variables de salida
            int casilla;
            String descripcionCasilla;



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("RULETA DE CASINO");
            System.out.println("----------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            casilla = (int) (Math.random()*NUM_CASILLAS);

            descripcionCasilla = "N�mero: " + casilla;
            if ( casilla != 0 ) {
                
                // Comprobamos si es par/impar
                boolean esPar = casilla % 2 == 0;
                descripcionCasilla += (esPar ? " PAR" :  " IMPAR");
                
                // Comprobamos si rojo/negro
                switch (casilla) {
                    case 1: case 3: case 5: case 7: case 12:    
                    case 9: case 14: case 16: case 18: case 19:    
                    case 21: case 23: case 25: case 27: case 30:                            
                    case 32: case 34: case 36: 
                        descripcionCasilla += " ROJO";
                        break;
                    
                    default:
                        descripcionCasilla += " NEGRO";
                        
                }

                // Comprobamos pasa/falta
                if (casilla<=18) {
                        descripcionCasilla += " FALTA";
                } else {
                        descripcionCasilla += " PASA";                    
                }
                
            } 
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("La bola ha ca�do en la casilla: ");
            System.out.println (descripcionCasilla);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}