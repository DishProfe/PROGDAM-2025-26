
package ejemplos2025;

/**
 * Programa Ejemplos de objetos Wrapper
 * @author diosdado
 */

import java.util.Scanner;


public class Envoltorios01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida
            Integer integer1, integer2;
            Double double1, double2;

            int int1, int2;

            // Variables auxiliares
            


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE WRAPPER");
            System.out.println("-------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // integer1 = new Integer (100);  // Boging "manual"
            integer1 = 100;  // boxing autom�tico

            //int1 = integer1.intValue(); // Unboxing "manual"
            int1 = integer1; // unboxing autom�tico


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Observamos m�todos est�ticos de Integer: ");
            System.out.println ("Integer.BYTES = " + Integer.BYTES);
            System.out.println ("Integer.MAX_VALUE = " + Integer.MAX_VALUE);
            System.out.println ("Integer.MIN_VALUE = " + Integer.MIN_VALUE);
            System.out.println ("Integer.SIZE = " + Integer.SIZE);

            System.out.println ();
            System.out.println ("Integer.parseInt(\"125\")= " + Integer.parseInt ("125"));
            System.out.println ("Integer.toBinaryString(15)= " + Integer.toBinaryString (15));
            System.out.println ("Integer.toHexString(254)= " + Integer.toHexString (254));

            

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}