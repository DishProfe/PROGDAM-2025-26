package ejemplos2025;

/**
 *
 * @author diosdado
 */
public class EjemplosPrint02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Declaración de variables
        int valor1;
        int valor2;
        int valor3;
        
        // Procesamiento
        valor1 = 10;
        valor2 = 20;
        valor3 = valor1 + valor2;

        // Salida de resultados
        System.out.println (valor1);
        System.out.println (valor2);
        System.out.println (valor1 + valor2);
        System.out.println (valor3);

        
        
        
        
    }
    
}
