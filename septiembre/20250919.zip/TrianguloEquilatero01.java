package ejemplos2025;
import ejemplos2024.*;
import java.util.Scanner;

/**
 *
 * @author portatil_profesorado
 */
public class TrianguloEquilatero01 {
    
    public static void main(String[] args) {
        
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        // Variables de entrada
        double lado;
        
        // Variables de salida
        double superficie, perimetro;
        
        // Variables intermedias
        double medioLado;
        double altura;
        

        // Entrada de datos
        // ----------------
        System.out.println ("CALCULO DE PERIMETRO Y SUPERFICIE DE TRIANGULOS EQUILATEROS");
        System.out.println ("-----------------------------------------------------------");
        System.out.println ("Los tres lados de un triangulo equilatero son iguales.");
        System.out.println ();
        System.out.print ("Introduzca lado (m): ");
        lado = teclado.nextDouble();
        
        
        // Procesamiento
        // -------------

        // Cálculo de la altura del triángulo
        medioLado = lado / 2.0;
        altura = Math.sqrt (lado*lado - medioLado*medioLado);

        // Cálculo del perímetro del triángulo
        perimetro = lado * 3;
                
        // Cálculo de la superficie del triángulo
        superficie = lado * altura / 2;


        
        // Salida de resultados
        // --------------------
        System.out.println();
        System.out.println ("Perimetro: " + perimetro + " m");
        System.out.println ("Superficie: " + superficie + " m2");
        
        
        
        
    }

}
