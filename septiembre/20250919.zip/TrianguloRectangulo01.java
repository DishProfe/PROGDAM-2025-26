package ejemplos2025;
import java.util.Scanner;

/**
 *
 * @author profe
 */
public class TrianguloRectangulo01 {
    
    public static void main(String[] args) {
        
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Declaración de Variables
        // ------------------------
        
        // Variables de entrada
        double base, altura;
        
        // Variables de salida
        double superficie, perimetro;
        
        // Variables auxiliares
        double hipotenusa;
        

        // Entrada de datos
        // ----------------
        System.out.println ("CALCULO DE PERIMETRO Y SUPERFICIE DE TRIANGULOS RECTANGULOS");
        System.out.println ("-----------------------------------------------------------");
        
        System.out.print ("Introduzca base (m): ");
        base = teclado.nextDouble();
        
        System.out.print ("Introduzca altura (m): ");
        altura = teclado.nextDouble();
        
        // Procesamiento
        // -------------

        // Cálculo de la superficie del triángulo
        superficie = base * altura / 2;

        // Cálculo del perímetro del triángulo
        hipotenusa = Math.sqrt ( base*base + altura*altura );
        perimetro = base + altura + hipotenusa;



        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("RESULTADO");
        System.out.println ("---------");
        System.out.println ("Perimetro: " + perimetro + " m" );
        System.out.println ("Superficie: " + superficie + " m2" );
        
        
        
        
    }

}
