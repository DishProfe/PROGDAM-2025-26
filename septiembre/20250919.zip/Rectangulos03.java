package ejemplos2025;
import java.util.Scanner;

/**
 *
 * @author portatil_profesorado
 */
public class Rectangulos03 {
    
    public static void main(String[] args) {
        
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        // Variables de entrada
        int base, altura;
        
        // Variables de salida
        int superficie, perimetro;
        

        // Entrada de datos
        // ----------------
        System.out.println ("TRABAJO CON RECTANGULOS");
        System.out.println ("-----------------------");

        System.out.print ("Introduzca base (m): ");
        base = teclado.nextInt();
        
        System.out.print ("Introduzca altura (m): ");
        altura = teclado.nextInt();
        
        // Procesamiento
        // -------------

        // Cálculo de la superficie del rectángulo
        superficie = base * altura;

        // Cálculo del perímetro del rectángulo
        perimetro = 2*base + 2*altura;

        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("RESULTADO");
        System.out.println ("---------");

        System.out.println ("Perimetro: ");
        System.out.println ( perimetro + " m");
        System.out.println ( perimetro*10 + " dm");
        System.out.println ( perimetro*100 + " cm");
        System.out.println ();

        System.out.println ("Superficie: ");
        System.out.println ( superficie + " m2");
        System.out.println ( superficie*100 + " dm2");
        System.out.println ( superficie*100*100 + " cm2");
        
        
        
        
    }

}
