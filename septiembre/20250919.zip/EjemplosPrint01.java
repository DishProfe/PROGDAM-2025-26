package ejemplos2025;

/**
 *
 * @author diosdado
 */
public class EjemplosPrint01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println (1);
        System.out.println ("2");
        System.out.println ("Tres");
        System.out.println ("4");
        System.out.println (5);
        System.out.println ("6");
        System.out.println (7);
        System.out.println ("8");
        System.out.println (8);
        System.out.println (5+9);
        System.out.println ("5+9");
        System.out.println (1+1+4+9+101);
        System.out.println (1+1*4-9+101);
        System.out.println ("cinco" + "nueve");
        System.out.println ("cinco" + "y" + "nueve");
        System.out.println ("cinco " + "y" + " nueve");

        
        
        
        
    }
    
}
