package ejemplos2025;
import java.util.Scanner;

/**
 *
 * @author portatil_profesorado
 */
public class Rectangulos02 {
    
    public static void main(String[] args) {
        
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        // Variables
        // ---------
        
        // Variables de entrada
        int base, altura;
        
        // Variables de salida
        int superficie, perimetro;
        

        // Entrada de datos
        // ----------------
        System.out.println ("TRABAJO CON RECTANGULOS");
        System.out.println ("-----------------------");

        System.out.print ("Introduzca base (cm): ");
        base = teclado.nextInt();
        
        System.out.print ("Introduzca altura (cm): ");
        altura = teclado.nextInt();
        
        // Procesamiento
        // -------------

        // Cálculo de la superficie del rectángulo
        superficie = base * altura;

        // Cálculo del perímetro del rectángulo
        perimetro = 2*base + 2*altura;

        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("RESULTADO");
        System.out.println ("---------");

        System.out.print ("Superficie: ");
        System.out.println ( superficie + " cm2");
        
        System.out.print ("Perimetro: ");
        System.out.println ( perimetro + " cm");
        
        
    }

}
