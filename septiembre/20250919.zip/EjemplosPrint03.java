package ejemplos2025;

/**
 *
 * @author diosdado
 */

import java.util.Scanner;


public class EjemplosPrint03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner (System.in);
        
        // Declaración de variables
        // ------------------------

        // Variables de entrada
        int valor1;
        int valor2;

        // Variables de salida
        int suma;
        int resta;
        int producto;
        int cociente;
        int resto;
        
        
        // Entrada de datos
        // ----------------
        System.out.println ("PROGRAMA PARA OPERAR CON DOS NUMEROS ENTEROS");
        System.out.println ("--------------------------------------------");
        
        System.out.print ("Introduzca primer valor: ");
        valor1 = teclado.nextInt();
        
        System.out.print ("Introduzca segundo valor: ");
        valor2 = teclado.nextInt();

        
        // Procesamiento
        // -------------
        suma = valor1 + valor2;
        resta = valor1 - valor2;
        producto = valor1 * valor2;
        cociente = valor1 / valor2;
        resto = valor1 % valor2;
        
        // Salida de resultados
        // --------------------
        System.out.println ();
        System.out.println ("RESULTADO");
        System.out.println ("---------");
        System.out.print ("Resultado de la suma: ");
        System.out.println (suma);
        System.out.print ("Resultado de la resta: ");
        System.out.println (resta);
        System.out.println ("Resultado del producto: " + producto);
        System.out.println ("Resultado del cociente: " + cociente);
        System.out.println ("Resultado del resto: " + resto);

        
        
        
        
    }
    
}
