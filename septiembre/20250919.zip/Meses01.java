package ejemplos2025;

/**
 *
 * @author diosdado
 */
public class Meses01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println ("Enero.");
        System.out.println ("Febrero.");
        System.out.println ("Marzo.");
        System.out.println ("Abril.");
        System.out.println ("Mayo.");
        System.out.println ("Junio.");
        System.out.println ("Julio.");
        System.out.println ("Agosto.");
        System.out.println ("Septiembre.");
        System.out.println ("Octubre.");
        System.out.println ("Noviembre.");
        System.out.println ("Diciembre.");
        
        
        
        
    }
    
}
