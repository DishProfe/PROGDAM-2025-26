
package ejemplos2025;

/**
 * Programa Comprobar fecha v�lida
 * @author diosdado
 */

import java.util.Scanner;


public class Fecha02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int YEAR_MIN = 1900;
            final int YEAR_MAX = 2100;

            // Variables de entrada
            int dia;
            int mes;
            int year;


            // Variables de salida
            boolean fechaValida;


            // Variables auxiliares
            boolean diaValido;
            boolean mesValido;
            boolean yearValido;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBACI�N DE FECHA V�LIDA");
            System.out.println("----------------------------");

            System.out.println("Introduzca d�a:");
            dia = teclado.nextInt();

            System.out.println("Introduzca mes:");
            mes = teclado.nextInt();
            
            System.out.println("Introduzca a�o:");
            year = teclado.nextInt();
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            diaValido = dia>=1 && dia<=31;
            mesValido = mes>=1 && mes<=12;
            yearValido = year>=YEAR_MIN && year<=YEAR_MAX;

            fechaValida = diaValido && mesValido && yearValido;

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("La fecha es v�lida: " + 
                    (fechaValida ? "s�" : "no") );


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}
