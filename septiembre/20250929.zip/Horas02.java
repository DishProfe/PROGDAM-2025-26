
package ejemplos2025;

/**
 * Programa Comprobaci�n de hora v�lida
 * @author diosdado
 */

import java.util.Scanner;


public class Horas02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int hora;
            int minuto;
            int segundo;




            // Variables de salida
            boolean tiempoValido;



            // Variables auxiliares
            boolean horaValida;
            boolean minutoValido;
            boolean segundoValido;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBACI�N DE HORA V�LIDA");
            System.out.println("---------------------------");
            System.out.println("Introduzca hora: ");
            hora = teclado.nextInt();
            System.out.println("Introduzca minuto: ");
            minuto = teclado.nextInt();
            System.out.println("Introduzca segundo: ");
            segundo = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            horaValida = hora>=0 && hora<=23;
            //System.out.println ("Hora v�lida: " + horaValida);

            minutoValido = minuto>=0 && minuto<=59;
            //System.out.println ("Minuto v�lido: " + minutoValido);

            segundoValido = segundo>=0 && segundo<=59;
            //System.out.println ("Segundo v�lido: " + segundoValido);
                        
            tiempoValido = hora>=0 && hora<=23 && 
                    minuto>=0 && minuto<=59 && 
                    segundo>=0 && segundo<=59; 
            
            
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El tiempo indicado es v�lido: " + 
                    (tiempoValido ? "s�" : "no") );

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}
