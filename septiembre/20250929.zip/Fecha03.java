
package ejemplos2025;

/**
 * Programa Comprobar fecha v�lida
 * @author diosdado
 */

import java.util.Scanner;


public class Fecha03 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int YEAR_MIN = 1900;
            final int YEAR_MAX = 2100;

            // Variables de entrada
            int dia;
            int mes;
            int year;


            // Variables de salida
            boolean fechaValida;


            // Variables auxiliares
            boolean diaValido;
            boolean mesValido;
            boolean yearValido;
            boolean esMes30;
            boolean esMes31;
            boolean esFebrero;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBACI�N DE FECHA V�LIDA");
            System.out.println("----------------------------");

            System.out.println("Introduzca d�a:");
            dia = teclado.nextInt();

            System.out.println("Introduzca mes:");
            mes = teclado.nextInt();
            
            System.out.println("Introduzca a�o:");
            year = teclado.nextInt();
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            yearValido = year>=YEAR_MIN && year<=YEAR_MAX;
            
            mesValido = mes>=1 && mes<=12;

            esMes30 = mes==4 || mes==6 || mes==9 || mes==11;
            esMes31 = mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 ||
                    mes == 10 || mes == 12;
            esFebrero = mes==2;
            
            diaValido = dia>=1 && 
                    ( esMes30 && dia<=30 || esMes31 && dia<=31 || esFebrero && dia<=28 ) ;

            fechaValida = diaValido && mesValido && yearValido;

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("La fecha es v�lida: " + 
                    (fechaValida ? "s�" : "no") );


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}
