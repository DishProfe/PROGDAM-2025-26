
package ejemplos2025;

/**
 * Programa Comprobaci�n de bisiesto
 * @author diosdado
 */

import java.util.Scanner;


public class Bisiesto01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int year;




            // Variables de salida
            int esBisiesto;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBACI�N DE A�O BISIESTO");
            System.out.println("----------------------------");
            System.out.println("Introduzca a�o: ");
            year = teclado.nextInt();


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El a�o bisiesto: " + esBisiesto);
            

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}
