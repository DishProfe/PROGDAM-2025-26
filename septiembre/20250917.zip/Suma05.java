package prueba02;

import java.util.Scanner;

/**
 *
 * @author diosdado
 */
public class Suma05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner teclado = new Scanner (System.in);
        
        
        int dato1;
        int dato2;
        int resultado;
        
        System.out.println ("Introduzca primer dato: ");
        dato1 = teclado.nextInt();
        System.out.println ("Introduzca segundo dato: ");
        dato2 = teclado.nextInt();
        resultado = dato1 + dato2;
        
        System.out.println ("RESULTADO");
        System.out.println ("---------");
        System.out.print (dato1 + " + " + dato2 + " = ");
        System.out.println (resultado);
        
    }
    
}
