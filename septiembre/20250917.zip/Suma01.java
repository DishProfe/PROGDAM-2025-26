/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prueba02;

/**
 *
 * @author diosdado
 */
public class Suma01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println ("3+6");
        System.out.println (3+6);

        System.out.print ("3+6= ");
        System.out.println (3+6);

    }
    
}
