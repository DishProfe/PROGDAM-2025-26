/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prueba02;

/**
 *
 * @author diosdado
 */
public class Suma02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        int dato1;
        int dato2;
        int resultado;
        
        
        dato1 = 3;
        dato2 = 6;
        resultado = dato1 + dato2;
        
        System.out.print (dato1);
        System.out.print ("+");
        System.out.print (dato2);       
        System.out.print ("=");
        System.out.println (resultado);
        
    }
    
}
