package prueba02;

/**
 *
 * @author diosdado
 */
public class Prueba02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        System.out.print ("Diosdado Sanchez Hernandez");
        System.out.println ("I.E.S. Aguadulce");
        

    }
    
}
