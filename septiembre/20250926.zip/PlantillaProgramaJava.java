/*
 * Plantilla para programas de prueba
 */
import java.util.Scanner;


public class PlantillaProgramaJava {
 
	public static void main(String[] args) {

		//----------------------------------------------
		//          Declaración de variables 
		//----------------------------------------------

		// Constantes


		// Variables de entrada
		



		// Variables de salida



		// Variables auxiliares


		// Clase Scanner para petición de datos de entrada
		Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("PLANTILLA DE PROGRAMA ");
        System.out.println("----------------------");
        System.out.println(" ");


        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------





		//----------------------------------	------------
		//              Salida de resultados 
		//----------------------------------------------
        
		System.out.println ();
		System.out.println ("RESULTADO");
		System.out.println ("---------");


		System.out.println ();
		System.out.println ("Fin del programa.");
        
        
	}
    
}