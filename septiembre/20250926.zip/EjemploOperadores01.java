package ejemplos2025;

/**
 * Programa Ejemplo de operadores
 *
 * @author diosdado
 */
import java.util.Scanner;

public class EjemploOperadores01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------
        // Constantes
        // Variables de entrada
        // Variables de salida
        // Variables auxiliares
        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE OPERADORES");
        System.out.println("----------------------");
        // Declaraci�n de variables
        short x = 7;
        int y = 5;
        float f1 = 13.5f;
        float f2 = 8f;

        // Ejemplos de operaciones
        System.out.println("EJEMPLOS DE USO DE OPERADORES ARITM�TICOS");
        System.out.println("-----------------------------------------");
        System.out.println("El valor de x es " + x + ", y es " + y);
        System.out.println("El resultado de x + y es " + (x + y));
        System.out.println("El resultado de x - y es " + (x - y));
        System.out.println("Divisi�n entera: x / y = " + (x / y));
        System.out.println("Resto de la divisi�n entera: x % y = " + (x % y));
        System.out.println("El valor de f1 es " + f1 + ", f2 es " + f2);
        System.out.println("El resultado de f1 / f2 es " + (f1 / f2));

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        //---------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");

        System.out.println();
        System.out.println("Fin del programa.");

    }

}
