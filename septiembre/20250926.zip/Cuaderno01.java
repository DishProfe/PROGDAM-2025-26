
package ejemplos2025;

/**
 * Programa Cuaderno
 * @author diosdado
 */

import java.util.Scanner;


public class Cuaderno01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numHojasTotales;

            // Variables de salida
            int numHojasRojas;
            int numHojasVerdes;



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJERCICIOS DE CUADERNOS DE COLORES");
            System.out.println("----------------------------------");
            System.out.println("Introduzca el n�mero total de hojas del cuaderno");
            numHojasTotales = teclado.nextInt();
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            numHojasRojas = numHojasTotales / 2 + numHojasTotales % 2 ; 
            numHojasVerdes = numHojasTotales / 2;




            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("N�mero de hojas rojas: " + numHojasRojas);
            System.out.println ("N�mero de hojas verdes: "+ numHojasVerdes);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}
