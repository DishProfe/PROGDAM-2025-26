package ejemplos2026;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author profe
 */
public class PruebaConexion01 {

    public static void main(String[] args) {

        Connection conexion = null;
        boolean conOk = false;

        // Cadena de conexi�n para conectar con MySQL en una IP,
        // seleccionar la base de datos llamada "world"
        // con usuario y contrase�a del servidor de MySQL: 1dam y 1dam
        //String cadenaConexion = "jdbc:mysql://192.168.56.7:3306/world?serverTimezone=UTC";        
        String cadenaConexion = "jdbc:mysql://192.168.56.7/world";        
        String usuario = "1dam";
        String passwd = "1dam";

        try {

            // Obtener la conexi�n
            System.out.println("Intentando conectar con la base de datos.");
            conexion = DriverManager.getConnection(cadenaConexion, usuario, passwd);
            conOk = true;

        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } 
        
        if ( conOk) {
            System.out.println("Conexi�n realizada con �xito.");
            System.out.printf ("Disponemos de un objeto de tipo Connection para comunicarnos con el SGBD: \n%s\n", 
                    conexion);
            System.out.println("�Y ahora qu�?");
        } else {
            System.out.println("No se pudo establecer la conexi�n con la base de datos.");            
        }
        

    }

}
