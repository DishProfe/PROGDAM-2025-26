
package ejemplos2026;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author profe
 */
public class EjemploConsulta01 {
    
    public static void main(String[] args) {
        
        Connection conexion= null;
        boolean connectionOk= false;
        
        // Cadena de conexi�n para conectar con MySQL en una IP,
        // seleccionar la base de datos llamada "world"
        // con usuario y contrase�a del servidor de MySQL: 1dam y 1dam
        //String cadenaConexion = "jdbc:mysql://192.168.56.7:3306/world?serverTimezone=UTC";        
        String cadenaConexion = "jdbc:mysql://192.168.56.7/world";        
        String usuario = "1dam";
        String passwd = "1dam";

        try {

            // Obtener la conexi�n
            System.out.println("Intentando conectar con la base de datos...");
            conexion = DriverManager.getConnection(cadenaConexion, usuario, passwd);
            connectionOk = true;
            System.out.printf ("Conexi�n establecida.\n");
            System.out.println();

        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } 
        
       
        if (connectionOk) {
            
            try {

                // Preparamos la consulta: objeto de tipo Statement
                Statement sentencia = conexion.createStatement();                
                
                // Texto de la consulta
                String sentenciaSQL = "SELECT name, region FROM country WHERE GovernmentForm LIKE '%Monarchy%' AND continent='Europe';";
                // Ejecutamos la consulta
                System.out.printf ("Ejecutando la consulta:\n%s\n\n", sentenciaSQL);
                // Obtenemos un objeto de tipo ResultSet al ejecutar la consulta con executeQuery
                ResultSet rs = sentencia.executeQuery ( sentenciaSQL );
                System.out.println ("Consulta enviada y recibida la respuesta.");
                System.out.println();
                
                // Iteramos sobre los registros del resultado
                System.out.println ("Resultado de la consulta:");
                System.out.printf ( "%-2s %-20s  %-20s \n", "#", "Name", "Region" );   
                System.out.printf ( "%-2s %-20s  %-20s \n", "-".repeat(2), "-".repeat(20), "-".repeat(20) );   
                int contador = 0;
                while (rs.next()) {
                    System.out.printf ( "%2d %-20s  %-20s \n", ++contador, rs.getString("name"), rs.getString (2) );   
                }
                System.out.println ();
                    
                    
            } catch (SQLException e) {
                System.out.println("SQL Exception: " + e.toString());
            }
        } else {
            System.out.println("No se pudo establecer la conexi�n con la base de datos.");            
        }
    }
}
        
