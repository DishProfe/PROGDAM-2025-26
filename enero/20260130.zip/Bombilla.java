
package domotica;

/**
 * Clase que representa una bomilla inteligente.    
 * @author diosdado
 */
public class Bombilla extends Dispositivo {
    
    // Atributos de estado (variables)
    private int intensidad;         // Intensidad actual de la bombilla
    private int numVecesManipulada; // N�mero de veces que ha sido manipulada (encendida o apagada) de manera "efectiva"

    /**
     * 
     * @param descripcion
     * @param ubicacion
     * @throws IllegalArgumentException 
     */
    public Bombilla (String descripcion, int ubicacion) throws IllegalArgumentException {
        
        super ( descripcion, ubicacion );
        
        // Si todo ha ido bien
        
        // Inicializaci�n de atributos espec�ficos
        this.intensidad = 0;
        this.numVecesManipulada = 0;
        
    }
    
    public Bombilla (int ubicacion) throws IllegalArgumentException {
        
        this ( Dispositivo.DEFAULT_DESCRIPTION, ubicacion );
        
    }

    
    public int getIntensidad() {
        return this.intensidad;
    }
    
    public int getNumVecesManipulada() {
        return this.numVecesManipulada;
    }
    
    @Override
    public void encender () {
        this.intensidad = 10;
        this.numVecesManipulada++;
    }
    
    @Override
    public void apagar() {
        this.intensidad = 0;
        this.numVecesManipulada++;
    }
    
    
    @Override
    public String toString() {
        return String.format ( "%s  intensidad: %2d  nve: %3d",
                super.toString(),
                this.intensidad,
                this.numVecesManipulada);
    }
    

}
