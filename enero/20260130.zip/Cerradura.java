package domotica;

/**
 *
 * @author diosdado
 */
public class Cerradura extends Dispositivo {
    
    
    // Atributos de estado (variables)
    private boolean estado; // Indica si la cerradura est� abierta (false/"desactivada"/"desarmada") o cerrada (true/"activada"/"armada")

    public Cerradura (String descripcion, int ubicacion) throws IllegalArgumentException {
        
        super (descripcion, ubicacion);
        
        // Si todo ha ido bien
        
        // Inicializamos atributos espec�ficos
        this.estado = false;
    }

    public boolean getEstado () {
        return this.estado;
    }
    
    @Override
    public void encender () {
        this.estado = true;
    }
    
    @Override
    public void apagar() {
        this.estado = false;
    }
    
    @Override
    public String toString(){
        return String.format ( "%s  estado: %s",
                super.toString(),
                this.estado ? "cerrada" : "abierta");
        
    }
    
    
}
