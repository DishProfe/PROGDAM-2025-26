package domotica;

/**
 * Clase que representa un dispositivo dom�tico. 
 * @author diosdado
 */
public abstract class Dispositivo {

    // Atributos de clase
    private static int numDispositivos = 0; // Atributo de n�mero de secuencia
    
    // Atributos de clase constantes
    /**
     * Valor asignado al atributo descripci�n si no se le asigna ninguno: {@value DEFAULT_DESCRIPTION}
     */
    public static final String DEFAULT_DESCRIPTION = "Sin descripcion";
    
    
    // Atributos de objeto 
    private final int id;
    private final String descripcion;
    private int ubicacion;
    
    
    /**
     * Constructor con dos par�metros. Crea un objeto de tipo Dispositivo bas�ndose en la
     * descripci�n y ubicaci�n proporcionadas. La ubicaci�n debe ser mayor que cero.
     * El id del dispositivo se genera autom�ticamente de manera secuencial.
     * @param descripcion descripci�n del dispositivo
     * @param ubicacion n�mero de habitaci�n en la que se ecuentra el dispositivo
     * @throws IllegalArgumentException si alg�n par�metro no es v�lido
     */
    public Dispositivo (String descripcion, int ubicacion) throws IllegalArgumentException {
        
        if ( ubicacion < 0 ) {
            throw new IllegalArgumentException ("ubicacion no v�lida");
        } else if ( descripcion == null || descripcion.isEmpty() || descripcion.isBlank()  ) {
            throw new IllegalArgumentException ("descripci�n no v�lida");
        } 
        
        // Si todo va bien
        
        // Actualizamos atributos de clase
        numDispositivos++;

        // Inicializamos atributos de objeto
        this.id = numDispositivos;
        this.descripcion = descripcion;
        this.ubicacion = ubicacion;
        
    }
    
    /**
     * Constructor con un par�metro. Solamente se recibe la ubicaci�n. El valor de la
     * descripci�n ser {@value DEFAULT_DESCRIPTION}. La ubicaci�n debe ser mayor que cero.
     * El id del dispositivo se genera autom�ticamente de manera secuencial.
     * @param ubicacion n�mero de habitaci�n en la que se ecuentra el dispositivo
     * @throws IllegalArgumentException si alg�n par�metro no es v�lido
     */
    public Dispositivo ( int ubicacion ) throws IllegalArgumentException {
        this ( Dispositivo.DEFAULT_DESCRIPTION, ubicacion);
    }
    
    
    /**
     * Obtiene el id del dispositivo.
     * @return id del dispositivo
     */
    public int getId() {
        return this.id;
    }
    
    /**
     * Obtiene la descripci�n del dispositivo.
     * @return descripci�n del dispositivo
     */
    public String getDescripcion() {
        return this.descripcion;
    }
    
    /**
     * Obtiene la ubicaci�n del dispositivo.
     * @return ubicaci�n del dispositivo
     */
    public int getUbicacion() {
        return this.ubicacion;
    }
   
    @Override
    public String toString() {
        return String.format ( "id: %2d  descripci�n: %-20s  ubicaci�n: %2d ",
                this.id,
                this.descripcion,
                this.ubicacion);
    }
    
    
    abstract public void encender() ; 
    abstract public void apagar() ; 
    
    
    
}
