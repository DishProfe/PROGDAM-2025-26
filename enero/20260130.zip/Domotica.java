package domotica;

/**
 * Programa principal para probar las clases de la biblioteca Domotica.
 * @author diosdado
 */
public class Domotica {

    /**
     * Programa principal de prueba.
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        // Array de dispositivos
        Dispositivo[] arrayDispositivos = new Dispositivo[20];
        
        //arrayDispositivos[0] = new Dispositivo ( 5 );
        //arrayDispositivos[1] = new Dispositivo ("altavoz", 2);
        //arrayDispositivos[2] = new Dispositivo ("consola", 1);
        
        arrayDispositivos[0] = new Bombilla ("b1", 1);
        arrayDispositivos[1] = new Cerradura ("c1", 1);
        arrayDispositivos[2] = new Cerradura ("c2", 2);
        arrayDispositivos[3] = new Bombilla ("b2", 2);
        
        
        System.out.println ("Dispositivos disponibles: ");
/*        int contador = 0;
        for ( Dispositivo elemento : arrayDispositivos  ) {
            System.out.printf ("Dispositivo %2d: %s\n",
                    contador++,
                    elemento.toString());
        }
*/

/*
        for ( int indice = 0 ; indice < arrayDispositivos.length ; indice++ ) {
            Dispositivo elemento = arrayDispositivos[indice];
            System.out.printf ("Dispositivo %2d: %s\n",
                    indice,
                    elemento.toString());
        }
*/


        int indice = 0;
        Dispositivo elemento = arrayDispositivos[0];
        while ( elemento != null ) {
            System.out.printf ("Dispositivo %2d: %s\n",
                    indice++,
                    elemento.toString());
            elemento = arrayDispositivos[indice];
        }

        

    }
    
}
