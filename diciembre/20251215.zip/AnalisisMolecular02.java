package ejemplos2025Strings;



import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *   An�lisis Molecular
 */

    public class AnalisisMolecular02 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        String formulaQuimica;
        
        // Variables de salida
        boolean formulaValida = false;
        String elemento;
        int cantidadAtomos;



       // Variables auxiliares
        String patronMoleculaValida = "([A-Z][a-z]?([2-9]|[1-9][0-9])?)+";
        String patronElemento = "([A-Z][a-z]?)([2-9]|[1-9][0-9])?";

        
        String[] formulasQuimicas = {"2NH", "HH1", "n2", "C6H7o2", "H2O1", "H101B12", 
            "H2O", "NaCl", "H2SO4", "C6H12O6", "HCl", "CH4", "O3", "Na2SO4"};
        
        
        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("AN�LISIS MOLECULAR");
        System.out.println("------------------");
        System.out.println("Introduzca la f�rmula que va a ser analizada:");

        formulaQuimica = teclado.nextLine();
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        

        
            
        // Comprobamos si la f�rmula cumple el patr�n de f�rmula v�lida
        if (formulaQuimica.matches(patronMoleculaValida) ) {
            // Si la f�rmula es v�lida hay que extraer sus componentes
            formulaValida = true;

            // Preparamos patr�n de extracci�n de cada elemento (elemento)(cantidad)
            Pattern patternElemento = Pattern.compile (patronElemento);
            Matcher matcherElemento = patternElemento.matcher(formulaQuimica);

            // Vamos buscando posibles elementos con find
            while (matcherElemento.find()) {
                // Extraemos el elemento
                elemento= matcherElemento.group(1);                                        

                // Extraemos la cantidad de �tomos
                String stringCantidad = matcherElemento.group(2);
                cantidadAtomos = stringCantidad == null ? 1 : Integer.parseInt(stringCantidad);

                System.out.printf ("Elemento: %2s - Cantidad: %2d �tomos\n", 
                        elemento, cantidadAtomos);
                

                
            }                
        }
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        if (formulaValida) {
            System.out.println("La f�rmula es v�lida.");
        } else {
            System.out.println("La f�rmula no es v�lida.");            
        }


    }
    
}