package ejemplos2025Strings;


import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 *   Programa
 */

    public class PatronRopa02 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        String etiquetaPrenda;
        
        
        // Variables de salida
        boolean etiquetaValida;
        String etiquetaPrendaLimpia;
        String cliente="" , id="", origen="", codControl="";

        // Variables auxiliares
        String patronPrenda = "([HMB])([0-9]{3,7})([EA])([0-9]{2})";
        Pattern patternPrenda = Pattern.compile (patronPrenda);
        Matcher matcherRopa = null;
        
        // Variables de entrada
     String[] productos= {"H12345E15", "M00000E00", "A12345E15", "H12345E11", 
    "B00011A02", "B00011A11", "h12345E15", "B1111A04", "B111111A06"};  

        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE EXPRESIONES REGULARES");
        System.out.println("---------------------------------");

        do {
            System.out.println ("Introduzca la etiqueta de la prenda (Tipo(H/M/B)-NNN-Origen(E/A): ");
            etiquetaPrenda = teclado.nextLine();
            etiquetaPrendaLimpia = etiquetaPrenda.trim();
            
            matcherRopa = patternPrenda.matcher (etiquetaPrendaLimpia.trim());
            etiquetaValida = matcherRopa.matches();           
        } while (!etiquetaValida); // Seguiremos solicitando mientras no sea válido

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        if ( etiquetaValida ) {  // No debemos intentar extraer grupos si no se ha producido acoplamiento
            cliente = matcherRopa.group(1);
            id = matcherRopa.group(2);
            origen = matcherRopa.group(3);
            codControl = matcherRopa.group(4);
        }
        
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        System.out.println("La etiqueta introducida es: " + etiquetaPrendaLimpia);

        System.out.println("Los componentes del identificador de prenda son: " );
        if ( etiquetaValida ) {
            System.out.printf ("Cliente: %s\n", cliente);
            System.out.printf ("identificador: %s\n", id);
            System.out.printf ("Origen: %s\n", origen);
            System.out.printf ("C�digo de control: %s\n", codControl);
        }
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}