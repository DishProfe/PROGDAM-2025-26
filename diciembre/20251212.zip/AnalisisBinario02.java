
package ejemplos2025Strings;

/**
 * Programa An�lisis Binario
 * @author diosdado
 */

import java.util.Scanner;


public class AnalisisBinario02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String textoEntrada;

            


            // Variables de salida
            boolean patronValido;

            String numeroBinario = "";
            String paridad = "";
            String longBinario = "";
            String numeroDecimal = "";

            boolean paridadCorrecta = true;
            boolean longCorrecta = true;
            boolean decimalCorrecto = true;
            
            // Variables auxiliares
            String patronBinario = "[01]+-[01]-[0-9]+-[0-9]+";
            
            int valorParidad = 0;
            int numBits = 0;
            int numDecimal = 0;
                    
            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("AN�LISIS BINARIO");
            System.out.println("----------------");
            System.out.println("Introduzca texto de entrada: ");

            textoEntrada = teclado.nextLine();
            
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            patronValido = textoEntrada.matches(patronBinario);
            if ( patronValido ) {
             
                // Extraemos primer bloque (n�mero en binario)
                int posGuion = textoEntrada.indexOf("-");
                int sigGuion = textoEntrada.indexOf("-", posGuion+1);
                numeroBinario = textoEntrada.substring(0, posGuion);

                // Extraemos segundo bloque (paridad)
                paridad = textoEntrada.substring(posGuion+1, sigGuion);

                // Extraemos tercer bloque (n�mero de bits)
                posGuion = sigGuion;
                sigGuion = textoEntrada.indexOf ("-", posGuion+1);
                longBinario = textoEntrada.substring(posGuion+1, sigGuion);
                
                // Extraemos cuarto bloque (n�mero en decimal)
                numeroDecimal = textoEntrada.substring(sigGuion+1);
                
                // Comprobamos que cada bloque es correcto
                
                // Segundo bloque
                int numUnos = 0;
                for ( int indice=0; indice<numeroBinario.length() ; indice++ ) {
                    if ( numeroBinario.charAt(indice) == '1' ) {
                        numUnos++;
                    }
                }

                valorParidad = numUnos % 2;
                paridadCorrecta =  valorParidad == Integer.parseInt(paridad) ;
                
                numBits = numeroBinario.length();
                longCorrecta = numBits == Integer.parseInt(longBinario);
                
                numDecimal = Integer.parseInt(numeroBinario, 2);
                decimalCorrecto = numDecimal == Integer.parseInt(numeroDecimal);
               
            }



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            if (patronValido) {
                System.out.print ("Patr�n v�lido. ");
                //System.out.printf ("N�mero binario: %s\n", numeroBinario);
                //System.out.printf ("Paridad: %s\n", paridad);
                //System.out.printf ("Longitud: %s\n", longBinario);
                //System.out.printf ("N�mero en decimal: %s\n", numeroDecimal);
                if ( paridadCorrecta && longCorrecta  && decimalCorrecto ) {
                    System.out.println("Todas las validaciones son correctas.");                    
                } else {
                    System.out.println();
                    if ( !paridadCorrecta ) {
                        System.out.printf ("Paridad incorrecta: %s. Deber�a ser %d.\n",
                                paridad, valorParidad);
                    }
                    if ( !longCorrecta ) {
                        System.out.printf ("N�mero de bits incorrecto: %s. Deber�a ser %d.\n",
                                longBinario, numBits);
                    }
                    if ( !decimalCorrecto ) {
                        System.out.printf ("N�mero decimal equivalente incorrecto: %s. Deber�a ser %d.\n",
                                numeroDecimal, numDecimal);
                    }
                }
            } else {
                System.out.println ("No cumple el patr�n.");                
            }

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

