
package ejemplos2025Strings;

/**
 * Programa An�lisis Binario
 * @author diosdado
 */

import java.util.Scanner;


public class AnalisisBinario01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String textoEntrada;

            


            // Variables de salida
            boolean patronValido;

            String numeroBinario = "";
            String paridad = "";
            String longBinario = "";
            String numeroDecimal = "";
            
            // Variables auxiliares
            String patronBinario = "[01]+-[01]-[0-9]+-[0-9]+";
            
            int valorParidad = 0;
            int numBits = 0;
            int numDecimal = 0;
                    
            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("AN�LISIS BINARIO");
            System.out.println("----------------");
            System.out.println("Introduzca texto de entrada: ");

            textoEntrada = teclado.nextLine();
            
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            patronValido = textoEntrada.matches(patronBinario);
            if ( patronValido ) {
             
                // Extraemos primer bloque (n�mero en binario)
                int posGuion = textoEntrada.indexOf("-");
                int sigGuion = textoEntrada.indexOf("-", posGuion+1);
                numeroBinario = textoEntrada.substring(0, posGuion);

                // Extraemos segundo bloque (paridad)
                paridad = textoEntrada.substring(posGuion+1, sigGuion);

                // Extraemos tercer bloque (n�mero de bits)
                posGuion = sigGuion;
                sigGuion = textoEntrada.indexOf ("-", posGuion+1);
                longBinario = textoEntrada.substring(posGuion+1, sigGuion);
                
                // Extraemos cuarto bloque (n�mero en decimal)
                numeroDecimal = textoEntrada.substring(sigGuion+1);
                
                // Comprobamos que cada bloque es correcto
                
                // Segundo bloque
                int numUnos = 0;
                for ( int indice=0; indice<numeroBinario.length() ; indice++ ) {
                    if ( numeroBinario.charAt(indice) == '1' ) {
                        numUnos++;
                    }
                }

               
            }



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            if (patronValido) {
                System.out.println ("Patr�n v�lido.");
                System.out.printf ("N�mero binario: %s\n", numeroBinario);
                System.out.printf ("Paridad: %s\n", paridad);
                System.out.printf ("Longitud: %s\n", longBinario);
                System.out.printf ("N�mero en decimal: %s\n", numeroDecimal);
            } else {
                System.out.println ("No cumple el patr�n.");                
            }

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

