
package ejemplos2025Arrays;

/**
 * Programa Ejemplos de Arrays
 * @author diosdado
 */

import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;


public class ArrayString01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes

            // Variables de entrada
            String[] grupos = { "1DAM", "2DAM", "1ASIR", "2ASIR", "1SMR", "2SMR", "CIBER"} ;


            // Variables de salida


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE ARRAYS");
            System.out.println("------------------");

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Tama�o del array: %d\n",
                    grupos.length);

            System.out.println ();
            System.out.println ("Contenido del array usando un bucle: ");
            for ( int indice = 0 ; indice < grupos.length ; indice++ ) {
                System.out.printf ( "%s ", grupos[indice]);
            }

            System.out.println ();
            System.out.println ("Contenido del array usando Arrays.toString: ");
            System.out.println ( Arrays.toString(grupos) );

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

