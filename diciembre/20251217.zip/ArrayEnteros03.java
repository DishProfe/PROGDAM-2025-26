
package ejemplos2025Arrays;

/**
 * Programa Ejemplos de Arrays
 * @author diosdado
 */

import java.util.InputMismatchException;
import java.util.Scanner;


public class ArrayEnteros03 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes

            // Variables de entrada
            int numElementos = 0;
            int[] numeros;


            // Variables de salida
            int sumaNumeros;
            int numPares;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE ARRAYS");
            System.out.println("------------------");
            boolean entradaValida = false;
            do {
                System.out.println("Introduzca tama�o del array (1-1000)");
                try {
                    numElementos = teclado.nextInt();
                    entradaValida = numElementos>=1 && numElementos<=1000;
                } catch ( InputMismatchException ex) {
                    teclado.nextInt();
                }                
            } while ( !entradaValida );
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Reservamos espacio para los elementos del array
            numeros = new int[numElementos];

            // Rellenamos cada posici�n del array con 
            // enteros aleatorios entre 0-9
            System.out.println ("Rellenando array...");
            for ( int indice=0 ; indice<numeros.length ; indice++ ) {
                numeros[indice] = (int)(Math.random()*10);
            }
            

            // Hacemos los c�lculos que nos piden
            sumaNumeros = 0;
            numPares = 0;
            for ( int indice=0 ; indice<numeros.length ; indice++ ) {
                sumaNumeros += numeros[indice];
                if ( numeros[indice] % 2 == 0) {
                    numPares++;
                }
            }
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Tama�o del array: %d\n",
                    numeros.length);
            System.out.printf ("Suma de los elementos: %d\n",
                    sumaNumeros);
            System.out.printf("N�mero de pares: %d\n",
                    numPares);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

