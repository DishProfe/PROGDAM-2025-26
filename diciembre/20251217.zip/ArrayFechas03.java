
package ejemplos2025Arrays;

/**
 * Programa Ejemplos de Arrays
 * @author diosdado
 */

import java.time.DateTimeException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;


public class ArrayFechas03 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes

            // Variables de entrada
            int diaNacim, mesNacim, yearNacim=0;

            // Variables de salida
            LocalDate[] arrayFechas = { LocalDate.of (2007, 11, 22), 
                                        LocalDate.of (2007,  3, 17),
                                        LocalDate.of (2006,  8, 11)};


            // Variables auxiliares
            int sizeArray;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE ARRAYS DE FECHAS");
            System.out.println("----------------------------");

            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            

            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Tama�o del array: %d\n",
                    arrayFechas.length);
            System.out.println ("Contenido del array usando un bucle: ");
            for ( int indice= 0; indice < arrayFechas.length ; indice++ ) {
                System.out.printf ("Fecha %2d: %s\n",
                        indice, arrayFechas[indice]);
            }

            System.out.println ();
            System.out.println ("Contenido del array usando toString: ");
            System.out.println ( Arrays.toString(arrayFechas));
            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

