
package ejemplos2025Arrays;

/**
 * Programa Ejemplos de Arrays
 * @author diosdado
 */

import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;


public class ArrayEnteros05 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes

            // Variables de entrada
            int numElementos = 0;
            int[] numeros = { 10, 5200, 33, 121, 3021 } ;


            // Variables de salida
            int sumaNumeros;
            int numPares;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE ARRAYS");
            System.out.println("------------------");

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

/*            
            // Reservamos espacio para los elementos del array
            numeros = new int[numElementos];

            // Rellenamos cada posici�n del array con valores concretos
            System.out.println ("Rellenando array...");
            numeros[0] = 10;
            numeros[1] = 5200;
            numeros[2] = 33;
            numeros[3] = 121;
            numeros[4] = 3021;
*/
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Tama�o del array: %d\n",
                    numeros.length);

            System.out.println ();
            System.out.println ("Contenido del array usando un bucle: ");
            for ( int indice = 0 ; indice < numeros.length ; indice++ ) {
                System.out.printf ( "%d ", numeros[indice]);
            }

            System.out.println ();
            System.out.println ("Contenido del array usando Arrays.toString: ");
            System.out.println ( Arrays.toString(numeros) );

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

