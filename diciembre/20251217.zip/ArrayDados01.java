
package ejemplos2025Arrays;

/**
 * Programa Ejemplos de Arrays
 * @author diosdado
 */

import aguadulce.Dado;
import java.util.Arrays;
import java.util.Scanner;


public class ArrayDados01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes

            // Variables de entrada

            // Variables de salida
            Dado[] arrayDado = { new Dado(4),
                                          new Dado(6),
                                          new Dado(8),
                                          new Dado(12),
                                          new Dado(20),
            };

            // Variables auxiliares

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE ARRAYS DE DADOS");
            System.out.println("---------------------------");

            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            

            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Tama�o del array: %d\n",
                    arrayDado.length);
            System.out.println ("Contenido del array usando un bucle: ");
            for ( int indice= 0; indice < arrayDado.length ; indice++ ) {
                System.out.printf ("Dado %2d: %s\n",
                        indice, arrayDado[indice]);
            }

            System.out.println ();
            System.out.println ("Contenido del array usando toString: ");
            System.out.println ( Arrays.toString(arrayDado));
            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

