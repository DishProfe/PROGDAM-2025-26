
package ejemplos2025Arrays;

/**
 * Programa Ejemplos de Arrays
 * @author diosdado
 */

import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Scanner;


public class ArrayFechas01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes

            // Variables de entrada
            int year = 0;

            // Variables de salida
            LocalDate[] arrayFechas;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE ARRAYS DE FECHAS");
            System.out.println("----------------------------");
            boolean entradaValida = false;
            do {
                System.out.println("Introduzca a�o (1900-2100)");
                try {
                    year = teclado.nextInt();
                    entradaValida = year>=1900 && year<=2100;
                } catch ( InputMismatchException ex) {
                    teclado.nextInt();
                }                
            } while ( !entradaValida );
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Reservamos espacio para los elementos del array
            arrayFechas = new LocalDate[12];

            // Rellenamos cada posici�n del array con 
            // enteros aleatorios entre 0-9
            System.out.println ("Rellenando array...");
            for ( int indice=0 ; indice<arrayFechas.length ; indice++ ) {
                LocalDate primerDia = LocalDate.of (year, indice+1, 1);               
                arrayFechas[indice] = LocalDate.of (year, indice+1, primerDia.lengthOfMonth());
            }
            

            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Tama�o del array: %d\n",
                    arrayFechas.length);
            System.out.println ("Contenido del array: ");
            for ( int indice= 0; indice < arrayFechas.length ; indice++ ) {
                System.out.printf ("�ltimo d�a del mes %2d: %s\n",
                        indice+1, arrayFechas[indice]);
            }
            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

