
package ejemplos2025Arrays;

/**
 * Programa Ejemplos de Arrays
 * @author diosdado
 */

import aguadulce.Bombilla;
import java.util.Arrays;
import java.util.Scanner;


public class EjemploSplit01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes

            // Variables de entrada
            String texto;
            
            // Variables de salida
            String[] arrayElementos;

            // Variables auxiliares

            
            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE USO DE SPLIT");
            System.out.println("------------------------");
            System.out.println ("Introduzca elementos separados por ',' o '.' o ';'");
            texto = teclado.nextLine();
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            arrayElementos = texto.split ("[,.;]");
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Tama�o del array: %d\n",
                    arrayElementos.length);
            System.out.println ("Contenido del array usando un bucle: ");
            for ( int indice= 0; indice < arrayElementos.length ; indice++ ) {
                System.out.printf ("Elemento %2d: %s\n",
                        indice, arrayElementos[indice]);
            }

            System.out.println ();
            System.out.println ("Contenido del array usando toString: ");
            System.out.println ( Arrays.toString(arrayElementos));
            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

