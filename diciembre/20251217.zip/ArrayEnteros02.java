
package ejemplos2025Arrays;

/**
 * Programa Ejemplos de Arrays
 * @author diosdado
 */

import java.util.Scanner;


public class ArrayEnteros02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int NUM_ELEMENTOS = 10;

            // Variables de entrada
            int[] numeros;



            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE ARRAYS");
            System.out.println("------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Reservamos espacio para los elementos del array
            numeros = new int[NUM_ELEMENTOS];

            // Rellenamos cada posici�n del array con 
            // enteros aleatorios entre 0-9
            System.out.println ("Rellenando array...");
            for ( int indice=0 ; indice<numeros.length ; indice++ ) {
                numeros[indice] = (int)(Math.random()*10);
            }
            
            


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Tama�o del array: %d\n",
                    numeros.length);
            System.out.println ("Contenido del array: ");
            for ( int indice=0 ; indice<numeros.length ; indice++ ) {
                System.out.printf ("Elemento %d: %d\n", 
                        indice, numeros[indice]);
            }                       

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

