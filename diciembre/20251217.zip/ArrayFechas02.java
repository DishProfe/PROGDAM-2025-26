
package ejemplos2025Arrays;

/**
 * Programa Ejemplos de Arrays
 * @author diosdado
 */

import java.time.DateTimeException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Scanner;


public class ArrayFechas02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes

            // Variables de entrada
            int diaNacim, mesNacim, yearNacim=0;

            // Variables de salida
            DayOfWeek[] arrayCumples;


            // Variables auxiliares
            LocalDate fechaNacim = null;
            int sizeArray;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE ARRAYS DE FECHAS");
            System.out.println("----------------------------");
            boolean entradaValida = false;
            do {
                System.out.println("Introduzca fecha de nacimiento (d�a, mes, a�o)");
                try {
                    diaNacim = teclado.nextInt();
                    mesNacim = teclado.nextInt();
                    yearNacim = teclado.nextInt();
                    fechaNacim = LocalDate.of (yearNacim, mesNacim, diaNacim);
                    entradaValida = true;
                } catch ( InputMismatchException | DateTimeException ex) {
                    teclado.nextInt();
                }                
            } while ( !entradaValida );
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Calculamos el tama�o del array 
            int yearActual = LocalDate.now().getYear();
            sizeArray = yearActual - yearNacim + 1; 
            
            // Reservamos espacio para los elementos del array
            arrayCumples = new DayOfWeek[sizeArray];

            // Rellenamos cada posici�n del array con los d�as de la semana
            // de cada cumplea�os
            LocalDate fechaCumple = fechaNacim;
            for ( int indice=0 ; indice<arrayCumples.length ; indice++ ) {
                arrayCumples[indice] = fechaCumple.plusYears(indice).getDayOfWeek();
            }
            

            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("Tama�o del array: %d\n",
                    arrayCumples.length);
            System.out.println ("Contenido del array: ");
            for ( int indice= 0; indice < arrayCumples.length ; indice++ ) {
                System.out.printf ("D�a de la semana del cumplea�os %2d: %s\n",
                        indice, arrayCumples[indice]);
            }
            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

