
package ejemplos2025Strings;

/**
 * Programa Comprobador de n�meros binarios
 * @author diosdado
 */

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ComprobadorBinarios01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String textoEntrada;



            // Variables de salida
            boolean esBinario;


            // Variables auxiliares
            Pattern patron;
            Matcher acoplamiento;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBADOR DE BINARIOS");
            System.out.println("-----------------------");
            System.out.println("Introduzca un n�mero binario de al menos 4 bits: ");
            textoEntrada = teclado.nextLine();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------


            // Creamos el pattern para reconocer binarios
            patron = Pattern.compile ("[01]{4,}");
            
            // Creamos el matcher del texto que queremos comprobar
            acoplamiento = patron.matcher(textoEntrada);

            esBinario = acoplamiento.matches();
                
            
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El texto introducido encaja con un n�mero binario: %b\n", esBinario);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

