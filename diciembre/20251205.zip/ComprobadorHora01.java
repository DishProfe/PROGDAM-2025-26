
package ejemplos2025Strings;

/**
 * Programa Comprobador de hora en formato 24h
 * @author diosdado
 */

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ComprobadorHora01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String textoEntrada;



            // Variables de salida
            boolean esHoraValida;


            // Variables auxiliares
            Pattern patron;
            Matcher acoplamiento;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBADOR DE HORAS EN FORMATO 24H");
            System.out.println("-----------------------------------");
            System.out.println("Introduzca una hora en formato 24h hh:mm:ss : ");
            textoEntrada = teclado.nextLine();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------


            // Creamos el pattern para reconocer binarios
            patron = Pattern.compile ("([01]?[0-9]|2[0-3])(:[0-5][0-9]){2}");
            
            // Creamos el matcher del texto que queremos comprobar
            acoplamiento = patron.matcher(textoEntrada);

            esHoraValida = acoplamiento.matches();
                
            
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El texto introducido encaja con una hora 24: %b\n", esHoraValida);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

