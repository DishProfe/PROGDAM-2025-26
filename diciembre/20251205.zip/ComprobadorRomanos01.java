
package ejemplos2025Strings;

/**
 * Programa Comprobador de n�meros romanos
 * @author diosdado
 */

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ComprobadorRomanos01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String textoEntrada;



            // Variables de salida
            boolean esRomanoValido;


            // Variables auxiliares
            Pattern patron;
            Matcher acoplamiento;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBADOR DE N�MEROS ROMANOS");
            System.out.println("------------------------------");
            System.out.println("Introduzca un n�mero romano (hasta 3999) ");
            textoEntrada = teclado.nextLine();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------


            // Creamos el pattern para reconocer binarios
            patron = Pattern.compile ("M{0,3}(CM|CD|D?C{0,3})(XC|XL|L?X{0,3})(IX|IV|V?I{0,3})");
            
            // Creamos el matcher del texto que queremos comprobar
            acoplamiento = patron.matcher(textoEntrada);

            esRomanoValido = acoplamiento.matches();
                
            
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.printf ("El texto introducido encaja con un n�mero romano: %b\n", esRomanoValido);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

