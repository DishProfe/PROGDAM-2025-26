package ejemplos2025Strings;


import ejemplos2024Strings.*;
import java.util.Scanner;

/**
 *   Programa
 */

    public class BusquedaMal05 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        String textoEntrada;
        
        
        // Variables de salida
        int contadorMal;
        
        // Variables auxiliares
        boolean malEncontrado;
        int posicionMal = 0;


        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("BÚSQUEDA DEL MAL");
        System.out.println("----------------");

            System.out.print("Introduzca el texto: ");
            textoEntrada = teclado.nextLine();

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        posicionMal = -1; // Para que al sumar +1 se comience por la posición 0
        contadorMal =  0;
        do {
            posicionMal = textoEntrada.toLowerCase().indexOf ("mal", posicionMal+1) ;
            malEncontrado = posicionMal >= 0;
            if (malEncontrado) {
                contadorMal++;
            }
        } while ( malEncontrado  );
          


        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        System.out.printf ("Número de veces encontrado el mal: %d\n", contadorMal);
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}