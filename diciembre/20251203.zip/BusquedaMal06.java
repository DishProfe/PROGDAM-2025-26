package ejemplos2025Strings;


import ejemplos2024Strings.*;
import java.util.Scanner;

/**
 *   Programa
 */

    public class BusquedaMal06 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        String textoEntrada;
        
        
        // Variables de salida
        int contadorMal;
        
        // Variables auxiliares
        boolean malEncontrado;
        int posicionMal = 0;


        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("BÚSQUEDA DEL MAL");
        System.out.println("----------------");

            System.out.print("Introduzca el texto: ");
            textoEntrada = teclado.nextLine();

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        contadorMal =  0;
        posicionMal = textoEntrada.toLowerCase().indexOf ("mal") ;
        while ( posicionMal >= 0 ){
            contadorMal++;
            posicionMal = textoEntrada.toLowerCase().indexOf ("mal", posicionMal+1) ;
        } 
          
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        System.out.printf ("Número de veces encontrado el mal: %d\n", contadorMal);
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}