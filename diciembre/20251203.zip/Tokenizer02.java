
package ejemplos2025Strings;

/**
 * Programa Ejemplo de troceado de cadenas
 * @author diosdado
 */

import java.util.Scanner;
import java.util.StringTokenizer;

public class Tokenizer02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String entrada;



            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("TROCEADO DE CADENAS");
            System.out.println("-------------------");
            System.out.println("Usamos separador por omisi�n (espacio)");

            entrada = teclado.nextLine ();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            StringTokenizer troceador = new StringTokenizer (entrada);

            int contador = 0;
            while ( troceador.hasMoreTokens() ) {
                String elemento = troceador.nextToken();
                System.out.printf ("Elmento %d: %s\n", ++contador, elemento);
            }                    

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

