package ejemplos2025Strings;


import ejemplos2024Strings.*;
import java.util.Scanner;

/**
 *   Programa
 */

    public class BusquedaMal02 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        String textoEntrada;
        
        
        // Variables de salida
        boolean malEncontrado;
        int posicion;

        // Variables auxiliares


        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("BÚSQUEDA DEL MAL");
        System.out.println("----------------");

            System.out.print("Introduzca el texto: ");
            textoEntrada = teclado.nextLine();

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        //malEncontrado = textoEntrada.toLowerCase().contains("mal");        
        malEncontrado = textoEntrada.toLowerCase().indexOf ("mal") >= 0 ;
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        System.out.println("Mal encontrado: " + malEncontrado);
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}