package ejemplos2025Strings;


import ejemplos2024Strings.*;
import java.util.Scanner;

/**
 *   Programa
 */

    public class BusquedaMal03 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        String textoEntrada;
        
        
        // Variables de salida
        boolean malEncontrado;
        int posicionMal = 0;

        // Variables auxiliares


        // Clase Scanner para petición de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("BÚSQUEDA DEL MAL");
        System.out.println("----------------");

            System.out.print("Introduzca el texto: ");
            textoEntrada = teclado.nextLine();

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        //malEncontrado = textoEntrada.toLowerCase().contains("mal");        
        posicionMal = textoEntrada.toLowerCase().indexOf ("mal") ;
        malEncontrado = posicionMal >= 0;
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
        System.out.println ();
	System.out.println ("RESULTADO");
	System.out.println ("---------");
        if (malEncontrado) {
            System.out.printf("Mal encontrado en posición: %d\n", posicionMal);
        } else {
            System.out.println("Mal no encontrado");            
        }
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
        
        
    }
    
}