
package ejemplos2025Strings;

/**
 * Programa Ejemplo de n�meros en varias bases
 * @author diosdado
 */

import java.util.Scanner;


public class NumerosFormato02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("INT PASADO A STRING EN DIFERENTES BASES");
            System.out.println("---------------------------------------");
            System.out.println(" ");



            int valorInt=255;
            
            String textoIntDec= String.format ("%d", valorInt);
            String textoIntHexMin= String.format ("%x", valorInt);
            String textoIntHexMay= String.format ("%X", valorInt);
            String textoIntBin= Integer.toBinaryString(valorInt);
            String textoIntOct= String.format( "%o", valorInt);

            System.out.printf ("Entero: %d (la pantalla lo representa en base decimal, aunque internamente en el ordenador est� en binario)\n", valorInt);
            System.out.printf ("Cadena (dec): \"%s\" (representaci�n textual del n�mero en base decimal)\n", textoIntDec);
            System.out.printf ("Cadena (hex): \"%s\" (representaci�n textual del n�mero en base hexadecimal en may)\n", textoIntHexMin);
            System.out.printf ("Cadena (hex): \"%s\" (representaci�n textual del n�mero en base hexadecimal en min)\n", textoIntHexMay);
            System.out.printf ("Cadena (bin): \"%s\" (representaci�n textual del n�mero en base binaria)\n", textoIntBin);
            System.out.printf ("Cadena (oct): \"%s\" (representaci�n textual del n�mero en base octal)\n", textoIntOct);


            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

