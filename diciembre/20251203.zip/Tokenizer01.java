
package ejemplos2025Strings;

/**
 * Programa Ejemplo de troceado de cadenas
 * @author diosdado
 */

import java.util.Scanner;
import java.util.StringTokenizer;

public class Tokenizer01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String entrada;



            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("TROCEADO DE CADENAS");
            System.out.println("-------------------");
            System.out.println("Usamos separador por omisi�n (espacio)");

            entrada = teclado.nextLine ();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            StringTokenizer troceador = new StringTokenizer (entrada);
            String primerElemento = troceador.nextToken();
            String segundoElemento = troceador.nextToken();
            String tercerElemento = troceador.nextToken();
            System.out.printf ("Nombre completo: %s\n", entrada);
            System.out.printf ("Primer token: %s \nSegundo token: %s \nTercer token: %s\n", 
                    primerElemento, segundoElemento, tercerElemento);


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

