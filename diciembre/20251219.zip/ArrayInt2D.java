
package ejemplos2025Arrays;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Arrays;
import java.util.Scanner;


public class ArrayInt2D {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida
            int[][] arrayInt2D;
            
            int[] arrayInt1;
            int[] arrayInt2;
            int[] arrayInt3;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLO DE ARRAYS DE INT");
            System.out.println("------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            arrayInt2D = new int[3][];

            arrayInt1 = new int[2];
            arrayInt2 = new int[5];
            arrayInt3 = new int[3];

            arrayInt2D[0] = arrayInt1;
            arrayInt2D[1] = arrayInt2;
            arrayInt2D[2] = arrayInt3;
            
            arrayInt1[0] = 1;
            arrayInt1[1] = 2;
            
            arrayInt2[0] = 12;
            arrayInt2[1] = 13;
            arrayInt2[2] = 14;
            arrayInt2[3] = 15;
            arrayInt2[4] = 16;

            arrayInt3[0] = 100;
            arrayInt3[1] = 200;
            arrayInt3[2] = 300;
            




            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");

            // Mostramos el contenido de los arrays mediante Arrays.toString
            System.out.println ();
            System.out.println("Mostramos el contenido de los arrays mediante Arrays.toString");
            System.out.printf ("arrayInt = %s\n", 
                    Arrays.toString(arrayInt2D));
            
            System.out.printf ("arrayInt1 = %s\n", 
                    Arrays.toString(arrayInt1));
            
            System.out.printf ("arrayInt2 = %s\n", 
                    Arrays.toString(arrayInt2));

            System.out.printf ("arrayInt3 = %s\n", 
                    Arrays.toString(arrayInt3));
            

            // Mostramos el contenido de los arrays mediante Arrays.deepToString
            System.out.println ();
            System.out.println("Mostramos el contenido de los arrays mediante Arrays.deepToString");
            System.out.printf ("arrayInt = %s\n", 
                    Arrays.deepToString(arrayInt2D));
            
            
            
            // Mostramos el contenido de los arrays mediante bucles for "convencionales"
            System.out.println ();
            System.out.println("Mostramos el contenido de los arrays mediante bucles for \"convencionales\"");
            System.out.print ("arrayInt = ");
            for (int indice1=0 ; indice1 < arrayInt2D.length ; indice1++ ) {
                int[] elemento = arrayInt2D[indice1];
                //System.out.printf ("%s ", elemento);
                System.out.print ("[ ");
                for ( int indice2 = 0 ; indice2 < elemento.length ; indice2++ ) {
                    System.out.printf ("%d ", elemento[indice2]);
                }
                System.out.print ("] ");
            }
            System.out.println ();
            
            

            // Mostramos el contenido de los arrays mediante bucles foreach/for in
            System.out.println ();
            System.out.println("Mostramos el contenido de los arrays mediante bucles foreach");

            System.out.print ("arrayInt = ");
            for ( int[] subarray : arrayInt2D ) {
                //System.out.printf ("%s ", subarray );
                System.out.print ("[ ");
                for ( int elemento : subarray ) {
                    System.out.printf ("%d ", elemento);
                }
                System.out.print ("] ");
            }
            System.out.println ();


            


            // Mostramos el contenido de los arrays mediante bucles while
            System.out.println ();
            System.out.println("Mostramos el contenido de los arrays mediante bucles while");
            System.out.print ("arrayInt = ");
            int indice1=0;
            while ( indice1 < arrayInt2D.length ) {
                int[] elemento = arrayInt2D[indice1++];
                //System.out.printf ("%s ", elemento);
                int indice2 = 0;
                System.out.print("[ ");
                while ( indice2 < elemento.length ) {
                    System.out.printf("%d ", elemento[indice2++]);
                }
                System.out.print("] ");
            }
            System.out.println ();



            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

