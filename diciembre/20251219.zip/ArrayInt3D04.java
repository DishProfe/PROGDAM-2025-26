
package ejemplos2025Arrays;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Arrays;
import java.util.Scanner;


public class ArrayInt3D04 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida
            // Reserva de espacio para el array con los contenidos ya conocidos
            int[][][] arrayInt3D =  { { { 1, 2, 3 }, { 4, 5 }, {6, 7 } }, { { 8, 9 }, { 10 } } };
            


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLO DE ARRAYS DE INT");
            System.out.println("------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------



            


            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");

            // Mostramos el contenido de los arrays mediante Arrays.toString
            System.out.println ();
            System.out.println("Mostramos el contenido de los arrays mediante Arrays.toString");
            System.out.printf ("arrayInt = %s\n", 
                    Arrays.toString(arrayInt3D));
            

            // Mostramos el contenido de los arrays mediante Arrays.deepToString
            System.out.println ();
            System.out.println("Mostramos el contenido de los arrays mediante Arrays.deepToString");
            System.out.printf ("arrayInt = %s\n", 
                    Arrays.deepToString(arrayInt3D));
            
            
            
            // Mostramos el contenido de los arrays mediante bucles for "convencionales"
            System.out.println ();
            System.out.println("Mostramos el contenido de los arrays mediante bucles for \"convencionales\"");
            System.out.print ("arrayInt = ");
            for (int indice1 = 0 ; indice1 < arrayInt3D.length ; indice1++ ) {
                System.out.print ("[ ");
                for ( int indice2 = 0 ; indice2 < arrayInt3D[indice1].length ; indice2++ ) {
                    System.out.print ("[ ");
                    for ( int indice3 = 0 ; indice3 < arrayInt3D[indice1][indice2].length ; indice3++ ) {
                        System.out.printf ("%d ", arrayInt3D[indice1][indice2][indice3]);
                    }
                    System.out.print ("] ");
                }
                System.out.print ("] ");
            }
            System.out.println ();
            
            

            // Mostramos el contenido de los arrays mediante bucles foreach/for in
            System.out.println ();
            System.out.println("Mostramos el contenido de los arrays mediante bucles foreach");

            System.out.print ("arrayInt = ");
            for ( int[][] subarray1 : arrayInt3D ) {
                System.out.print ("[ ");
                for ( int[] subarray2 : subarray1 ) {
                    System.out.print ("[ ");
                    for ( int elemento: subarray2 ) {
                        System.out.printf ("%d ", elemento);
                    }
                    System.out.print ("] ");
                }
                System.out.print ("] ");
            }
            System.out.println ();


            



            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

