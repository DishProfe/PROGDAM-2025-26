
package ejemplos2025Arrays;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Arrays;
import java.util.Scanner;


public class ArrayInt3D02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida
            int[][][] arrayInt3D;
            

            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLO DE ARRAYS DE INT");
            System.out.println("------------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Reserva de espacio para el array de la primera dimensi�n
            arrayInt3D = new int[2][][];

            // Reserva de espacio para los arrays de la segunda dimensi�n
            arrayInt3D[0] = new int[3][];
            arrayInt3D[1] = new int[2][];

            // Reserva de espacio para los arrays de la tercera dimensi�n
            arrayInt3D[0][0] = new int[3];
            arrayInt3D[0][1] = new int[2];
            arrayInt3D[0][2] = new int[2];

            arrayInt3D[1][0] = new int[2];
            arrayInt3D[1][1] = new int[1];

            
            // Rellenamos "a mano" todas las casillas del array
            arrayInt3D[0][0][0] = 1;
            arrayInt3D[0][0][1] = 2;
            arrayInt3D[0][0][2] = 3;
            arrayInt3D[0][1][0] = 4;
            arrayInt3D[0][1][1] = 5;
            arrayInt3D[0][2][0] = 6;
            arrayInt3D[0][2][1] = 7;
            arrayInt3D[1][0][0] = 8;
            arrayInt3D[1][0][1] = 9;
            arrayInt3D[1][1][0] = 10;
            

            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");

            // Mostramos el contenido de los arrays mediante Arrays.toString
            System.out.println ();
            System.out.println("Mostramos el contenido de los arrays mediante Arrays.toString");
            System.out.printf ("arrayInt = %s\n", 
                    Arrays.toString(arrayInt3D));
            

            // Mostramos el contenido de los arrays mediante Arrays.deepToString
            System.out.println ();
            System.out.println("Mostramos el contenido de los arrays mediante Arrays.deepToString");
            System.out.printf ("arrayInt = %s\n", 
                    Arrays.deepToString(arrayInt3D));
            
            
            
            // Mostramos el contenido de los arrays mediante bucles for "convencionales"
            System.out.println ();
            System.out.println("Mostramos el contenido de los arrays mediante bucles for \"convencionales\"");
            System.out.print ("arrayInt = ");
            for (int indice1 = 0 ; indice1 < arrayInt3D.length ; indice1++ ) {
                System.out.print ("[ ");
                for ( int indice2 = 0 ; indice2 < arrayInt3D[indice1].length ; indice2++ ) {
                    System.out.print ("[ ");
                    for ( int indice3 = 0 ; indice3 < arrayInt3D[indice1][indice2].length ; indice3++ ) {
                        System.out.printf ("%d ", arrayInt3D[indice1][indice2][indice3]);
                    }
                    System.out.print ("] ");
                }
                System.out.print ("] ");
            }
            System.out.println ();
            
            

            // Mostramos el contenido de los arrays mediante bucles foreach/for in
            System.out.println ();
            System.out.println("Mostramos el contenido de los arrays mediante bucles foreach");

            System.out.print ("arrayInt = ");
            for ( int[][] subarray1 : arrayInt3D ) {
                System.out.print ("[ ");
                for ( int[] subarray2 : subarray1 ) {
                    System.out.print ("[ ");
                    for ( int elemento: subarray2 ) {
                        System.out.printf ("%d ", elemento);
                    }
                    System.out.print ("] ");
                }
                System.out.print ("] ");
            }
            System.out.println ();


            



            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

