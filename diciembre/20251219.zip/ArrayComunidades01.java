
package ejemplos2025Arrays;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Arrays;
import java.util.Scanner;


public class ArrayComunidades01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida
            String[] arrayComunidades = {"Andaluc�a", "Arag�n", "Asturias" };
            


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("ARRAYS DE GEOGRAF�A");
            System.out.println("-------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");

            // Mostramos el contenido de los arrays mediante Arrays.toString
            System.out.println ();
            System.out.println("Mostramos el contenido de los arrays mediante Arrays.toString");
            System.out.printf ("arrayComunidades = %s\n", 
                    Arrays.toString(arrayComunidades));
            
            
            
            // Mostramos el contenido de los arrays mediante bucles for "convencionales"
            System.out.println ();
            System.out.println("Mostramos el contenido de los arrays mediante bucles for \"convencionales\"");
            System.out.print ("arrayInt = ");
            for (int indice1 = 0 ; indice1 < arrayComunidades.length ; indice1++ ) {
                        System.out.printf ("%s ", arrayComunidades[indice1]);
            }
            System.out.println ();
            

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

