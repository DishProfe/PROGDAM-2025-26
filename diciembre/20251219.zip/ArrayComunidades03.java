
package ejemplos2025Arrays;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Arrays;
import java.util.Scanner;


public class ArrayComunidades03 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida
            String[] arrayComunidades = {"Andaluc�a", "Arag�n", "Asturias" };
            
            String[][] arrayProvincias = { 
                { "Almer�a", "C�diz", "C�rdoba", "Granada", "Huelva", "Ja�n", "M�laga", "Sevilla" } , 
                { "Huesca", "Zaragoza", "Teruel"}, 
                { "Asturias"} 
            };

            String[][][] arrayComarcas = {
                {
                    {"Alpujarra Almeriense", "Los Filabres-Tabernas", "Levante Almeriense", "Poniente Almeriense"},
                    {"Bah�a de C�diz", "Campo de Gibaltar"},
                    {"Campi�a Este-Guadajoz", "Campi�a Sur", "Los Pedroches"},
                    {"Alhama", "Altiplano de Granada"}
                },
                {
                    {"Alto G�llego", "Cinca Medio", "Hoya de Huesca"},
                    {"Andorra-Sierra de Arcos", "Bajo Arag�n"},
                    {"Aranda", "Campo de Borja"}
                },
                {
                    {"Avil�s", "CAudal", "Eo-Navia", "Gij�n", "Nal�n"}
                }
                        
            };

            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("ARRAYS DE GEOGRAF�A");
            System.out.println("-------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");

            // Mostramos el contenido de los arrays mediante Arrays.toString
            System.out.println ();
            System.out.println("Mostramos el contenido de los arrays mediante Arrays.toString y Arrays.deepToString");
            System.out.printf ("arrayComunidades = %s\n", 
                    Arrays.toString(arrayComunidades));
            
            System.out.printf ("arrayProvincias = %s\n", 
                    Arrays.deepToString(arrayProvincias));
            
            
            

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

