
package ejemplos2025;

/**
 * Programa Qu� n�mero est� m�s cercano a 100
 * @author diosdado
 */

import java.util.Scanner;


public class Cercano100 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int num1, num2;




            // Variables de salida
           int masCercano100;



            // Variables auxiliares
            int distancia1;
            int distancia2;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("QU� N�MERO EST� M�S CERCANO A 100");
            System.out.println("---------------------------------");

            System.out.println ("Introduzca dos enteros a, y b:");
            num1 = teclado.nextInt();
            num2 = teclado.nextInt();
            
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            distancia1 = Math.abs(100 - num1);
            distancia2 = Math.abs(100 - num2);
            
            masCercano100 = distancia1 < distancia2 ? num1 : num2 ;



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El m�s cercano a 100 es: " + masCercano100);

            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}
