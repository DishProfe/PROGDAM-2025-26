
package ejemplos2025;

/**
 * Programa Comprobador de tipo de tri�ngulo
 * @author diosdado
 */

import java.util.Scanner;


public class Triangulo01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int lado1, lado2, lado3;



            // Variables de salida
            String tipoTriangulo;


            // Variables auxiliares
            boolean trianguloCorrecto;
            boolean tresLadosIguales;
            boolean dosLadosIguales;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBADOR DE TIPO DE TRI�NGULO");
            System.out.println("--------------------------------");
            System.out.println("Introduzca los tres lados del tri�ngulo");

            lado1 = teclado.nextInt();
            lado2 = teclado.nextInt();
            lado3 = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            trianguloCorrecto = lado1<lado2+lado3 && lado2<lado1+lado3 && lado3<lado1+lado2;
            
            
            //tipoTriangulo = !trianguloCorrecto ? "Error" : "Tri�ngulo v�lido";        

            
            tresLadosIguales = lado1==lado2 && lado2==lado3;

/*
            tipoTriangulo = 
                    !trianguloCorrecto ? "Error" : 
                    (  tresLadosIguales ? "Equil�tero" : "No equil�tero"  ) ;        
*/            
            
            
            dosLadosIguales = lado1== lado2 || lado1==lado3 || lado2==lado3;
            
            tipoTriangulo = 
                    !trianguloCorrecto ? "Error" : 
                    (  tresLadosIguales ? "Equil�tero" : 
                       ( dosLadosIguales ? "Is�sceles" : "Escaleno"  )
                    ) ;        

            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println (tipoTriangulo);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

