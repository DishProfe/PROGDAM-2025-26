
package ejemplos2025;

/**
 * Programa para obtener el c�digo de un car�cter
 * @author diosdado
 */

import java.util.Scanner;


public class ObtenerCodigoCaracter01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            char caracter;



            // Variables de salida
            int codigo;



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("OBTENCI�N DE C�DIGO DE UN CAR�CTER");
            System.out.println("---------------------");
            System.out.println("Introduzca un car�cter");
            caracter = teclado.nextLine().charAt(0);
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            codigo = (int) caracter;



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El c�digo de '" + caracter + "' es " + codigo);
            

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

