
package ejemplos2025;

/**
 * Programa para saber si un n�mero es un cuadrado perfecto
 * @author diosdado
 */

import java.util.Scanner;


public class CuadradoPerfecto01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;




            // Variables de salida
            boolean esCuadradoPerfecto;



            // Variables auxiliares
            int raizEntera;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBACI�N DE CUADRADO PERFECTO");
            System.out.println("---------------------------------");

            System.out.println ("Introduzca n�mero entero:");
            numero = teclado.nextInt();
            
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            raizEntera = (int) Math.sqrt (numero);
        
            esCuadradoPerfecto = raizEntera*raizEntera == numero;


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El n�mero es cuadrado perfecto: " + esCuadradoPerfecto);
            System.out.println ("El n�mero " + ( esCuadradoPerfecto ? "" : "no " ) + "es cuadrado perfecto");
            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}
