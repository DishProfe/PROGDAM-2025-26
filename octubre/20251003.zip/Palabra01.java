
package ejemplos2025;

/**
 * Programa para trabajar con textos
 * @author diosdado
 */

import java.util.Scanner;


public class Palabra01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String palabra;




            // Variables de salida
            char primeraLetra;
            char ultimaLetra;
            
            char segundaLetra;
            char penultimaLetra;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("PROGRAMAS DE EJEMPLO CON TEXTOS");
            System.out.println("-------------------------------");
            System.out.println("Introduzca palabra: ");
            palabra = teclado.nextLine();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            primeraLetra = palabra.charAt(0);
            ultimaLetra = palabra.charAt ( palabra.length() - 1 );

            segundaLetra =  palabra.charAt(1);
            penultimaLetra = palabra.charAt ( palabra.length() - 2 );


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Palabra: " + palabra);
            System.out.println ("Primera letra: " + "'" + primeraLetra + "'");
            System.out.println ("Segunda letra: " + "'" + segundaLetra + "'");
            System.out.println ("Pen�ltima letra: " + "'" + penultimaLetra + "'");
            System.out.println ("�ltima letra: " + "'" + ultimaLetra + "'");

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

