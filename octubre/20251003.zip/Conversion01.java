package ejemplos2025;

/**
 * Programa XXX
 *
 * @author diosdado
 */
import java.util.Scanner;

public class Conversion01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------
        // Constantes
        // Variables de entrada
        // Variables de salida
        // Variables auxiliares
        int int1, int2, int3;
        long lon1, lon2, lon3;
        float r1, r2, r3;
        double r4, r5, r6;

        short s1, s2, s3;

        int ent1;
        long ent2;
        double real1;
        float real2;

        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("EJEMPLOS DE CONVERSI�N");
        System.out.println("----------------------");
        System.out.println(" ");

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        int1 = 100;
        lon1 = 200;
        lon2 = int1;
        int2 = (int) lon1;
        s1 = (short) int1;
        real1 = 100;
        real2 = 100f;
        r3 = (float) 100.0;

        r4 = 750;

        ent1 = 0; ent2 = 0; real1 = 0.0; real2 = 0f;
        
        real2 = (float) 3_000_000_000L;
        
        
        ent2  = (long) (55*2.0);
        ent1  = (int) (55+5L);
        
        
        
        //---------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");

        System.out.println();
        System.out.println("Fin del programa.");

    }

}
