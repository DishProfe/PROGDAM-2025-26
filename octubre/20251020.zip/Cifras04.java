
package ejemplos2025;

/**
 * Programa que reciba desde teclado dos n�meros enteros: uno de varias
 * cifras y uno de una cifra (es decir, una cifra entre 0 y 9). El programa debe 
 * calcular cuantas veces aparece esa cifra en el n�mero.
 * @author diosdado
 */

import java.util.Scanner;


public class Cifras04 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;
            int cifra;

            // Variables de salida
            int numVeces;


            // Variables auxiliares
            int resto;
            int numDescendente;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO DEL N�MERO DE VECES QUE EST� UNA CIFRA EN UN N�MERO");
            System.out.println("-----------------------------------------------------------");

            System.out.println("Introduzca n�mero entero: ");
            numero = teclado.nextInt ();

            System.out.println("Introduzca cifra: ");
            cifra = teclado.nextInt ();
            
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            
            // Valor inicial del contador
            // Este contador se ir� incrementando en 1 cada vez que 
            // encuentre un resto que coincida con la cifra
            numVeces = 0;
            numDescendente = numero;
            
            for (  ; numDescendente > 0    ;   ) {
            
                // An�lisis cifra:
                // --------------
                    // Obtenemos la �ltima cifra (unidad) del n�mero que estamos analizando
                    resto = numDescendente % 10;
                    if ( resto == cifra ) {
                        numVeces++;
                    }

                    // Calculamos que el cociente para "quitar" la �ltima cifra
                    numDescendente = numDescendente / 10;
            
            }
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("La cifra " + cifra + " aparece " + numVeces + " veces en " + numero);
            


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}