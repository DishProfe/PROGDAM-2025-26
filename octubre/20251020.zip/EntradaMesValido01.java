
package ejemplos2025;

/**
 * Programa con validaci�n de entrada para un mes
 * @author diosdado
 */

import java.util.Scanner;


public class EntradaMesValido01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int mes;




            // Variables de salida



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("VALIDACI�N DE MES");
            System.out.println("-----------------");
            
            do {
                System.out.println("Introduzca mes (1-12)");
                mes = teclado.nextInt();
            } while ( mes > 12 || mes < 1 ); // Mientras el mes est� fuera del rango se repite la petici�n

            // No se sale del bucle hasta que el mes sea v�lido
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Por ahora no hacemos nada
            // Pero si hemos llegado hasta aqu� es por que el mes es v�lido



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El mes introducido es " + mes);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}