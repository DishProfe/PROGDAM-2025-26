
package ejemplos2025;

/**
 * Programa para invertir un texto
 * @author diosdado
 */

import java.util.Scanner;


public class InvertirTexto01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String texto;



            // Variables de salida
            String textoInvertido;


            // Variables auxiliares
            int indice;
            int longTexto;
            char c;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("INVERSI�N DEL TEXTO");
            System.out.println("-------------------");
            System.out.println("Introduzca texto para invertir: ");
            texto = teclado.nextLine();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            
            // Obtenemos la longitud del texto
            longTexto = texto.length();
            
            // Inicializamos el resultado (texto invertido) con la cadena vac�a
            textoInvertido = "";
            
            for ( indice = 0; indice < longTexto ; indice++ ) {
                c = texto.charAt(indice);
                textoInvertido = c + textoInvertido;
            }


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println (textoInvertido);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}