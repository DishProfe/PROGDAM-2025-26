
package ejemplos2025;

/**
 * Programa Para multiplicar los n�meros entre n y m
 * @author diosdado
 */

import java.util.Scanner;


public class BucleMultiplicador01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int valorInicial, valorFinal;



            // Variables de salida
            int producto;


            // Variables auxiliares
            int inicio, fin;
            int contador;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("MULTIPLICADOR");
            System.out.println("-------------");
            System.out.println("Introduzca n�meros inicial y final para multiplicar:");
            valorInicial = teclado.nextInt();
            valorFinal = teclado.nextInt();

            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            inicio = Math.min (valorInicial, valorFinal);
            fin = Math.max (valorInicial, valorFinal);
            
            // Valor inicial del acumulador: 1 pues vamos a ir multiplicando
            producto = 1;
            
            for ( contador = inicio ; contador<=fin ; contador++ ) {
                producto *= contador;
                
            }
            



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println (producto);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}