
package ejemplos2025;

/**
 * Programa Contador de vocales may�sculas
 * @author diosdado
 */

import java.util.Scanner;


public class NumVocalesMay03 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String texto;



            // Variables de salida
            int numVocalesMay;
            String textoEscondido;


            // Variables auxiliares
            int indice;
            int longTexto;
            char c;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CONTEO DE VOCALES MAY�SCULAS");
            System.out.println("----------------------------");
            System.out.println("Introduzca un texto:");
            texto = teclado.nextLine();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Obtengo la longitud del texto
            longTexto = texto.length();
            
            // Valor inicial del contador de vocales
            numVocalesMay = 0;
            
            // Valor inicial del texto acumulativo de salida
            textoEscondido = "";
            
            // Recorremos todos los caracteres del texto
            for ( indice = 0 ; indice < longTexto ; indice++ ) {
                // Obtenemos cada caracter
                c = texto.charAt(indice);
                // Comprobamos si el caracter es o no vocal may�scula
                if ( c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U') {
                    // Si es una vocal may�scula, incrementamos el contador
                    numVocalesMay++;
                    
                    // A�ado la vocal a la salida
                    textoEscondido = textoEscondido + c;
                    
                } else if ( c >='A' && c <='Z' || c >= 'a' && c <='z') {
                    // Si cualquier otra letra a�ado '-' a la salida
                    textoEscondido = textoEscondido + "-";                    
                } else {
                    // A�ado el car�cter no letra a la salida
                    textoEscondido = textoEscondido + c;                    
                }
            }



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Cantidad de vocales may�sculas: " +
                    numVocalesMay);
            System.out.println (texto);
            System.out.println (textoEscondido);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}