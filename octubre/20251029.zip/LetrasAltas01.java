
package ejemplos2025;

/**
 * Programa Localizaci�n de Letras Altas
 * @author diosdado
 */

import java.util.Scanner;


public class LetrasAltas01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String texto;



            // Variables de salida
            int numLetrasAltas;
            String textoResultado;



            // Variables auxiliares
            int longTexto;
            int posicion;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("LOCALIZACI�N DE LETRAS ALTAS");
            System.out.println("----------------------------");
            System.out.println("Introduzca texto");
            texto = teclado.nextLine();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            longTexto = texto.length();
            posicion = 0; 
            numLetrasAltas = 0;
            textoResultado = "";
            while ( posicion < longTexto ) {
                char c = texto.charAt(posicion);
                if ( (c >= 'A' && c <= 'Z') || c=='b' || c=='d' || c=='f' || c=='h' || c=='l' || c=='t' || c=='j' || c=='i' ) {
                    numLetrasAltas++;
                    textoResultado += c;
                    //System.out.print (c + " ");
                } else {
                    textoResultado += ".";                    
                }
                
                posicion++;
            }



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("N�mero de letras altas: " + numLetrasAltas);
            System.out.println (texto);
            System.out.println (textoResultado);
            
//Esto es una prueba de texto con letras altas...

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

