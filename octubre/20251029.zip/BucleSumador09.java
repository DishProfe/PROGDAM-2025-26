
package ejemplos2025;

/**
 * Programa Que suma los n�meros entre n y m
 * @author diosdado
 */

import java.util.Scanner;


public class BucleSumador09 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int valorInicial, valorFinal;




            // Variables de salida
            int suma;


            // Variables auxiliares
            int inicio, fin;
            int contador;
            int temp;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("SUMADOR");
            System.out.println("-------");
            System.out.println("Programa que suma los n�meros desde n (inicio) hasta m (fin) de dos en dos");

            System.out.println("Introduzca el valor de n: ");
            valorInicial = teclado.nextInt();

            System.out.println("Introduzca el valor de m: ");
            valorFinal = teclado.nextInt();
                
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // El valor inicial debe ser el menor y el final el mayor
            inicio = Math.min(valorInicial, valorFinal);
            fin = Math.max(valorInicial, valorFinal);
            
            // Valor inicial del acumulador
            suma = 0;
            
            // Bucle que va desde 0 hasta n
            for ( contador = inicio ; contador <= fin ; contador += 10 ) {
                // Voy acumulando (sumando) cada valor de contador
                suma = suma + contador;
                
            }
            


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println (suma);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}