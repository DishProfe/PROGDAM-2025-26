
package ejemplos2025;

/**
 * Programa Tabla de multiplicar
 * @author diosdado
 */

import java.util.Scanner;


public class TablaMultiplicar01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;




            // Variables de salida
            String tabla;


            // Variables auxiliares
            int contador;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("TABLA DE MULTIPLICAR");
            System.out.println("--------------------");
            
            do {
                System.out.println("Introduzca n�mero 1- 9 para calcular su tabla");
                numero = teclado.nextInt();
            } while ( numero<1 || numero>9 );
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Valor inicial del acumulador: cadena vac�a
            tabla = "";
            // Bucle desde 1 hasta 10 para generar cada l�nea de la tabla 
            for ( contador = 1; contador<=10 ; contador++ ) {
                // Vamos concatenando en la cadena cada l�nea (terminada en \n para que sea una l�nea nueva)
                tabla = tabla + numero + "x" + contador + "=" + numero*contador + "\n";                
            }

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println (tabla);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}