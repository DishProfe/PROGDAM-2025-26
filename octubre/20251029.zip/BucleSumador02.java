
package ejemplos2025;

/**
 * Programa Que suma los n primeros n�meros
 * @author diosdado
 */

import java.util.Scanner;


public class BucleSumador02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;




            // Variables de salida
            int suma;


            // Variables auxiliares
            int contador;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("SUMADOR");
            System.out.println("-------");
            System.out.println("Programa que suma los n�meros desde 1 hasta n.");
            System.out.println("Introduzca el valor de n: ");
            numero = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Valor inicial del acumulador
            suma = 0;
            
            // Bucle que va desde 0 hasta n
            contador = 0;
            while ( contador <= numero ) {
                // Voy acumulando (sumando) cada valor de contador
                suma = suma + contador;
            
                contador++;
            }
            


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println (suma);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}