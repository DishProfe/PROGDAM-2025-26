
package ejemplos2025;

/**
 * Programa para generar una serie
 * @author diosdado
 */

import java.util.Scanner;


public class SerieNumerica02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int valorInicial, valorFinal;



            // Variables de salida
            String serie;


            // Variables auxiliares
            int inicio, fin;
            int contador;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("SERIE NUM�RICA");
            System.out.println("--------------");
            System.out.println("Introduzca valores inicial y final:");
            valorInicial = teclado.nextInt();
            valorFinal = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            inicio = Math.min (valorInicial, valorFinal);
            fin = Math.max (valorInicial, valorFinal);
            
            serie = "";
            
            for ( contador= inicio ; contador <= fin ; contador++ ) {

                if (contador>inicio) {
                    serie += " ";
                }
                serie = serie + contador; 

            }



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println (serie); 


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}