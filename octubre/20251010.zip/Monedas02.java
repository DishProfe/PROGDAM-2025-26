
package ejemplos2025;

/**
 * Programa M�quina de cambio
 * @author diosdado
 */

import ejemplos2025.resueltos.*;
import java.util.Scanner;


public class Monedas02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            double euros;




            // Variables de salida
            int m2, m1, m050, m020, m010, m005, m002, m001;



            // Variables auxiliares
            int resto;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("M�QUINA DE CAMBIO");
            System.out.println("-----------------");
            System.out.println("Introduzca cantidad total en euros: ");
            euros = teclado.nextDouble();
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            
            // Monedas de 2 euros: el cociente de dividir entre 2
            m2 = (int)euros / 2;
            
            // Monedas de 1 euro (0 o 1): lo que sobre de dividir entre 2
            m1 = (int)euros % 2;

            // El resto que queda son c�ntimos: lo pasamos a enteros
            resto = (int)((euros - 2*m2 - m1)*100) ;

            // Monedas de 50 c�ntimos (0 o 1)
            m050 = resto / 50;
            resto = resto % 50; // El nuevo resto debe ser menor de 50 c�ntimos
            
            // Monedas de 20 c�ntimos (0,1 o 2)
            m020 = resto / 20;
            resto = resto % 20; // El nuevo resto debe ser menor de 20 c�ntimos
            
            // Monedas de 10 c�ntimos (0 o 1)
            m010 = resto / 10;
            resto = resto % 10; // El nuevo resto debe ser menor de 10 c�ntimos
            
            // Monedas de 5 c�ntimos (0 o 1)
            m005 = resto / 5;
            resto = resto % 5; // El nuevo resto debe ser menor de 5 c�ntimos
            
            // Monedas de 2 c�ntimos (0,1 o 2)
            m002 = resto / 2;
            resto = resto % 2; // El nuevo resto debe ser menor de 2 c�ntimos

            // Monedas de 1 c�ntimo (0 o 1): lo que quede de resto
            m001 = resto;
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Monedas de  2 euros:    " + m2);
            System.out.println ("Monedas de  1 euros:    " + m1);
            System.out.println ("Monedas de 50 c�ntimos: " + m050);
            System.out.println ("Monedas de 20 c�ntimos: " + m020);
            System.out.println ("Monedas de 10 c�ntimos: " + m010);
            System.out.println ("Monedas de  5 c�ntimos: " + m005);
            System.out.println ("Monedas de  2 c�ntimos: " + m002);
            System.out.println ("Monedas de  1 c�ntimo : " + m001);
            //System.out.println ("Resto: " + resto);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}
