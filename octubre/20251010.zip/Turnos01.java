
package ejemplos2025;

/**
 * Programa TURNOS
 * El usuario introduce el d�a de incio del turno
 * La longitud de turnos es de 5 d�as y la de los descansos de 2 d�as.
 * @author diosdado
 */

import java.util.Scanner;


public class Turnos01 {
    
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int LONG_TURNO = 5;
            final int LONG_DESCANSO = 2;


            // Variables de entrada
            int diaInicioTurno;




            // Variables de salida
            int diaInicioDescanso;
            int diaInicioSigTurno;



            // Variables auxiliares
            
            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("TURNOS DE TRABAJO");
            System.out.println("-----------------");
            System.out.println("La longitud de los turno es de 5 d�as y la de los descansos de 2 d�as.");
            System.out.println("Introduzca el d�a de comienzo (0-6): ");
            diaInicioTurno = teclado.nextInt();
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            
            // C�lculo del d�a de inicio del descanso
            diaInicioDescanso = (diaInicioTurno + LONG_TURNO) % 7;
            
            // C�lculo del d�a de inicio del siguiente turno
            diaInicioSigTurno = (diaInicioDescanso + LONG_DESCANSO) % 7;



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("D�a de inicio del turno: " + diaInicioTurno);
            System.out.println ();

            System.out.println ("D�a de inicio del descanso: " + diaInicioDescanso );
            System.out.println ("D�a de inicio del siguiente turno: " + diaInicioSigTurno );


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

