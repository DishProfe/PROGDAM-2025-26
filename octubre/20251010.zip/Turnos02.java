
package ejemplos2025;

/**
 * Programa TURNOS
 * El usuario introduce el tama�o o longitud de los turnos (n�mero de d�as) junto con el d�a de incio del turno
 * La longitud del descanso (n�mero de d�as) se calcula como 1 d�a de descanso por cada dos de trabajo, sin contar las fracciones.
 * @author diosdado
 */

import java.util.Scanner;


public class Turnos02 {
    
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int longTurno;
            int diaInicioTurno;




            // Variables de salida
            int diaInicioDescanso;
            int diaInicioSigTurno;



            // Variables auxiliares
            int longDescanso;
            
            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("TURNOS DE TRABAJO");
            System.out.println("-----------------");
            System.out.println("Introduzca el tama�o de los turnos (n�mero de d�as): ");
            longTurno = teclado.nextInt();
            System.out.println("Introduzca el d�a de comienzo (0-6): ");
            diaInicioTurno = teclado.nextInt();
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // C�lculo del n�mero de d�as de descanso
            longDescanso = longTurno / 2;
            
            // C�lculo del d�a de inicio del descanso
            diaInicioDescanso = (diaInicioTurno + longTurno) % 7;
            
            // C�lculo del d�a de inicio del siguiente turno
            diaInicioSigTurno = (diaInicioDescanso + longDescanso) % 7;



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Longitud de los turnos: " + longTurno + " d�as");
            System.out.println ("D�a de inicio del turno: " + diaInicioTurno);
            System.out.println ();

            System.out.println ("Longitud del descanso: " + longDescanso + " d�as");
            System.out.println ("D�a de inicio del descanso: " + diaInicioDescanso );
            System.out.println ("D�a de inicio del siguiente turno: " + diaInicioSigTurno );


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

