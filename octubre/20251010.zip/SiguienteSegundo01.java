
package ejemplos2025;

/**
 * Programa para calcular el siguiente segundo de un hora hh:mm:ss
 * @author diosdado
 */

import ejemplos2025.resueltos.*;
import java.util.Scanner;


public class SiguienteSegundo01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int hora, minuto, segundo;



            // Variables de salida
            int shor, smin, sseg;


            // Variables auxiliares
            int minExtra, horExtra;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO DEL SIGUIENTE SEGUNDO A UNA HORA");
            System.out.println("----------------------------------------");
            System.out.println("Introduzca hora, minuto y segundo:");
            hora = teclado.nextInt();
            minuto = teclado.nextInt();
            segundo = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            
            
            // Siguiente segundo: si se pasa de 59 debe volver a 00
            sseg = (segundo + 1) % 60;
            
            // Posible minuto extra: 0 o 1 (si el segundo ha pasado de 59 a 00)
            minExtra = (segundo + 1) / 60;
            
            // Siguiente minuto: el minuto anterior m�s un posible minuto extra
            // Si se pasa de 59 debe volver a 00
            smin = ( minuto + minExtra ) % 60;
            
            // Posible hora extra:0 o 1 (si el minuto ha pasado de 59 a 00)
            horExtra = (minuto + minExtra) / 60;

            // Siguiente hora: la hora anterior m�s una posible hora extra
            // Si se pasa de 23 debe volver a 00
            shor = (hora + horExtra) % 24;


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Siguiente segundo:");
            System.out.println ("Hora: " + shor + ":" + smin + ":" + sseg);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

