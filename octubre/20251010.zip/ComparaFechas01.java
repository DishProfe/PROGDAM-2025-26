
package ejemplos2025;

/**
 * Programa Comparador de Fechas
 * @author diosdado
 */

import ejemplos2025.resueltos.*;
import java.util.Scanner;


public class ComparaFechas01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int dia1, mes1, year1;
            int dia2, mes2, year2;



            // Variables de salida
            boolean fechasIguales;
            boolean fecha1MasModerna;
            boolean fechasMismaDecada;
            boolean fecha1MasCercanaFinDecada;
            



            // Variables auxiliares
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPARACI�N DE FECHAS");
            System.out.println("---------------------");

            System.out.println("Introduzca fecha1 (d�a, mes, a�o)");
            dia1 = teclado.nextInt();
            mes1 = teclado.nextInt();
            year1 = teclado.nextInt();

            System.out.println("Introduzca fecha2 (d�a, mes, a�o)");
            dia2 = teclado.nextInt();
            mes2 = teclado.nextInt();
            year2 = teclado.nextInt();


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Las fechas son iguales si coinciden d�a, mes y a�o
            fechasIguales = dia1==dia2 && mes1==mes2 && year1==year2;

            // Fecha m�s moderna
            fecha1MasModerna = year1>year2 || ( year1 == year2 && mes1>mes2 ) || ( year1==year2 && mes1==mes2 && dia1>dia2 ) ;

            // Misma d�cada 
            fechasMismaDecada = year1/10 == year2/10; 
                       
            // Fecha m�s cercana al final de su d�cada
            fecha1MasCercanaFinDecada = year1%10 > year2%10 || year1%10 == year2%10 && mes1>mes2 || year1%10 == year2%10 && mes1==mes2 && dia1>dia2 ;
            
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("1.   Las fechas son iguales: " + fechasIguales);
            System.out.println ("2.1. La fecha m�s moderna es: " + (fecha1MasModerna ? dia1 + "/" + mes1 + "/" + year1 : dia2 + "/" + mes2 + "/" + year2) );
            System.out.println ("2.2. Las fechas pertenecen a la misma d�cada: " + fechasMismaDecada);
            System.out.println ("2.3. La fecha m�s cercana al fin de su d�cada es: " + (fecha1MasCercanaFinDecada ? dia1 + "/" + mes1 + "/" + year1 : dia2 + "/" + mes2 + "/" + year2) );


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}