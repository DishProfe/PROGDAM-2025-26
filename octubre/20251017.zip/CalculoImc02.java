
package ejemplos2025;

/**
 * Programa C�lculo del IMC
 * @author diosdado
 */

import java.util.Scanner;


public class CalculoImc02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            double peso, altura;




            // Variables de salida
            double imc;
            String textoIMC;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO DEL IMC");
            System.out.println("---------------");

            System.out.println("Introduzca peso (Kg) :");
            peso = teclado.nextDouble();

            System.out.println("Introduzca altura (m) :");
            altura = teclado.nextDouble();


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            imc = peso /  Math.pow (altura, 2) ;

            if ( imc < 18.5 ) {
                textoIMC = "Peso bajo";
            } else if ( imc < 25.0 )  {
                textoIMC = "Normopeso";
            } else if ( imc < 30.0 )  {
                textoIMC = "Sobrepeso";
            } else {
                textoIMC = "Obesidad";
            }            


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El IMC es: " + imc);
                System.out.println (textoIMC);


            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

