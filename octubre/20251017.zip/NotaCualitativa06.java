
package ejemplos2025;

/**
 * Programa para obtener una nota cualitativa a partir de una cuantitativa (0,00-10,00)
 * @author diosdado
 */

import java.util.Scanner;


public class NotaCualitativa06 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            double nota;




            // Variables de salida
            String notaCualitativa;



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CONVERSI�N DE NOTA CUANTITATIVA A NOTA CUALIATIVA");
            System.out.println("--------------------------------------------------");
            System.out.println("Introduzca nota (0.00-10.00)");
            nota = teclado.nextDouble();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            
/*
            notaCualitativa = nota < 5.0 ? "NO APTO" : 
                    ( nota < 7 ? "APROBADO" : 
                    ( nota < 9 ? "NOTABLE" : "SOBRESALIENTE" )  ) ;
*/

            if ( nota < 5.0 ) {    
                notaCualitativa = "NO APTO"; 
            } else {
                if  ( nota < 7 ) {
                    notaCualitativa = "APROBADO"; 
                } else {
                    if ( nota < 9) {
                        notaCualitativa = "NOTABLE";
                    } else {
                        notaCualitativa = "SOBRESALIENTE";
                    }                     
                }
            }


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ( notaCualitativa );

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

