
package ejemplos2025;

/**
 * Programa que reciba desde teclado dos n�meros enteros: uno de cinco 
 * cifras y uno de una cifra (es decir, una cifra entre 0 y 9). El programa debe 
 * calcular cuantas veces aparece esa cifra en el n�mero de cinco cifras.
 * @author diosdado
 */

import java.util.Scanner;


public class Cifras01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;
            int cifra;

            // Variables de salida
            int numVeces;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO DEL N�MERO DE VECES QUE EST� UNA CIFRA EN UN N�MERO");
            System.out.println("-----------------------------------------------------------");

            System.out.println("Introduzca n�mero de cinco cifras: ");
            numero = teclado.nextInt ();

            System.out.println("Introduzca cifra: ");
            cifra = teclado.nextInt ();
            
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}