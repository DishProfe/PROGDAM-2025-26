
package ejemplos2025;

/**
 * Programa C�lculo del n�mero de d�as de  un mes
 * @author diosdado
 */

import java.util.Scanner;


public class NumDiasMes02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int mes, year;




            // Variables de salida
            int numDiasMes;



            // Variables auxiliares
            boolean yearBisiesto;
            int diaBisiesto;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO DEL N�MERO DE D�AS DE UN MES");
            System.out.println("------------------------------------");
            System.out.println("Introduzca mes y a�o");
            mes = teclado.nextInt();
            year= teclado.nextInt();
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Calculamos si el a�o es o no bisiesto
            yearBisiesto = (year % 400 == 0) || (year % 4 == 0 && year % 100 != 0);
//            diaBisiesto = yearBisiesto ? 1 : 0; // D�a que sumamos si fuera a�o bisiesto
//            
//            // Calculamos los d�as del mes
//            numDiasMes = mes==4 || mes==6 || mes==9 || mes==11 
//                    ? 30 : ( mes==2 ? 28 + diaBisiesto : 31 ); 
            
//            if ( mes==4 || mes==6 || mes==9 || mes==11 ) {
//                numDiasMes = 30;
//            } else if (  mes==2 ) {
//                if (yearBisiesto) {
//                    numDiasMes = 29;
//                } else {
//                    numDiasMes = 28;
//                }                
//            } else {
//                numDiasMes = 31;
//            }
//            
            switch ( mes ) {
                
                case 1:
                    numDiasMes = 31;
                    break;

                case 2:
                    if (yearBisiesto) {
                        numDiasMes = 29;
                    } else {
                        numDiasMes = 28;
                    }                
                    break;

                case 3:
                    numDiasMes = 31;                    
                    break;

                case 4:
                    numDiasMes = 30;                    
                    break;
                    
                case 5:
                    numDiasMes = 31;                    
                    break;

                case 6:
                    numDiasMes = 30;                    
                    break;

                case 7:
                    numDiasMes = 31;                    
                    break;

                case 8:
                    numDiasMes = 31;                    
                    break;

                case 9:
                    numDiasMes = 30;                    
                    break;

                case 10:
                    numDiasMes = 31;                    
                    break;

                case 11:
                    numDiasMes = 30;                    
                    break;

                default:
                    numDiasMes = 31;                    

            }


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El mes " + mes + " de " + year + 
                    " tiene " + numDiasMes + " d�as");

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}