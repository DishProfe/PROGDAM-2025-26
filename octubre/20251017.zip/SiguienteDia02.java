
package ejemplos2025;

/**
 * Programa para calcular el siguiente d�a de una fecha
 * @author diosdado
 */

import java.util.Scanner;


public class SiguienteDia02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int dia, mes, year;




            // Variables de salida
            int sigDia, sigMes, sigYear;


            // Variables auxiliares
            boolean yearBisiesto;
            int diaBisiesto;
            int numDiasMes;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO DEL SIGUIENTE D�A");
            System.out.println("-------------------------");
            System.out.println("Introduzca d�a, mes y a�o:");
            dia = teclado.nextInt();
            mes = teclado.nextInt();
            year = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Calculamos si el a�o es o no bisiesto
            yearBisiesto = (year % 400 == 0) || (year % 4 == 0 && year % 100 != 0);
            diaBisiesto = yearBisiesto ? 1 : 0; // D�a que sumamos si fuera a�o bisiesto
            
            // Calculamos los d�as del mes
//            numDiasMes = mes==4 || mes==6 || mes==9 || mes==11 
//                    ? 30 : ( mes==2 ? 28 + diaBisiesto : 31 ); 
            

            if  ( mes==4 || mes==6 || mes==9 || mes==11 ) {
                numDiasMes = 30;
            } else if ( mes ==2 ) {
                if ( yearBisiesto) 
                    numDiasMes = 29;
                else
                    numDiasMes = 28;
            }
            else {
                    numDiasMes = 31;                    
            }
            
            
            // Calculamos el siguiente d�a teniendo en cuenta que el �ltimo d�a es numDiasMes
            sigDia = 1 + dia%numDiasMes;
            // Otra forma: sigDia = (dia + 1)>numDiasMes ? 1 : dia+1 ;
            
            // Si pasamos a dia 1, incrementamos el mes             
            // Pero teniendo en cuenta que el �ltimo mes es 12. Si superamos 12, pasamos a 1
            //sigMes = (sigDia == 1) ? 1 + mes%12 : mes ;
            
            sigMes = mes;
            if ( sigDia == 1 ) {
                sigMes = 1 + mes%12;
            } 

            
            // Si hemos decrementado el mes (hemos pasado de 12 a 1), es que hemos pasado de a�o: incrementamos el a�o
            //sigYear = sigMes < mes ? year+1 : year;

            // Otra forma (Hugo): si pasamos a mes 1 y d�a 1 es porque hemos cambiado de a�o
            //sigYear = (sigDia==1 && sigMes==1) ? year+1 : year;

            sigYear = year;
            if ( sigDia==1 && sigMes==1 ) {
                sigYear++;
            } 
            
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El siguiente d�a para la fecha " + dia + "/" + mes + "/" + year + " es: ");
            System.out.println (sigDia + "/" + sigMes + "/" + sigYear);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

