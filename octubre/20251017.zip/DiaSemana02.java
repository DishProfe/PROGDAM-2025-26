
package ejemplos2025;

/**
 * Programa Para convertir n�mero (1-7) en texto ("lunes" a "domingo")
 * @author diosdado
 */

import java.util.Scanner;


public class DiaSemana02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numDiaSemana;




            // Variables de salida
            String textoDiaSemana;



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("D�A DE LA SEMANA DE N�MERO A TEXTO");
            System.out.println("----------------------------------");
            System.out.println("Introduzca un n�mero que representa d�a de la semana (1-7)");
            numDiaSemana = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

//            textoDiaSemana = 
//                    numDiaSemana == 1 ? "lunes" : 
//                    ( numDiaSemana == 2 ? "martes" : 
//                    ( numDiaSemana == 3 ? "mi�rcoles" : 
//                    ( numDiaSemana == 4 ? "jueves" : "otro") )  );


    //            if ( numDiaSemana == 1 ) {
    //                textoDiaSemana = "lunes";
    //            } else if ( numDiaSemana == 2 ) {
    //                textoDiaSemana = "martes";                 
    //            } else if ( numDiaSemana == 3 ) {
    //                textoDiaSemana = "mi�rcoles";                 
    //            } else if ( numDiaSemana == 4 ) {
    //                textoDiaSemana = "jueves";                 
    //            } else if ( numDiaSemana == 5 ) {
    //                textoDiaSemana = "viernes";                 
    //            } else if ( numDiaSemana == 6 ) {
    //                textoDiaSemana = "s�bado";                 
    //            } else {
    //                textoDiaSemana = "domingo";                 
    //            }
            
            switch ( numDiaSemana ) {
                
                case 1:
                    textoDiaSemana = "lunes";
                    break;
                    
                case 2: 
                    textoDiaSemana = "martes";                 
                    break;
                    
                case 3:
                    textoDiaSemana = "mi�rcoles";                 
                    break;
                    
                case 4:
                    textoDiaSemana = "jueves";                 
                    break;
                    
                case 5: 
                    textoDiaSemana = "viernes";                 
                    break;
                    
                case 6:
                    textoDiaSemana = "s�bado";                 
                    break;
                                       
                default:
                    textoDiaSemana = "domingo";                 
                    
            }
            
            
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El d�a de la semana es: " +  textoDiaSemana);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

