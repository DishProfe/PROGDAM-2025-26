
package ejemplos2025;

/**
 * Programa Segundos transcurridos
 * @author diosdado
 */

import java.util.Scanner;


public class SegundosTranscurridos {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int hora;
            int minuto;
            int segundo;




            // Variables de salida
            int segundosTranscurridos;



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("SEGUNDOS TRANSCURRIDOS DESDE MEDIANOCHE");
            System.out.println("---------------------------------------");
            System.out.println("Introduzca hora: ");
            hora = teclado.nextInt();
            System.out.println("Introduzca minuto: ");
            minuto = teclado.nextInt();
            System.out.println("Introduzca segundo: ");
            segundo = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            
            segundosTranscurridos = hora*3600 + minuto*60 + segundo;
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Segundos transcurridos desde media noche " + 
                    segundosTranscurridos);
            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}
