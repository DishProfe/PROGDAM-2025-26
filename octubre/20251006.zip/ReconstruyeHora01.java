
package ejemplos2025;

/**
 * Programa para construir una hora a partir del n�mero de segundos transcurridos desde medianoche
 * @author diosdado
 */

import java.util.Scanner;


public class ReconstruyeHora01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numSegundos;



            // Variables de salida
            int hora, minuto, segundo;


            // Variables auxiliares
            int resto;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("RECONSTRUCCI�N DE HORA A PARTIR DEL N�MERO DE SEGUNDOS TRANSCURRIDOS DESDE MEDIANOCHE");
            System.out.println("-------------------------------------------------------------------------------------");
            System.out.println("Introduzca n�mero de segundos transcurridos desde medianoche:");
            numSegundos = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Por cada bloque de 3600 segundos tendremos una hora
            hora = numSegundos / 3600 ;
            
            // El resto ser�n minutos y segundos
            resto = numSegundos % 3600;
            
            // De lo que quede, por cada bloque de 60 segundos tendremos un minuto
            minuto = resto / 60;
            
            // El resto ser�n los segundos que no llegan a hacer un minuto (<60)
            segundo = resto % 60;



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Segundos transcurridos desde medianoche (00:00:00): " + 
                    numSegundos);
            System.out.println ("Hora: " + hora + ":" + minuto + ":" + segundo);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

