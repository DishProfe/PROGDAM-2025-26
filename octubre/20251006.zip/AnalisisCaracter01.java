
package ejemplos2025;

/**
 * Programa para convertir un car�cter de may�scula a min�scula
 * @author diosdado
 */

import java.util.Scanner;


public class AnalisisCaracter01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            char caracter;




            // Variables de salida
            int codigo;
            boolean esMayuscula, esMinuscula, esLetra, esDigito, esAlfanumerico;
            boolean esVocalMay, esVocalMin, esVocal, esConsonante;
            boolean esComilla, esParentesis;
            
            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CONVERTIR DE MAY�SCULA A MIN�SCULA");
            System.out.println("AN�LISIS DE UN CAR�CTER A PARTIR DE SU C�DIGO");
            System.out.println("---------------------------------------------");
            System.out.println("Introduzca un car�cter");
            caracter = teclado.nextLine().charAt(0);

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Obtenemos el c�digo
            codigo = (int) caracter;
            
            // Comprobamos si es may�scula (rango A-Z)
            esMayuscula = caracter>='A' && caracter<='Z';

            // Comprobamos si es min�scula (rango a-z)            
            esMinuscula = caracter>='a' && caracter<='z';
            
            // Comprobamos si es una letra
            esLetra = esMayuscula || esMinuscula ;

            // Comprobamos si es un d�gito
            esDigito = caracter>='0' && caracter<='9';

            // Comprobamos si es un alfanum�rico
            esAlfanumerico = esLetra || esDigito;
            
            // Comprobamos si es una vocal min�scula
            esVocalMin = caracter=='a' || caracter=='e' || caracter=='i' || caracter=='o' || caracter=='u' ;
            
            // Comprobamos si es una vocal may�scula
            esVocalMay = caracter=='A' || caracter=='E' || caracter=='I' || caracter=='O' || caracter=='U' ;
            
            // Comprobamos si es una vocal
            esVocal = esVocalMin || esVocalMay;
            
            // Comprobamos si es una consonante
            esConsonante = esLetra && !esVocal;
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El c�digo de '" + caracter + "' es " + codigo);
            System.out.println ();
            System.out.println ("El car�cter es may�scula: " + esMayuscula );
            System.out.println ("El car�cter es min�scula: " + esMinuscula );
            System.out.println ("El car�cter es una letra: " + esLetra );
            System.out.println ("El car�cter es un d�gito: " + esDigito );
            System.out.println ("El car�cter es alfanum�rico: " + esAlfanumerico );
            System.out.println ();
            System.out.println ("El car�cter es una vocal may�scula: " + esVocalMay );
            System.out.println ("El car�cter es una vocal min�scula: " + esVocalMin );
            System.out.println ("El car�cter es una vocal: " + esVocal );
            System.out.println ("El car�cter es una consontante: " + esConsonante );


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

