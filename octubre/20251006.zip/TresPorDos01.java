
package ejemplos2025;

/**
 * Programa Oferta de 3x2
 * @author diosdado
 */

import java.util.Scanner;


public class TresPorDos01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            double precio;
            int unidades;




            // Variables de salida
            double precioFinal;



            // Variables auxiliares
            int bloques3Unidades;
            int resto;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("OFERTA DE 3X2");
            System.out.println("-------------");
            System.out.println("Introduzca precio del producto (euros): ");
            precio = teclado.nextDouble();
            System.out.println("Introduzca n�mero de unidades: ");
            unidades = teclado.nextInt();


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            // Calculamos el n�mero de bloques de tres unidades (cada bloque de tres valdr� dos veces el precio)
            bloques3Unidades= unidades / 3;
            
            // Calculamos lo que sobra (0,1 o 2 unidades)
            resto = unidades % 3;
            
            precioFinal = bloques3Unidades * 2 * precio + resto * precio;





            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El importe final ser�: " + precioFinal + " euros");


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

