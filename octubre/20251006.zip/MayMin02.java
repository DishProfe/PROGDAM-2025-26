
package ejemplos2025;

/**
 * Programa para convertir un car�cter de may�scula a min�scula
 * @author diosdado
 */

import java.util.Scanner;


public class MayMin02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int DIF_MAY_MIN = 'a' - 'A';


            // Variables de entrada
            char caracter;




            // Variables de salida
            char minuscula;
            char mayuscula;



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CONVERTIR DE MAY�SCULA A MIN�SCULA");
            System.out.println("-----------------------");
            System.out.println("Introduzca car�cter: ");

            caracter = teclado.nextLine().charAt(0);

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            
            // Solamente se lleva a cabo la conversi�n si el car�cter est� en el rango A-Z
            // La conversi�n consiste en sumar la diferencia DIF_MAY_MIN al caracter
            minuscula = caracter>='A' && caracter<='Z' ? (char) (caracter + DIF_MAY_MIN) : caracter  ;

            // Solamente se lleva a cabo la conversi�n si el car�cter est� en el rango a-z
            // La conversi�n consiste en restar la diferencia DIF_MAY_MIN al caracter
            mayuscula = caracter>='a' && caracter<='z' ? (char) (caracter - DIF_MAY_MIN) : caracter ; 
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El car�cter '" + caracter + " ' en min�scula es '" + minuscula + "'");
            System.out.println ("El car�cter '" + caracter + " ' en may�scula es '" + mayuscula + "'");


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

