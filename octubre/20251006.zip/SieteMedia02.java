
package ejemplos2025;

/**
 * Programa Siete y Media
 * @author diosdado
 */

import java.util.Scanner;


public class SieteMedia02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int naipe1, naipe2, naipe3;




            // Variables de salida
            boolean esSieteMedia;
            double pasa;


            // Variables auxiliares
            double vn1, vn2, vn3;
            double suma;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("JUEGO DE LAS SIETE Y MEDIA");
            System.out.println("--------------------------");
            System.out.println("Introduzca el valor de tres naipes (1-7, 10-12): ");
            naipe1 = teclado.nextInt();
            naipe2 = teclado.nextInt();
            naipe3 = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            vn1 = naipe1>=1 && naipe1<=7 ? naipe1 : 0.5 ;
            vn2 = naipe2>=1 && naipe2<=7 ? naipe2 : 0.5 ;
            vn3 = naipe3>=1 && naipe3<=7 ? naipe3 : 0.5 ;
            
            suma = vn1 + vn2 + vn3;
            
            pasa = suma - 7.5;
            esSieteMedia = suma==7.5;

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("La suma vale: " + suma);
            System.out.println ("Suman siete y medio: " + (esSieteMedia ? "s�" : "no") ) ;
            System.out.print ( (pasa>0 ? "Se pasa por: " + pasa + "\n" : ""));
            System.out.print ( (pasa<0 ? "No llega por: " + (-pasa) + "\n" : ""));
                


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

