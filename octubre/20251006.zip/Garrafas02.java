
package ejemplos2025;

/**
 * Programa Garrafas de agua
 * @author diosdado
 */

import java.util.Scanner;


public class Garrafas02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            double litros;


            // Variables de salida
            int numGarrafas1L, numGarrafas2L, numGarrafas5L;


            // Variables auxiliares
            int resto;
            int litrosEntero;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO M�NIMO DE GARRAFAS");
            System.out.println("--------------------------");
            System.out.println("Introduzca la cantidad de litros (n�mero entero):");
            litros = teclado.nextDouble();


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            
            
            litrosEntero = (int) Math.ceil (litros) ;

            // C�lculo de garrafas de 5 litros: tantas como se pueda (cociente)
            numGarrafas5L = litrosEntero / 5;

            // Lo que sobre (resto) debe ser menor de 5
            resto = litrosEntero % 5;
            
            // Calculo de garrafas de 2 litros (0, 1 o 2): tantas como se pueda (cociente)
            numGarrafas2L = resto / 2;
            
            // Lo que sobre (resto) debe ser menor que 2
            // Ese resto ser� el n�mero de garrafas de un litro (0 o 1)
            numGarrafas1L = resto % 2;



            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Para poder transportar esa cantidad ser�an necesarias: ");
            System.out.println ("Garrafas de 5 litros: " + numGarrafas5L);
            System.out.println ("Garrafas de 2 litros: " + numGarrafas2L);
            System.out.println ("Garrafas de 1 litro : " + numGarrafas1L);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

