
package ejemplos2025;

/**
 * Programa para convertir un car�cter de may�scula a min�scula
 * @author diosdado
 */

import java.util.Scanner;


public class MayMin01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int DIF_MAY_MIN = 'a' - 'A';


            // Variables de entrada
            char caracter;




            // Variables de salida
            char minuscula;



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CONVERTIR DE MAY�SCULA A MIN�SCULA");
            System.out.println("-----------------------");
            System.out.println("Introduzca car�cter: ");

            caracter = teclado.nextLine().charAt(0);

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // La conversi�n consiste en sumar la diferencia DIF_MAY_MIN al caracter
            minuscula = (char) (caracter + DIF_MAY_MIN);

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El car�cter '" + caracter + " ' en min�scula es '" + minuscula + "'");


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

