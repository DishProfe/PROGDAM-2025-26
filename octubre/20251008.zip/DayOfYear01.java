
package ejemplos2025;

/**
 * Programa para calcular el d�a del a�o (d�as transcurridos desde del comienzo del a�o)
 * @author diosdado
 */

import java.util.Scanner;


public class DayOfYear01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int dia, mes, year;



            // Variables de salida
            int diaYear;


            // Variables auxiliares
            int diasAcumulados;
            boolean esBisiesto;
            int diaBisiesto;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO DEL D�A DEL A�O");
            System.out.println("-----------------------");
            System.out.println("Introduzca fecha: dia, mes, a�o");
            dia = teclado.nextInt();
            mes = teclado.nextInt();
            year = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Comprobamos si el a�o es bisiesto o no
            esBisiesto = (year % 400 == 0) || ( year % 4 == 0 && year % 100 != 0);
            diaBisiesto = esBisiesto ? 1 : 0; // D�a a sumar si es biesto

            diasAcumulados = 
                    ( mes> 1 ? 31 : 0) + // Si estamos "m�s all� de enero" (mes>1), se suman los 31 d�as de enero
                    ( mes> 2 ? 28+diaBisiesto : 0) + // Si estamos "m�s all� de febrero" (mes>2), se suman los 28/29 d�as de febrero
                    ( mes> 3 ? 31 : 0) +
                    ( mes> 4 ? 30 : 0) +
                    ( mes> 5 ? 31 : 0) +
                    ( mes> 6 ? 30 : 0) +
                    ( mes> 7 ? 31 : 0) +
                    ( mes> 8 ? 31 : 0) +
                    ( mes> 9 ? 30 : 0) +
                    ( mes>10 ? 31 : 0) +
                    ( mes>11 ? 30 : 0) ; // Si estamos "m�s all� de noviembre" (es decir, diciembre), se suman los 31 d�as de diciembre

            // Sumamos los d�as acumulados hasta el mes anterior al actual al d�a de mes actual
            diaYear= diasAcumulados + dia;
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El d�a en el a�o para la fecha " + 
                    dia + "/" + mes + "/" + year + " es: " + diaYear);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}