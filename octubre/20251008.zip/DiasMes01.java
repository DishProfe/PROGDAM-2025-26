
package ejemplos2025;

/**
 * Programa para calcular el n�mero de d�as que tiene un mes
 * @author diosdado
 */

import java.util.Scanner;


public class DiasMes01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int mes;
            int year;




            // Variables de salida
            int numDias;



            // Variables auxiliares
            boolean esBisiesto;
            int diaBisiesto;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("D�AS EN UN MES");
            System.out.println("--------------");
            System.out.println("Introduzca mes y a�o: ");
            mes = teclado.nextInt();
            year = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            esBisiesto = (year % 400 == 0) || ( year % 4 == 0 && year % 100 != 0);
            diaBisiesto = esBisiesto ? 1 : 0;
            
            
            numDias = mes==4 || mes==6 || mes==9 || mes==11 ? 30 :
                    ( mes==2 ? 28+diaBisiesto : 31 )  ;



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El mes " + mes +" del a�o " + year + " tiene " +
                    numDias + " dias");
            


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}