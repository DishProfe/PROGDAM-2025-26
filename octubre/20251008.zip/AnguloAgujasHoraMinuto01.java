
package ejemplos2025;

/**
 * Programa C�lculo del �ngulo entre la aguja de hora y la aguja de minuto
 * @author diosdado
 */

import java.util.Scanner;


public class AnguloAgujasHoraMinuto01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int ANCHURA_HORA = 360 / 12 ; // La "anchura" de una hora es 360/12=30 grados 
            final int ANCHURA_MIN = 360 / 60; // La "anchura" de un minuto es de 6 grados

            // Variables de entrada
            int hora, minuto;


            // Variables de salida
            double angulo;


            // Variables auxiliares
            int posHora, posMinuto;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO DEL �NGULO ENTRE AGUJAS DE HORA Y MINUTO");
            System.out.println("------------------------------------------------");
            System.out.println("Introduzca hora y minuto (12h): ");
            hora = teclado.nextInt();
            minuto = teclado.nextInt();
            
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Si las hora son las 12, la pasamos a 0. En el resto de casos (1-11) queda igual
            posHora = hora; //% 12 ;

            // Hacemos lo mismo con los minutos
            posMinuto = minuto;
            
            // Posici�n de la aguja hora: pasamos al rango 0-360
            posHora = posHora * ANCHURA_HORA;
            
            // Posici�n de la aguja minuto: pasamos al rango 0-360
            posMinuto = posMinuto * ANCHURA_MIN;

            angulo = Math.abs (posHora - posMinuto);

            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El �ngulo entre las dos agujas es: " +
                    angulo + " grados");

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}