
package ejemplos2025;

/**
 * Programa M�quina de cambio
 * @author diosdado
 */

import java.util.Scanner;


public class Monedas01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int m2, m1, m050, m020, m010, m005, m002, m001;


            // Variables de salida
            double euros;


            // Variables auxiliares
            double centimos;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("MONEDAS");
            System.out.println("-------");
            System.out.println("Introduzca cantidad de monedas de 2, 1, 0.50, 0.20, 0.10, 0.05, 0.02, 0.01 euros: ");
            m2   = teclado.nextInt();
            m1   = teclado.nextInt();
            m050 = teclado.nextInt();
            m020 = teclado.nextInt();
            m010 = teclado.nextInt();
            m005 = teclado.nextInt();
            m002 = teclado.nextInt();
            m001 = teclado.nextInt();
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            
            // Sumamos las monedas de c�ntimo multiplic�ndolas por su valor
            centimos = 0.50*m050 + 0.20*m020 + 0.10*m010 + 0.05*m005 + 0.02*m002 + 0.01*m001;
                       
            // A�adimos las monedas de euros enteros (monedas de 1 y 2 euros) multiplic�ndolas por su valor
            euros = 2*m2 + m1 + centimos;
            

            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Cantidad de euros: " + euros);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}
