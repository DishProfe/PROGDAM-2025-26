
package ejemplos2025;

/**
 * Programa para calcular el n�mero de d�as que tiene un mes
 * @author diosdado
 */

import java.util.Scanner;


public class DiasMes02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int NUM_DIAS_FEB = 28;
            final int NUM_DIAS_ENE_DIC = 31;
            final int NUM_DIAS_ABR_JUN = 30;
            

            // Variables de entrada
            int mes;
            int year;




            // Variables de salida
            int numDias;



            // Variables auxiliares
            //boolean esBisiesto;
            int diaBisiesto;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("D�AS EN UN MES");
            System.out.println("--------------");
            System.out.println("Introduzca mes y a�o: ");
            mes = teclado.nextInt();
            year = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            //esBisiesto = (year % 400 == 0) || ( year % 4 == 0 && year % 100 != 0);
            //diaBisiesto = esBisiesto ? 1 : 0;

            // Posible d�a "extra" que se suma si el a�o es bisiesto
            diaBisiesto = 0;
            if ( (year % 400 == 0) || ( year % 4 == 0 && year % 100 != 0) ) {
                diaBisiesto++;
            } 

            //numDias = mes==4 || mes==6 || mes==9 || mes==11 ? 30 :
            //        ( mes==2 ? 28+diaBisiesto : 31 )  ;
            
            // Comprobaci�n de meses de 30 d�as
            if ( mes==4 || mes==6 || mes==9 || mes==11 ) {
                numDias = 30;
            } else {
                // Comprobaci�n de febrero (28+(0/1))
                if ( mes==2 ) {
                    // Si el mes es febrero (2) es 28 + posible d�a extra de bisiesto
                    numDias = 28 + diaBisiesto;
                } else {
                    // Si no es de 30 y no es febrero, es de 31
                    numDias = 31;
                }
            }
            


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El mes " + mes +" del a�o " + year + " tiene " +
                    numDias + " dias");
            


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}