
package ejemplos2025;

/**
 * Programa Juego de domin�
 * @author diosdado
 */

import java.util.Scanner;


public class Domino02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int a1, a2, b1, b2, m1, m2;




            // Variables de salida
            boolean emparejaFicha;



            // Variables auxiliares
            boolean emparejaAM;
            boolean emparejaBM;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("FICHAS DE DOMIN�");
            System.out.println("----------------");

            System.out.println("Introduzca los valores de la ficha A (0-6)");
            a1 = teclado.nextInt();
            a2 = teclado.nextInt();

            System.out.println("Introduzca los valores de la ficha B (0-6)");
            b1 = teclado.nextInt();
            b2 = teclado.nextInt();

            System.out.println("Introduzca los valores de la ficha M (0-6)");
            m1 = teclado.nextInt();
            m2 = teclado.nextInt();
            
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            //emparejaAM = a1==m1 || a1==m2 || a2==m1 || a2==m2;

            emparejaAM = false;
            if ( a1==m1 || a1==m2 || a2==m1 || a2==m2 ) {
                emparejaAM = true;
            } 
            
            //emparejaBM = b1==m1 || b1==m2 || b2==m1 || b2==m2;
            if ( b1==m1 || b1==m2 || b2==m1 || b2==m2 ) {
                emparejaBM = true;
            } else {
                emparejaBM = false;
            }

            // emparejaFicha = emparejaAM || emparejaBM;            
            if ( emparejaAM || emparejaBM ) {
                emparejaFicha = true;
            } else {
                emparejaFicha = false;
            }
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Puedo soltar alguna ficha: " + (emparejaFicha ? "s�" : "no") );

            //System.out.println (emparejaAM ? "Podr�a soltarse la ficha A" : "" );
            if  ( emparejaAM ) {
                System.out.println ("Podr�a soltarse la ficha A");            
            }

            //System.out.println (emparejaBM ? "Podr�a soltarse la ficha B" : "" );
            if  ( emparejaBM ) {
                System.out.println ("Podr�a soltarse la ficha B");            
            }
            


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}