
package ejemplos2025;

/**
 * Programa Impresora a doble cara
 * @author diosdado
 */

import java.util.Scanner;


public class Impresora01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numPaginas;



            // Variables de salida
            int numHojasDobleCara;
            boolean ultimaPaginaBlanco;
            int totalPaginas;


            // Variables auxiliares


            // Clase Scanner para petici?n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("IMPRESOSA A DOBLE CARA");
            System.out.println("----------------------");
            System.out.println("Introduzca n�mero de p�ginas a imprimir");
            numPaginas = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            numHojasDobleCara = numPaginas / 2 + numPaginas % 2; 

            //ultimaPaginaBlanco = numPaginas % 2 == 1;
            ultimaPaginaBlanco = false;
            if ( numPaginas % 2 == 1 ) {
                ultimaPaginaBlanco = true;
            } 
            

            totalPaginas = numPaginas;

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("N�mero de hojas impresas a doble cara: " + numHojasDobleCara);
            //System.out.println ("�ltima p�gina en blanco: " + (ultimaPaginaBlanco ? "S�" : "No") );
            if ( ultimaPaginaBlanco) {
                System.out.println ("La �ltima p�gina est� en blanco");
            } else {
                System.out.println ("La �ltima p�gina no est� en blanco");                
            }
            System.out.println ("Total de p�ginas: " + totalPaginas);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

