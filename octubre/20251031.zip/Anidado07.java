
package ejemplos2025;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class Anidado07 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numLineas;
            int numColumnas;



            // Variables de salida



            // Variables auxiliares
            int fila;
            int columna;
            int contador;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("TABLA DE N�MEROS");
            System.out.println("----------------");

            System.out.println("Introduzca n�mero de l�neas: ");
            numLineas = teclado.nextInt();

            System.out.println("Introduzca n�mero de columnas: ");
            numColumnas = teclado.nextInt();
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------




            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");

            // Iniciamos contador
            contador = 1;
            
            // Vamos generando cada fila
            for ( fila = 1 ; fila<=numLineas ; fila++ ) {
                // Para cada fila escribimos su n�mero de fila y el car�cter ":"
                System.out.print (fila + ":");

                // Dentro de cada fila vamos generando las 11 columnas
                for ( columna = 1 ; columna <= numColumnas ; columna++  ) {
                    // Para cada columna escribimos su n�mero de columna
                    System.out.print ( " " + contador++ );
                }
                // Una vez escritas todas las columnas de la fila,
                // escribimos un avance de l�nea
                System.out.println ();
            }

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}