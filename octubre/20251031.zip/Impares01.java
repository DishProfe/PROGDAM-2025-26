
package ejemplos2025;

/**
 * Programa Procesamiento de datos de entrada
 * @author diosdado
 */

import java.util.Scanner;


public class Impares01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;



            // Variables de salida
            int cantidadImpares;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //      Entrada de datos + Procesamiento 
            //----------------------------------------------
            System.out.println("PROCESAMIENTO DE DATOS");
            System.out.println("----------------------");

            
            // Inicializamos contadores
            cantidadImpares = 0;
            
            do {
                // Vamos pidiendo n�meros hasta que se introduzca un negativo
                System.out.println("Introduzca n�mero entero: ");
                numero = teclado.nextInt();
                
                // Si el n�mero introducido es impar lo contabilizamos
                if ( numero % 2 != 0 && numero>=0) {
                    cantidadImpares++;
                }

            } while ( numero >= 0 );


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Cantidad de impares: " + cantidadImpares);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}