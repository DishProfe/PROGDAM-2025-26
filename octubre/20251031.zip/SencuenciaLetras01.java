
package ejemplos2025;

/**
 * Programa Generador de Secuencia de letras
 * @author diosdado
 */

import java.util.Scanner;


public class SencuenciaLetras01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            char letraInicial;
            char letraFinal;



            // Variables de salida
            String secuencia;


            // Variables auxiliares
            char contadorLetra;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("SECUENCIA DE LETRAS");
            System.out.println("-------------------");

            do {
                System.out.println("Introduzca primera letra:");
                letraInicial = teclado.nextLine().charAt(0);
            } while ( letraInicial<'A' || letraInicial>'Z');

            do {
                System.out.println("Introduzca �ltima letra (no puede ser menor que la primera):");
                letraFinal = teclado.nextLine().charAt(0);
            } while ( letraFinal<'A' || letraFinal>'Z' || letraFinal<letraInicial);
            


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Iniciamos el texto final de secuencia a un texto vac�o
            secuencia = "";
            
            // Vamos recorriendo desde la primera letra hasta la �ltima
            for ( contadorLetra= letraInicial  ; contadorLetra <= letraFinal ;  contadorLetra++ ) {
                secuencia = secuencia + contadorLetra;
            }



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println (secuencia);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}