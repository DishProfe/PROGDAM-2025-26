
package ejemplos2025;

/**
 * Programa Lista de nombres
 * @author diosdado
 */

import java.util.Scanner;


public class Nombres01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String nombre;



            // Variables de salida
            String listaNombres;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //        Entrada de datos + Procesamiento
            //----------------------------------------------
            System.out.println("LISTA DE NOMBRES");
            System.out.println("----------------");


            // Iniciamos acumulador a la cadena vac�a
            listaNombres = "";
            
            do {
                System.out.println("Introduzca nombre (escriba \"fin\" para terminar)");
                nombre = teclado.nextLine();
                
                if ( !nombre.equals("fin") ) {
                    if (listaNombres.length()>0) {
                        listaNombres += ", " + nombre;
                    } else {
                        listaNombres += nombre;
                    }
                }
                
            } while ( !nombre.equals("fin") );


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println (listaNombres);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}