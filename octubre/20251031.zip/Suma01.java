
package ejemplos2025;

/**
 * Programa que suma y contea
 * @author diosdado
 */

import java.util.Scanner;


public class Suma01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;



            // Variables de salida
            int suma;
            int numElementos;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //      Entrada de datos + Procesamiento 
            //----------------------------------------------
            System.out.println("SUMA Y CONTEO");
            System.out.println("-------------");

            // Inicializamos acumulador
            suma = 0;
            
            // Inicializamos contador
            numElementos = 0;
            
            do {
                // Vamos pidiendo n�meros hasta que se introduzca un negativo
                System.out.println("Introduzca n�mero entero: ");
                numero = teclado.nextInt();
                

                // Vamos acumulando (sumando) y contando los n�meros introducidos
                if ( numero >= 0 ) {
                    // Acumulamos
                    suma += numero;

                    // Y contamos
                    numElementos++;
                }

            } while ( numero >= 0 );



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("N�mero de elementos: " + numElementos);
            System.out.println ("Suma: " + suma);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}