
package ejemplos2025;

/**
 * Programa Procesamiento de datos de entrada
 * @author diosdado
 */

import java.util.Scanner;


public class EntradaNumeros01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            double numero;



            // Variables de salida
            double suma;



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //      Entrada de datos + Procesamiento 
            //----------------------------------------------
            System.out.println("PROCESAMIENTO DE DATOS");
            System.out.println("----------------------");

            // Valor inicial del acumulador
            suma = 0.0;
            
            do {
                // Vamos pidiendo n�meros hasta que se introduzca 0
                System.out.println("Introduzca n�mero: ");
                numero = teclado.nextDouble();

                // Vamos acumulando cada n�mero que se introduce
                suma += numero;
            } while ( numero != 0.0 );


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("La suma de los n�meros es: " + suma);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}