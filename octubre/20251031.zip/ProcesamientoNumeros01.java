
package ejemplos2025;

/**
 * Programa que analiza los n�meros introducidos
 * @author diosdado
 */

import java.util.Scanner;


public class ProcesamientoNumeros01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;



            // Variables de salida
            int numElementos;
            int numPares;
            int numImpares;
            int numPositivos;
            int numCeros;
            
            int suma;
            int producto;
            double media;

            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //      Entrada de datos + Procesamiento 
            //----------------------------------------------
            System.out.println("PROCESAMIENTO DE N�MEROS");
            System.out.println("------------------------");

            // Inicializamos acumuladores
            suma = 0;
            producto = 1;
            media = 0.0;
            
            // Inicializamos contadores
            numElementos = 0;
            numPares = 0;
            numImpares = 0;
            numPositivos = 0;
            numCeros = 0;
            
            do {
                // Vamos pidiendo n�meros hasta que se introduzca un negativo
                System.out.println("Introduzca n�mero entero: ");
                numero = teclado.nextInt();
                

                // Vamos acumulando (sumando) y contando los n�meros introducidos
                if ( numero >= 0 ) {

                    // Acumulamos
                    suma += numero;
                    producto *= numero;
                    
                    // Y contamos
                    numElementos++;
                    
                    // Contamos positivos y ceros
                    if ( numero>0 ) {
                        numPositivos++;
                    } else {
                        numCeros++;
                    }
                    
                    // Contamos pares e impares
                    if ( numero % 2 == 0 ) {
                        numPares++;
                    } else {
                        numImpares++;
                    }
                    
                }

            } while ( numero >= 0 );

            if ( numElementos > 0 ) {
                media = (double)suma / numElementos;
            }
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("N�mero de elementos: " + numElementos);
            System.out.println ("N�mero de positivos: " + numPositivos);
            System.out.println ("N�mero de ceros: " + numCeros);
            System.out.println ("N�mero de pares: " + numPares);
            System.out.println ("N�mero de impares: " + numImpares);

            System.out.println ("Suma: " + suma);
            System.out.println ("Producto: " + producto);
            System.out.println ("Media: " + media);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}