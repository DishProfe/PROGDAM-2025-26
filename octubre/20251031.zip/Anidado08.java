
package ejemplos2025;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class Anidado08 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numLineas;
            int numColumnas;



            // Variables de salida
            String tabla;


            // Variables auxiliares
            int fila;
            int columna;
            int contador;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("TABLA DE N�MEROS");
            System.out.println("----------------");

            System.out.println("Introduzca n�mero de l�neas: ");
            numLineas = teclado.nextInt();

            System.out.println("Introduzca n�mero de columnas: ");
            numColumnas = teclado.nextInt();
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Iniciamos la tabla a la cadena vac�a
            tabla = "";
            
            // Vamos generando cada fila
            for ( fila = 1, contador = 1 ; fila<=numLineas ; fila++ ) {
                // Para cada fila escribimos su n�mero de fila y el car�cter ":"
                tabla += fila + ":" ;

                // Dentro de cada fila vamos generando las 11 columnas
                for ( columna = 1 ; columna <= numColumnas ; columna++, contador++  ) {
                    // Para cada columna escribimos su n�mero de columna
                    tabla += " " + contador;
                }
                // Una vez escritas todas las columnas de la fila,
                // escribimos un avance de l�nea
                tabla += "\n";
            }



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println (tabla);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}