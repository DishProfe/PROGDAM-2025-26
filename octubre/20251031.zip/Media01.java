
package ejemplos2025;

/**
 * Programa Procesamiento de datos de entrada
 * @author diosdado
 */

import java.util.Scanner;


public class Media01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            double numero;



            // Variables de salida
            double media;


            // Variables auxiliares
            double suma;
            int numElementos;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //      Entrada de datos + Procesamiento 
            //----------------------------------------------
            System.out.println("PROCESAMIENTO DE DATOS");
            System.out.println("----------------------");

            
            // Inicializamos acumulador
            suma = 0.0;
            media = 0.0;
            
            // Inicializamos contador
            numElementos = 0;
            
            do {
                // Vamos pidiendo n�meros hasta que se introduzca un negativo
                System.out.println("Introduzca n�mero real: ");
                numero = teclado.nextDouble();
                
                // Vamos acumulando (sumando) los n�meros introducidos
                if ( numero >= 0.0 ) {
                    suma += numero;
                    numElementos++;
                }

            } while ( numero >= 0.0 );

            // Calculamos la media
            if ( numElementos > 0 ) {
                media = suma / numElementos;
            }
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Media: " + media);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}