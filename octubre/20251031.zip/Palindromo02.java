
package ejemplos2025;

/**
 * Programa Detector de Pal�ndromos
 * @author diosdado
 */

import java.util.Scanner;


public class Palindromo02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String texto;



            // Variables de salida
            boolean esPalindromo;


            // Variables auxiliares
            int indice;
            int longTexto;
            String textoInverso;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("DETECCI�N DE PAL�NDROMOS");
            System.out.println("------------------------");
            System.out.println("Introduzca texto: ");
            texto = teclado.nextLine();
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Obtenemos la longitud del texto
            longTexto = texto.length();
            
            // Generamos el texto inverso
            textoInverso = "";
            for ( indice = 0 ; indice < longTexto ; indice++ ) {
                char c = texto.charAt (indice);
                textoInverso = c + textoInverso;
            }
            
            // Comparamos el texto original con el texto invertido
            esPalindromo = texto.equals(textoInverso);
            
                    
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Es texto " + 
                    ( esPalindromo ? "" : "no ") +
                    "es pal�ndromo."); 


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}