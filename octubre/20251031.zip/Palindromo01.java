
package ejemplos2025;

/**
 * Programa Detector de Pal�ndromos
 * @author diosdado
 */

import java.util.Scanner;


public class Palindromo01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String texto;



            // Variables de salida
            boolean esPalindromo;


            // Variables auxiliares
            int indice;
            int longTexto;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("DETECCI�N DE PAL�NDROMOS");
            System.out.println("------------------------");
            System.out.println("Introduzca texto: ");
            texto = teclado.nextLine();
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Obtenemos la longitud del texto
            longTexto = texto.length();
            
            esPalindromo = true;
            for ( indice = 0; indice <= longTexto / 2 && esPalindromo ; indice++ ) {
                esPalindromo = texto.charAt (indice) == texto.charAt (longTexto-1-indice);
            }

                    
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Es texto " + 
                    ( esPalindromo ? "" : "no ") +
                    "es pal�ndromo."); 


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}