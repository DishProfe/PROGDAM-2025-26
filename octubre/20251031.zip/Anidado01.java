
package ejemplos2025;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class Anidado01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            



            // Variables de salida



            // Variables auxiliares

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("TABLA DE N�MEROS");
            System.out.println("----------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------




            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");

            System.out.println ("1: 1 2 3 4 5");
            System.out.println ("2: 1 2 3 4 5");
            System.out.println ("3: 1 2 3 4 5");
            System.out.println ("4: 1 2 3 4 5");
            System.out.println ("5: 1 2 3 4 5");


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}