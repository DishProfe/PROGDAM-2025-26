
package ejemplos2025;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class ConcatenarTextos01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String texto1, texto2, texto3;




            // Variables de salida
            String textoResultado;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CONCATENACI�N DE CADENAS");
            System.out.println("------------------------");
            System.out.println("Introduzca tres textos:");
            texto1 = teclado.nextLine();
            texto2 = teclado.nextLine();
            texto3 = teclado.nextLine();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            textoResultado = texto1 + " " + texto2 + " " + texto3;



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Resultado final: ");
            System.out.println ("\"" +  textoResultado + "\"");

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}