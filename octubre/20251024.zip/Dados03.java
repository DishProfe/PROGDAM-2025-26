
package ejemplos2025;

/**
 * Programa Dados
 * @author diosdado
 */

import java.util.Scanner;


public class Dados03 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int NUM_DADOS = 4;


            // Variables de entrada
            int dado1, dado2, dado3, dado4;


            // Variables de salida
            boolean pareja;
            boolean trio;
            boolean doblePareja;
            boolean poker;
            boolean sinJugada;
            
            double puntuacionMedia;
            
            int v1 = 0, v2 = 0;



            // Variables auxiliares



            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("JUEGO DE DADOS");
            System.out.println("--------------");
            System.out.println("Introduzca el valor obtenido en cada dado: ");
            dado1 =  teclado.nextInt();
            dado2 =  teclado.nextInt();
            dado3 =  teclado.nextInt();
            dado4 =  teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            
            // Calculamos cada posible jugada (unas pueden incluir a otras)

            // Pareja: basta con que haya dos dados iguales (cualquier combinaci�n: 1-2, 1-3, 1-4, 2-3, 2-4, 3-4)
            pareja = dado1==dado2 || dado1==dado3 || dado1==dado4 || dado2==dado3 || dado2==dado4 || dado3==dado4;
            
            // Doble pareja: basta con que dos dados sean iguales y los otros dos tambi�n (cualquier combinaci�n: 1-2 y 3-4; 1-3 y 2-4; 1-4 y 2-3)
            doblePareja = (dado1==dado2 && dado3==dado4) || (dado1==dado3 && dado2==dado4) || (dado1==dado4 && dado2==dado3);

            // Tr�o: tres dados deben ser iguales (cualquier combinaci�n: 1,2,3 - 2,3,4 - 1,3,4 - 1,2,4)
            trio = dado1==dado2 && dado2==dado3  ||  dado2==dado3 && dado3==dado4  || dado1==dado3 && dado3==dado4 ||  dado1==dado2 && dado2==dado4 ;

            // Poker: los cuatro dados deben ser iguales: solo una posibilidad para comprobar
            poker = dado1==dado2 && dado2==dado3 && dado3==dado4;
            
            // Ahora refinamos para que solamente pueda haber una jugada:
            
            trio = trio && !poker; // Si hay poker, descartamos el tr�o (lo incuye)
            doblePareja = doblePareja && !poker; // Si hay poker, descartamos la posible doble pareja (la incluir�a)
            pareja = pareja && !doblePareja && !trio &&!poker;  // Si hay poker, doble pareja o tr�o, descartamos la pareja (la incluyen)
            sinJugada = !pareja && !doblePareja && !trio && !poker; // Si no hay pareja, ni doble pareja, ni tr�o, ni poker, no hay jugada
            
            
            // C�lculo de la puntuaci�n media (media aritm�tica)
            puntuacionMedia = (double) (dado1 + dado2 + dado3 + dado4) / NUM_DADOS;
            
            
            // Por �ltimo, recuperamos el valor de los dados que contienen la jugada
            if (poker) {
                // Si es p�quer, basta con mirar cualquiera de los dados, p.e. d1
                v1 = dado1;
            } else if (trio) {
                // Es un tr�o
                if ( dado1==dado2 ) {
                    // Si d1 y d2 son iguales -> Cualquiera de los dos vale para el tr�o
                    v1 = dado1;
                } else {
                    // Si no, cualquiera de los otros dos vale para el tr�o
                    v1 = dado3;
                }
            } else if ( pareja ) {
                // Es una pareja
                if ( dado1 == dado2 || dado1 == dado3 || dado1 == dado4 ) {
                    // Si d1 coincide con d2, d3 o d4 -> d1 es parte de la pareja
                    v1 =dado1;
                } else if ( dado2 == dado3 || dado2 == dado4 ) {
                    // Si d2 coincide con d3 o d4 -> d2 es parte de la pareja
                    v1 = dado2;
                } else {
                    // Si d1 ni d2 no coinciden con nadie -> La pareja es d3 y d4
                    v1 = dado3;
                }
            } else if ( doblePareja ) {
                // Es una doble pareja

                // Calculamos v1: el primer dado forma parte de la primera pareja
                v1 = dado1;
                if ( dado1 == dado2 ) {
                    // Si d1 y d2 coinciden -> La otra pareja es d3 y d4
                    v2 = dado3;
                } else if ( dado1 == dado3 ) {
                    // Si d1 y d3 coinciden -> La otra pareja es d2 y d4
                    v2 = dado2;
                } else {
                    // Si no, la �nica opci�n que queda es que la doble pareja 
                    // sea d1d4 y d2d3
                    v2 = dado2;
                }
            
        }

            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Jugada obtenida en el lanzamiento: ");
            System.out.print (  pareja      ? "Pareja" : "" );
            System.out.print (  doblePareja ? "Doble pareja" : "" );
            System.out.print (  trio        ? "Tr�o" : "" );
            System.out.print (  poker       ? "P�quer" : "" );
            System.out.print (  sinJugada   ? "Sin jugada" : "" );
            
            //System.out.println();
            System.out.print ( !sinJugada ? (" de " + v1) : "" );
            System.out.print ( doblePareja ? (" y " + v2)  : "" );
            System.out.println();
            
            System.out.println ( "Puntuaci�n media: " + puntuacionMedia);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

