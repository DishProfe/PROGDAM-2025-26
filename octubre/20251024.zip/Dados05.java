
package ejemplos2025;

/**
 * Programa Dados
 * @author diosdado
 */

import java.util.Scanner;

enum JugadaPoker {SIN_JUGADA, PAREJA, DOBLE_PAREJA, TRIO, POKER};

public class Dados05 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes
            final int NUM_DADOS = 4;


            // Variables de entrada
            int dado1, dado2, dado3, dado4;


            // Variables de salida
            JugadaPoker jugada;
            
            double puntuacionMedia;
            
            int v1 = 0, v2 = 0;



            // Variables auxiliares



            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("JUEGO DE DADOS");
            System.out.println("--------------");
            System.out.println("Introduzca el valor obtenido en cada dado: ");
            dado1 =  teclado.nextInt();
            dado2 =  teclado.nextInt();
            dado3 =  teclado.nextInt();
            dado4 =  teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            
            // Calculamos cada posible jugada (unas pueden incluir a otras)

            if ( dado1==dado2 && dado2==dado3 && dado3==dado4 ) {
                // Poker: los cuatro dados deben ser iguales: solo una posibilidad para comprobar
                jugada = JugadaPoker.POKER;            

            } else if ( dado1 == dado2 && dado2 == dado3 || dado2 == dado3 && dado3 == dado4 || dado1 == dado3 && dado3 == dado4 || dado1 == dado2 && dado2 == dado4 ) {
                // Tr�o: tres dados deben ser iguales (cualquier combinaci�n: 1,2,3 - 2,3,4 - 1,3,4 - 1,2,4)
                jugada = JugadaPoker.TRIO;

            } else if ( (dado1==dado2 && dado3==dado4) || (dado1==dado3 && dado2==dado4) || (dado1==dado4 && dado2==dado3) ) {
                // Doble pareja: basta con que dos dados sean iguales y los otros dos tambi�n (cualquier combinaci�n: 1-2 y 3-4; 1-3 y 2-4; 1-4 y 2-3)
                jugada = JugadaPoker.DOBLE_PAREJA;

            } else if (dado1==dado2 || dado1==dado3 || dado1==dado4 || dado2==dado3 || dado2==dado4 || dado3==dado4) {
                // Pareja: basta con que haya dos dados iguales (cualquier combinaci�n: 1-2, 1-3, 1-4, 2-3, 2-4, 3-4)
                jugada = JugadaPoker.PAREJA;

            } else {
                // No se ha encontrado ninguna jugada
                jugada = JugadaPoker.SIN_JUGADA;
            }
                
            
            // C�lculo de la puntuaci�n media (media aritm�tica)
            puntuacionMedia = (double) (dado1 + dado2 + dado3 + dado4) / NUM_DADOS;
            
            // Por �ltimo, recuperamos el valor de los dados que contienen la jugada            
            switch ( jugada ) {
                case POKER:
                    // Si es p�quer, basta con mirar cualquiera de los dados, p.e. d1
                    v1 = dado1;
                    break;

                case TRIO:
                    // Es un tr�o
                    if ( dado1==dado2 ) {
                        // Si d1 y d2 son iguales -> Cualquiera de los dos vale para el tr�o
                        v1 = dado1;
                    } else {
                        // Si no, cualquiera de los otros dos vale para el tr�o (pues tienen que ser iguales)
                        v1 = dado3;
                    }                    
                    break;
                 
                case PAREJA:
                    // Es una pareja
                    if (dado1 == dado2 || dado1 == dado3 || dado1 == dado4) {
                        // Si d1 coincide con d2, d3 o d4 -> d1 es parte de la pareja
                        v1 = dado1;
                    } else if (dado2 == dado3 || dado2 == dado4) {
                        // Si d2 coincide con d3 o d4 -> d2 es parte de la pareja
                        v1 = dado2;
                    } else {
                        // Si d1 ni d2 no coinciden con nadie -> La pareja es d3 y d4
                        v1 = dado3;
                    }
                    break;

                case DOBLE_PAREJA:
                    // Es una doble pareja

                    // Calculamos v1: nos quedamos con el primer dado, que forma parte de una pareja
                    v1 = dado1;
                    
                    // Calculamos v2:
                    if ( dado1 == dado2 ) {
                        // Si d1 y d2 coinciden -> La otra pareja es d3 y d4
                        v2 = dado3;
                    } else if ( dado1 == dado3 ) {
                        // Si d1 y d3 coinciden -> La otra pareja es d2 y d4
                        v2 = dado2;
                    } else {
                        // Si no, la �nica opci�n que queda es que la doble pareja 
                        // sea d1d4 y d2d3
                        v2 = dado2;
                    }
                    break;
                
                case SIN_JUGADA:
                    v1 = 0;
                    v2 = 0;
                    
            }
        

            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Jugada obtenida en el lanzamiento: ");
            System.out.print (  jugada );
            
            //System.out.println();
            System.out.print ( jugada != JugadaPoker.SIN_JUGADA ? (" de " + v1) : "" );
            System.out.print ( jugada == JugadaPoker.DOBLE_PAREJA ? (" y " + v2)  : "" );
            System.out.println();
            
            System.out.println ( "Puntuaci�n media: " + puntuacionMedia);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}

