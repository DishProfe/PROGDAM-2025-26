
package ejemplos2025;

/**
 * Programa XXX
 * @author diosdado
 */

import java.util.Scanner;


public class ConcatenarTextos04 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            //String texto1, texto2, texto3;




            // Variables de salida
            String textoResultado;


            // Variables auxiliares
            int contador;
            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("CONCATENACI�N DE CADENAS");
            System.out.println("------------------------");

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            textoResultado = "";
            contador = 0;
            while ( contador <= 9 ) {
                textoResultado += contador;            
                contador++;
            }

 

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Resultado final: ");
            System.out.println ("\"" +  textoResultado + "\"");

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}