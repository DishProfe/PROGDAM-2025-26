
package ejemplos2025;

/**
 * Programa De entero a palabra
 * @author diosdado
 */

import java.util.Scanner;


public class NumeroAPalabraCualquierCifra01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;



            // Variables de salida
            String textoResultado;

            // Variables auxiliares
            boolean numeroInvalido;
            int cifra;
            int numRestante;
            String textoCifra;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("DE ENTERO A PALABRA");
            System.out.println("-------------------");

            
            do {
                System.out.print("Introduzca n�mero entero entero entre 0-999999999: ");
                numero = teclado.nextInt();                

                numeroInvalido = numero < 0 || numero > 999999999;
                
                if ( numeroInvalido ) {
                    System.out.println ("N�mero inv�lido. Introd�zcalo de nuevo...\n");
                }

            } while ( numeroInvalido );

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            
            numRestante = numero;
            textoResultado = "";
            
            do {

                cifra = numRestante % 10;
                numRestante = numRestante / 10;
                        
                switch (cifra) {
                    case 0:
                        textoCifra = "cero";
                        break;
                    case 1:
                        textoCifra = "uno";
                        break;
                    case 2:
                        textoCifra = "dos";
                        break;
                    case 3:
                        textoCifra = "tres";
                        break;
                    case 4:
                        textoCifra = "cuatro";
                        break;
                    case 5:
                        textoCifra = "cinco";
                        break;
                    case 6:
                        textoCifra = "seis";
                        break;
                    case 7:
                        textoCifra = "siete";
                        break;
                    case 8:
                        textoCifra = "ocho";
                        break;
                    case 9:
                        textoCifra = "nueve";
                        break;
                    default:
                        textoCifra = "error";
                        break;
                }

                textoResultado = textoCifra + " " + textoResultado
;                        
                
            } while ( numRestante > 0 ) ;
            

            


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El n�mero introducido es: " 
                    + textoResultado); 
           

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}