
package ejemplos2025;

/**
 * Programa Al menos dos entradas son iguales
 * @author diosdado
 */

import java.util.Scanner;


public class DosIguales01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int a, b, c;




            // Variables de salida
            boolean dosIguales;
            String mensajeFinal;



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBACI�N DE IGUALDAD");
            System.out.println("---------------------");
            /*
            System.out.println("Introduzca a: ");
            a = teclado.nextInt();

            System.out.println("Introduzca b: ");
            b = teclado.nextInt();

            System.out.println("Introduzca b: ");
            c = teclado.nextInt(); */

            System.out.println ("Introduzca tres enteros a, b y c:");
            a = teclado.nextInt();
            b = teclado.nextInt();
            c = teclado.nextInt();
            
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            dosIguales =  a==b || b==c || a==c ;



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("a= " + a);
            System.out.println ("b= " + b);
            System.out.println ("c= " + c);
            System.out.println ("Hay al menos dos iguales: " + dosIguales);

            mensajeFinal = dosIguales ? "Hay al menos dos iguales" : "Los tres son diferentes";
            System.out.println ( mensajeFinal );

            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}
