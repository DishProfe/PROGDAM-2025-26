
package ejemplos2025;

/**
 * Programa para comprobar si un n�mero es positivo, negativo o cero
 * @author diosdado
 */

import java.util.Scanner;


public class PositivoNegativoCero01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;




            // Variables de salida
            String resultado;



            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBACI�N POSITIVO-NEGATIVO-CERO");
            System.out.println("-----------------------------------");

            System.out.println ("Introduzca un n�mero entero:");
            numero = teclado.nextInt();
            
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            resultado = numero > 0 ? "positivo" : ( numero < 0 ? "negativo" : "cero" ); 



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El n�mero es " + resultado);

            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}
