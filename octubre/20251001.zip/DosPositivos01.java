
package ejemplos2025;

/**
 * Programa para comprobar si dos n�meros son positivos
 * @author diosdado
 */

import java.util.Scanner;


public class DosPositivos01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int a, b;




            // Variables de salida
            boolean dosPositivos;
            String mensajeFinal;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("PROGRAMA DE COMPROBACI�N DE DOS POSITIVOS");
            System.out.println("-----------------------------------------");
            System.out.println("Introduzca dos n�meros enteros: a y b");
            a = teclado.nextInt();
            b = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            dosPositivos = a>0 && b>0;



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");

            System.out.println ("Los dos n�meros son positivos: " + dosPositivos);

            mensajeFinal = dosPositivos ? "Los dos n�meros son positivos" : "Al menos uno no es positivo";
            System.out.println (mensajeFinal);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}
