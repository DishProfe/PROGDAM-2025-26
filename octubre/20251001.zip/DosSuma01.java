
package ejemplos2025;

/**
 * Programa para comprobar que la suma de dos n�meros es un tercer n�mero
 * @author diosdado
 */

import java.util.Scanner;


public class DosSuma01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int a, b, c;



            // Variables de salida
            boolean sumaValida;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("TRES N�MEROS: UNO DE ELLOS ES LA SUMA DE LOS OTROS DOS");
            System.out.println("------------------------------------------------------");
            System.out.println("Introduzca tres n�meros enteros a, b, c: ");
            a = teclado.nextInt();
            b = teclado.nextInt();
            c = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            
            sumaValida = a+b==c || a+c==b || b+c==a;
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("La suma de dos de ellos es igual al tercero: " + sumaValida);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}
