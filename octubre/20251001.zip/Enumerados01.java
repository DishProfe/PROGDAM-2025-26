
package ejemplos2025;

/**
 * Programa Ejemplo de tipo enumerado
 * @author diosdado
 */

import java.util.Scanner;


public class Enumerados01 {
 
        public enum Estacion { SPRING, SUMMER, AUTUMN, WINTER };
        public enum PaloBaraja { OROS, COPAS, BASTOS, ESPADAS };
        public enum Medalla { ORO, PLATA, BRONCE };
        public enum ComunidadAutonoma { ANDALUCIA, EXTREMADURA, ASTURIAS, GALICIA };
        
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada




            // Variables de salida



            // Variables auxiliares
            int x;
            boolean y;
            String texto;
            Estacion estacion1, estacion2, estacion3;
            PaloBaraja palo1, palo2, palo3, palo4;
            Medalla med1, med2, med3;
            ComunidadAutonoma com1, com2, com3;
            
            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("EJEMPLOS DE USO DE ENUM");
            System.out.println("-----------------------");
            System.out.println(" ");


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            x =10;
            y = true;
            texto = "Ejemplo de texto";
            estacion1 = Estacion.SUMMER;
            estacion2 = Estacion.WINTER;
            estacion3 = estacion1;

            palo1 = PaloBaraja.BASTOS;
            palo2 = PaloBaraja.OROS;
            palo3 = PaloBaraja.ESPADAS;
            palo4 = palo2;

            med1 = Medalla.ORO;
            med2 = med1;
            med3 = med2;
            
            com1 = ComunidadAutonoma.ANDALUCIA;
            com2 = ComunidadAutonoma.EXTREMADURA;
            com3 = com1;
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("estacion1 = " + estacion1);
            System.out.println ("estacion2 = " + estacion2);
            System.out.println ("estacion3 = " + estacion3);

            System.out.println ("palo1 = " + palo1);
            System.out.println ("palo2 = " + palo2);

            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}
