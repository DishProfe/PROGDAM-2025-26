
package ejemplos2025;

/**
 * Programa para saber si un n�mero de 2 cifras es capic�a
 * @author diosdado
 */

import java.util.Scanner;


public class Capicua03 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;




            // Variables de salida
            boolean capicua;
            String mensajeResultado;



            // Variables auxiliares
            int unidades;
            int decenas;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBACI�N DE CAPIC�A");
            System.out.println("-----------------------");

            System.out.println ("Introduzca n�mer entero de dos cifras:");
            numero = teclado.nextInt();
            
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            mensajeResultado = numero>=10 && numero<=99 ?  (numero % 11 == 0 ? "s�" : "no") : "error"  ;



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El n�mero es capicua: " + mensajeResultado);
            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}
