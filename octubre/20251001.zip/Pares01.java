
package ejemplos2025;

/**
 * Programa Comprobador de paridad
 * @author diosdado
 */

import java.util.Scanner;


public class Pares01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;




            // Variables de salida
            boolean esPar; 



            // Variables auxiliares
            int resto; 


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBADOR DE PARIDAD");
            System.out.println("----------------------");
            System.out.println("Introduzca un n�mero entero:");
            numero = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            resto = numero % 2 ;
            esPar = resto == 0;
            // esPar = (numero % 2) == 0;


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El n�mero " + numero + " es par: " + esPar);
            System.out.println ("El n�mero " + numero + " es par: " + 
                    (esPar ? "s�" : "no") );
            System.out.println ("El n�mero " + numero + 
                    (esPar ? " s�" : " no") +
                    " es par."); 
            System.out.println ("El n�mero " + numero + 
                    (esPar ? "" : " no") + " es par" ); 
            System.out.println ("El n�mero " + numero + " es " +
                    (esPar ? "par" : "impar")); 
            
            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}
