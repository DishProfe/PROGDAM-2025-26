
package ejemplos2025;

/**
 * Programa para saber si un n�mero de 2 cifras es capic�a
 * @author diosdado
 */

import java.util.Scanner;


public class Capicua01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;




            // Variables de salida
            boolean capicua;



            // Variables auxiliares
            int unidades;
            int decenas;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("COMPROBACI�N DE CAPIC�A");
            System.out.println("-----------------------");

            System.out.println ("Introduzca n�mer entero de dos cifras:");
            numero = teclado.nextInt();
            
            
            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            unidades = numero % 10;
            decenas = numero / 10;
            
            capicua = unidades == decenas  ;



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El n�mero es capicua: " + capicua);
            System.out.println ("El n�mero " + ( capicua ? "" : "no " ) + "es capicua");
            
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}
