
package ejemplos2025;

/**
 * Programa C�lculo si al menos hay dos n�meros iguales de un conjunto de tres
 * @author diosdado
 */

import java.util.Scanner;


public class IgualesDeTres01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int num1, num2, num3;



            // Variables de salida
            boolean dosIguales;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("AL MENOS DOS IGUALES DE TRES");
            System.out.println("------------------------");
            System.out.println("Introduzca tres n�meros enteros");
            num1 = teclado.nextInt();
            num2 = teclado.nextInt();
            num3 = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            if (num1 == num2 || num2 == num3 || num1 == num3) {
                dosIguales = true;
            } else {
                dosIguales = false;                
            }

            // dosIguales = num1 == num2 || num2 == num3 || num1 == num3 ;
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            if (dosIguales) {
                System.out.println ("Al menos hay dos n�meros iguales");
            }
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}