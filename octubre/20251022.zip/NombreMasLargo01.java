
package ejemplos2025;

/**
 * Programa Para averiguar cu�l de dos nombres es m�s largo
 * @author diosdado
 */

import java.util.Scanner;


public class NombreMasLargo01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String nombre1, nombre2;




            // Variables de salida
            String nombreMasLargo;



            // Variables auxiliares
            int longNombre1;
            int longNombre2;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("NOMBRE M�S LARGO");
            System.out.println("----------------");
            System.out.println("Introduzca primer nombre: ");
            nombre1 = teclado.nextLine();
            System.out.println("Introduzca segundo nombre: ");
            nombre2 = teclado.nextLine();


            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Obtenemos la longitud de cada nombre
            longNombre1 = nombre1.length();
            longNombre2 = nombre2.length();

            nombreMasLargo = longNombre1 > longNombre2 ? nombre1 : nombre2;
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El nombre m�s largo es: " + nombreMasLargo);

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}