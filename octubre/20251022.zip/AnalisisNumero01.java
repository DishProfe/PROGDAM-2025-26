
package ejemplos2025;

/**
 * Programa An�lisis de n�mero
 * @author diosdado
 */

import java.util.Scanner;

enum TipoNumero { NEGATIVO, CERO, POSITIVO};

public class AnalisisNumero01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;



            // Variables de salida
            boolean esPar;
            TipoNumero tipoNumero;
            boolean mayor3Cifras;
            


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("AN�LISIS DE N�MERO");
            System.out.println("------------------");
            System.out.println("Introduzca n�mero entero: ");
            numero = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            // Comprobaci�n de paridad
            esPar = numero % 2 == 0 ;
            
            // Comprobaci�n +/-/0
            if ( numero < 0 ) {
                tipoNumero = TipoNumero.NEGATIVO;
            } else if ( numero == 0) {
                tipoNumero = TipoNumero.CERO;
            } else {
                tipoNumero = TipoNumero.POSITIVO;
            }

            // Comprobaci�n de m�s de tres cifras
            // if ( Math.abs(numero) > 999 )
            
//            if ( numero > 999 || numero < -999 ) {            if ( Math.abs(numero) > 999 || numero < -999 ) {            if ( Math.abs(numero) > 999 || numero < -999 ) {
//                mayor3Cifras = true;
//            } else {
//                mayor3Cifras = false;
//            }

            mayor3Cifras = numero > 999 || numero < -999;

            //mayor3Cifras = Math.abs (numero) > 999;
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El n�mero es " +
                    (esPar ? "par" : "impar") );
            System.out.println ("El n�mero es " + tipoNumero);
            System.out.println ("El n�mero " 
                    + (mayor3Cifras ? "" : "no ")
                    + "tiene m�s de tres cifras");
            System.out.println ("Fin del programa.");
        
        
	}
    
}