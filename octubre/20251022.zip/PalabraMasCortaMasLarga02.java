
package ejemplos2025;

/**
 * Programa Para calcular la palabra m�s larga y la m�s corta de tres.
 * @author diosdado
 */

import java.util.Scanner;


public class PalabraMasCortaMasLarga02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            String palabra1, palabra2, palabra3;



            // Variables de salida
            String palabraMasLarga="";
            String palabraMasCorta="";


            // Variables auxiliares
            int long1, long2, long3;


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("PALABRA M�S LARGA Y PALABRA M�S CORTA");
            System.out.println("-------------------------------------");
            System.out.println("Introduzca tres palabras");
            palabra1 = teclado.nextLine();
            palabra2 = teclado.nextLine();
            palabra3 = teclado.nextLine();
            

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            long1 = palabra1.length();
            long2 = palabra2.length();
            long3 = palabra3.length();

            if ( long1 > long2 && long1 > long3 ) {
                palabraMasLarga = palabra1;
            } else if ( long2 > long3 && long2 > long1 ) {
                palabraMasLarga = palabra2;
            } else {
                palabraMasLarga = palabra3;                
            }

            if ( long1 < long2 && long1 < long3 ) {
                palabraMasCorta = palabra1;
            } else if ( long2 < long3 && long2 < long1 ) {
                palabraMasCorta = palabra2;
            } else {
                palabraMasCorta = palabra3;                
            }
            
            
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("Palabra m�s larga: " + palabraMasLarga);
            System.out.println ("Palabra m�s corta: " + palabraMasCorta);


            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}