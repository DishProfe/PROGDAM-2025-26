
package ejemplos2025;

/**
 * Programa De entero a palabra
 * @author diosdado
 */

import java.util.Scanner;


public class NumeroAPalabraDosCifras01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;



            // Variables de salida
            String texto;

            // Variables auxiliares
            boolean numeroInvalido;
            int unidad;
            int decena;
            String textoUnidad;
            String textoDecena;            

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("DE ENTERO A PALABRA");
            System.out.println("-------------------");

            
            do {
                System.out.print("Introduzca n�mero entero entero entre 0-99: ");
                numero = teclado.nextInt();                

                numeroInvalido = numero < 0 || numero > 99;
                
                if ( numeroInvalido ) {
                    System.out.println ("N�mero inv�lido. Introd�zcalo de nuevo...\n");
                }

            } while ( numeroInvalido );

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            unidad = numero % 10;
            decena = numero / 10;

            switch (decena) {
                case 0:
                    textoDecena = "cero";
                    break;
                case 1:
                    textoDecena = "uno";
                    break;
                case 2:
                    textoDecena = "dos";
                    break;
                case 3:
                    textoDecena = "tres";
                    break;
                case 4:
                    textoDecena = "cuatro";
                    break;
                case 5:
                    textoDecena = "cinco";
                    break;
                case 6:
                    textoDecena = "seis";
                    break;
                case 7:
                    textoDecena = "siete";
                    break;
                case 8:
                    textoDecena = "ocho";
                    break;
                case 9:
                    textoDecena = "nueve";
                    break;
                default:
                    textoDecena = "error";
                    break;
            }

            
            
            switch (unidad) {
                case 0:
                    textoUnidad = "cero";
                    break;
                case 1:
                    textoUnidad = "uno";
                    break;
                case 2:
                    textoUnidad = "dos";
                    break;
                case 3:
                    textoUnidad = "tres";
                    break;
                case 4:
                    textoUnidad = "cuatro";
                    break;
                case 5:
                    textoUnidad = "cinco";
                    break;
                case 6:
                    textoUnidad = "seis";
                    break;
                case 7:
                    textoUnidad = "siete";
                    break;
                case 8:
                    textoUnidad = "ocho";
                    break;
                case 9:
                    textoUnidad = "nueve";
                    break;
                default:
                    textoUnidad = "error";
                    break;
            }
            
            texto = textoDecena + " " + textoUnidad;
            


            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El n�mero introducido es: " 
                    + texto); 
           

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}