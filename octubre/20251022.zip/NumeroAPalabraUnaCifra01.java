
package ejemplos2025;

/**
 * Programa De entero a palabra
 * @author diosdado
 */

import java.util.Scanner;


public class NumeroAPalabraUnaCifra01 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int numero;



            // Variables de salida
            String texto;



            // Variables auxiliares
            boolean numeroInvalido;

            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("DE ENTERO A PALABRA");
            System.out.println("-------------------");

            
            do {
                System.out.print("Introduzca n�mero entero entero entre 0-9: ");
                numero = teclado.nextInt();                

                numeroInvalido = numero < 0 || numero > 9;
                
                if ( numeroInvalido ) {
                    System.out.println ("N�mero inv�lido. Introd�zcalo de nuevo...\n");
                }

            } while ( numeroInvalido );

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------
            switch (numero) {
                case 0:
                    texto = "cero";
                    break;
                case 1:
                    texto = "uno";
                    break;
                case 2:
                    texto = "dos";
                    break;
                case 3:
                    texto = "tres";
                    break;
                case 4:
                    texto = "cuatro";
                    break;
                case 5:
                    texto = "cinco";
                    break;
                case 6:
                    texto = "seis";
                    break;
                case 7:
                    texto = "siete";
                    break;
                case 8:
                    texto = "ocho";
                    break;
                case 9:
                    texto = "nueve";
                    break;
                default:
                    texto = "error";
                    break;
            }
            



            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            System.out.println ("El n�mero introducido es: " 
                    + texto); 
           

            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}