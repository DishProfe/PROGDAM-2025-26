
package ejemplos2025;

/**
 * Programa C�lculo del mayor y el menor de dos n�meros
 * @author diosdado
 */

import java.util.Scanner;


public class MayorMenor02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int num1, num2;



            // Variables de salida
            int mayor, menor;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("C�LCULO DE MAYOR Y MENOR");
            System.out.println("------------------------");
            System.out.println("Introduzca dos n�meros enteros");
            num1 = teclado.nextInt();
            num2 = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            //mayor = num1>num2 ? num1: num2 ;
            //menor = num1<num2 ? num1: num2 ;

            if ( num1>num2 ) {
                mayor = num1;
                menor = num2;
            } else {
                mayor = num2;
                menor = num1;
            }
            
            

            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            if ( num1 == num2) {
                System.out.println ("Los dos n�meros son iguales.");
            } else {
                System.out.println ("El mayor es: " + mayor);
                System.out.println ("El menor es: " + menor);
            }
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}