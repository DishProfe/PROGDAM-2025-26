
package ejemplos2025;

/**
 * Programa C�lculo si al menos hay dos n�meros iguales de un conjunto de tres
 * @author diosdado
 */

import java.util.Scanner;


public class IgualesDeTres02 {
 
	public static void main(String[] args) {

            //----------------------------------------------
            //          Declaraci�n de variables 
            //----------------------------------------------

            // Constantes


            // Variables de entrada
            int num1, num2, num3;



            // Variables de salida
            boolean dosIguales;
            int repetido;


            // Variables auxiliares


            // Clase Scanner para petici�n de datos de entrada
            Scanner teclado= new Scanner (System.in);
        
        
            //----------------------------------------------
            //                Entrada de datos 
            //----------------------------------------------
            System.out.println("AL MENOS DOS IGUALES DE TRES");
            System.out.println("------------------------");
            System.out.println("Introduzca tres n�meros enteros");
            num1 = teclado.nextInt();
            num2 = teclado.nextInt();
            num3 = teclado.nextInt();

            //----------------------------------------------
            //                 Procesamiento 
            //----------------------------------------------

            dosIguales = num1 == num2 || num2 == num3 || num1 == num3;

            if (dosIguales) {
                if ( num1 == num2) {
                    repetido = num1;
                } else {
                    repetido = num3;
                }
            }

            if (dosIguales) {
                repetido = num1 == num2 ? num1 : num3 ; 
            }
            
            
            
            
            
            //---------------------------------------------
            //              Salida de resultados 
            //----------------------------------------------

            System.out.println ();
            System.out.println ("RESULTADO");
            System.out.println ("---------");
            if (dosIguales) {
                System.out.println ("Al menos hay dos n�meros iguales.");
            } else {
                System.out.println ("Todos son diferentes.");                
            }
            System.out.println ();
            System.out.println ("Fin del programa.");
        
        
	}
    
}